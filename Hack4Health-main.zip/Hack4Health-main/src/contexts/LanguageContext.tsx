'use client';

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { translations, languageNames, languageFlags, Translation } from '@/lib/translations';

interface LanguageContextType {
  currentLanguage: string;
  setLanguage: (language: string) => void;
  t: Translation;
  availableLanguages: string[];
  languageNames: typeof languageNames;
  languageFlags: typeof languageFlags;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

interface LanguageProviderProps {
  children: ReactNode;
}

export function LanguageProvider({ children }: LanguageProviderProps) {
  const [currentLanguage, setCurrentLanguage] = useState<string>('english');
  const [isClient, setIsClient] = useState(false);

  // Available languages
  const availableLanguages = Object.keys(translations);

  useEffect(() => {
    setIsClient(true);
    // Load saved language from localStorage
    const savedLanguage = localStorage.getItem('nidaan-language');
    if (savedLanguage && translations[savedLanguage]) {
      setCurrentLanguage(savedLanguage);
    }
  }, []);

  const setLanguage = (language: string) => {
    if (translations[language]) {
      setCurrentLanguage(language);
      localStorage.setItem('nidaan-language', language);
      
      // Update document language for accessibility
      document.documentElement.lang = language === 'hindi' ? 'hi' : 
                                     language === 'odia' ? 'or' : 
                                     language === 'sambalpuri' ? 'or' : 'en';
    }
  };

  const t = translations[currentLanguage] || translations.english;

  // Don't render until client-side to avoid hydration mismatch
  if (!isClient) {
    return <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
    </div>;
  }

  return (
    <LanguageContext.Provider 
      value={{ 
        currentLanguage, 
        setLanguage, 
        t, 
        availableLanguages,
        languageNames,
        languageFlags
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}
