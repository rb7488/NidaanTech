'use client';

import React, { useState, useEffect } from 'react';
import Layout from '@/components/Layout';
import { useLanguage } from '@/contexts/LanguageContext';
import { mockApi, SymptomAnalysisResponse, apiUtils } from '@/lib/mockApi';
import { MedicalDiagnosisResult } from '@/lib/medicalDiagnosis';
import { useVoiceRecognition } from '@/hooks/useVoiceRecognition';
import { 
  Mic, 
  MicOff, 
  Search, 
  AlertTriangle, 
  CheckCircle, 
  Clock,
  MapPin,
  Phone,
  Share2,
  MessageCircle,
  ArrowLeft,
  Loader2
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import Link from 'next/link';

export default function SymptomsPage() {
  const { t, currentLanguage } = useLanguage();
  const [symptoms, setSymptoms] = useState<string>('');
  const [analysis, setAnalysis] = useState<SymptomAnalysisResponse | null>(null);
  const [medicalDiagnosis, setMedicalDiagnosis] = useState<MedicalDiagnosisResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState<'input' | 'followup' | 'questioning' | 'analyzing' | 'results'>('input');
  const [userPincode] = useState('751001'); // Mock user pincode
  const [useMedicalAPI, setUseMedicalAPI] = useState(true); // Toggle between old and new API
  const [illnessDuration, setIllnessDuration] = useState<number>(1); // Days since symptoms started
  const [voiceError, setVoiceError] = useState<string | null>(null);
  
  // Akinator-like questioning system state
  const [currentQuestion, setCurrentQuestion] = useState<any>(null);
  const [questionHistory, setQuestionHistory] = useState<any[]>([]);
  const [questionCount, setQuestionCount] = useState(0);
  const [preliminaryDiseaseScores, setPreliminaryDiseaseScores] = useState<any>(null);
  const [maxQuestions, setMaxQuestions] = useState(5); // Dynamic question limit

  // Voice recognition hook
  const {
    isListening,
    transcript,
    error: voiceRecognitionError,
    isSupported: isVoiceSupported,
    startListening,
    stopListening,
    resetTranscript
  } = useVoiceRecognition({
    language: currentLanguage,
    continuous: true,
    interimResults: true
  });

  // Handle voice recognition transcript updates
  useEffect(() => {
    if (transcript) {
      setSymptoms(transcript);
    }
  }, [transcript]);

  // Handle voice recognition errors
  useEffect(() => {
    if (voiceRecognitionError) {
      setVoiceError(voiceRecognitionError);
      // Let the browser handle permission requests natively
      // Don't show custom modal, just display the error
    }
  }, [voiceRecognitionError]);

  const handleStartListening = () => {
    setVoiceError(null);
    resetTranscript();
    startListening();
  };


  const handleStopListening = () => {
    stopListening();
  };

  const analyzeSymptoms = async () => {
    if (!symptoms.trim()) return;
    
    if (useMedicalAPI) {
      // For medical API, go to follow-up questions first
      setStep('followup');
    } else {
      // For basic API, analyze directly
      setLoading(true);
      setStep('analyzing');
      
      try {
        const symptomsArray = symptoms
          .split(/[,;]+/) // Split by comma or semicolon
          .map(s => s.trim())
          .filter(s => s.length > 0); // Remove empty strings
        const result = await mockApi.analyzeSymptoms(symptomsArray, userPincode, currentLanguage);
        setAnalysis(result);
        setStep('results');
      } catch (error) {
        console.error('Error analyzing symptoms:', error);
      } finally {
        setLoading(false);
      }
    }
  };

  const processMedicalDiagnosis = async () => {
    setLoading(true);
    setStep('analyzing');
    
    try {
      const symptomsArray = symptoms.split(',').map(s => s.trim());
      
      const response = await fetch('/api/intelligent-diagnosis', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          symptoms: symptomsArray,
          pincode: userPincode,
          language: currentLanguage,
          age: 30, // Mock age - in real app, get from user profile
          gender: 'male', // Mock gender - in real app, get from user profile
          illnessDuration: illnessDuration,
          action: 'diagnose'
        }),
      });
      
      if (response.ok) {
        const medicalResult = await response.json();
        setMedicalDiagnosis(medicalResult);
        
        // Record consultation for performance metrics
        try {
          await fetch('/api/performance-metrics', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              action: 'record',
              data: {
                ...medicalResult,
                location: userPincode,
                userProfile: { age: 30, gender: 'male' }
              }
            }),
          });
        } catch (metricsError) {
          console.warn('Failed to record performance metrics:', metricsError);
        }
      } else {
        throw new Error('Intelligent diagnosis API failed');
      }
      
      setStep('results');
    } catch (error) {
      console.error('Error analyzing symptoms:', error);
      // Fallback to old API if medical API fails
      try {
        const symptomsArray = symptoms
          .split(/[,;]+/) // Split by comma or semicolon
          .map(s => s.trim())
          .filter(s => s.length > 0); // Remove empty strings
        const result = await mockApi.analyzeSymptoms(symptomsArray, userPincode, currentLanguage);
        setAnalysis(result);
        setStep('results');
      } catch (fallbackError) {
        console.error('Fallback API also failed:', fallbackError);
      }
    } finally {
      setLoading(false);
    }
  };

  // Start the intelligent questioning phase
  const startQuestioningPhase = async () => {
    setLoading(true);
    
    try {
      const symptomsArray = symptoms.split(',').map(s => s.trim());
      
      // Get preliminary diagnosis to guide questions
      const response = await fetch('/api/intelligent-diagnosis', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          symptoms: symptomsArray,
          pincode: userPincode,
          language: currentLanguage,
          age: 30,
          gender: 'male',
          illnessDuration: illnessDuration,
          action: 'diagnose'
        }),
      });
      
      if (response.ok) {
        const result = await response.json();
        setPreliminaryDiseaseScores(result);
        
        // Determine dynamic question limit based on symptoms and confidence
        const symptomCount = symptomsArray.length;
        const primaryConfidence = result.primaryDiagnosis?.confidence || 0;
        
        let dynamicLimit = 5; // Default
        if (symptomCount <= 2) {
          dynamicLimit = 10; // More questions for limited symptoms
        } else if (primaryConfidence < 60) {
          dynamicLimit = 8; // More questions for low confidence
        } else if (primaryConfidence > 80) {
          dynamicLimit = 3; // Fewer questions for high confidence
        }
        
        setMaxQuestions(dynamicLimit);
        
        // Get the first intelligent question
        if (result.intelligentQuestions?.nextQuestion) {
          setCurrentQuestion(result.intelligentQuestions.nextQuestion);
          setQuestionCount(1);
          setStep('questioning');
        } else {
          // No questions available, proceed directly to final analysis
          setMedicalDiagnosis(result);
          setStep('results');
        }
      } else {
        throw new Error('Failed to get preliminary diagnosis');
      }
    } catch (error) {
      console.error('Error starting questioning phase:', error);
      // Fallback to direct analysis
      processMedicalDiagnosis();
    } finally {
      setLoading(false);
    }
  };

  // Handle answer to current question
  const handleQuestionAnswer = async (answer: boolean | string) => {
    const answerData = {
      questionId: currentQuestion.id,
      answer: answer,
      timestamp: new Date().toISOString()
    };
    
    // Add to question history
    const newHistory = [...questionHistory, answerData];
    setQuestionHistory(newHistory);
    
    setLoading(true);
    
    try {
      const symptomsArray = symptoms.split(',').map(s => s.trim());
      
      // Get next question or final diagnosis
      const response = await fetch('/api/intelligent-diagnosis', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          symptoms: symptomsArray,
          pincode: userPincode,
          language: currentLanguage,
          age: 30,
          gender: 'male',
          illnessDuration: illnessDuration,
          conversationHistory: newHistory,
          action: 'answer_question',
          questionId: currentQuestion.id,
          answer: answer,
          currentResult: preliminaryDiseaseScores
        }),
      });
      
      if (response.ok) {
        const result = await response.json();
        setPreliminaryDiseaseScores(result);
        
        // Check if we should ask another question based on confidence and question limit
        const currentConfidence = result.primaryDiagnosis?.confidence || 0;
        const shouldContinueAsking = result.intelligentQuestions?.nextQuestion && 
                                   questionCount < maxQuestions && 
                                   currentConfidence < 60; // Continue until 60% confidence
        
        if (shouldContinueAsking) {
          setCurrentQuestion(result.intelligentQuestions.nextQuestion);
          setQuestionCount(prev => prev + 1);
        } else {
          // Proceed to final analysis
          setMedicalDiagnosis(result);
          
          // Record consultation for performance metrics
          try {
            await fetch('/api/performance-metrics', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                action: 'record',
                data: {
                  ...result,
                  location: userPincode,
                  userProfile: { age: 30, gender: 'male' },
                  questioningSession: {
                    totalQuestions: questionCount,
                    questionsAnswered: newHistory.length,
                    completionRate: (newHistory.length / questionCount) * 100
                  }
                }
              }),
            });
          } catch (metricsError) {
            console.warn('Failed to record performance metrics:', metricsError);
          }
          
          setStep('results');
        }
      } else {
        throw new Error('Failed to process question answer');
      }
    } catch (error) {
      console.error('Error processing question answer:', error);
      // Fallback to current preliminary diagnosis
      setMedicalDiagnosis(preliminaryDiseaseScores);
      setStep('results');
    } finally {
      setLoading(false);
    }
  };

  // Skip remaining questions and proceed to diagnosis
  const skipQuestions = () => {
    setMedicalDiagnosis(preliminaryDiseaseScores);
    setStep('results');
  };

  const resetForm = () => {
    setSymptoms('');
    setAnalysis(null);
    setMedicalDiagnosis(null);
    setIllnessDuration(1);
    setVoiceError(null);
    setCurrentQuestion(null);
    setQuestionHistory([]);
    setQuestionCount(0);
    setPreliminaryDiseaseScores(null);
    setStep('input');
    resetTranscript();
    if (isListening) {
      stopListening();
    }
  };

  const shareViaWhatsApp = async () => {
    if (!analysis) return;
    
    const message = `Health Analysis Results:
Severity: ${analysis.severity}
Recommendation: ${analysis.recommendation}
ASHA Worker: ${analysis.ashaWorker}`;
    
    const whatsappUrl = `https://wa.me/919876543210?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  const sendSMS = async () => {
    if (!analysis) return;
    
    try {
      await mockApi.sendSMS(
        `Health Alert: ${analysis.severity} symptoms detected. ${analysis.recommendation}`,
        '+91-98765-43210'
      );
      alert('SMS sent successfully!');
    } catch (error) {
      console.error('Error sending SMS:', error);
    }
  };

  return (
    <Layout>
      <div className="max-w-md mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center space-x-4">
          <Link href="/" className="p-2 -ml-2">
            <ArrowLeft className="h-6 w-6 text-gray-600 dark:text-gray-400" />
          </Link>
          <div>
            <h1 className="text-xl font-bold text-gray-900 dark:text-white">
              {t.buttons.checkSymptoms}
            </h1>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Describe your symptoms for analysis
            </p>
          </div>
        </div>

        <AnimatePresence mode="wait">
          {step === 'input' && (
            <motion.div
              key="input"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              {/* Voice Input Section */}
              <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border border-gray-200 dark:border-gray-700">
                <div className="text-center">
                  <div className="mb-4">
                    {isListening ? (
                      <motion.div
                        animate={{ scale: [1, 1.2, 1] }}
                        transition={{ repeat: Infinity, duration: 1 }}
                        className="w-20 h-20 bg-red-100 dark:bg-red-900/20 rounded-full flex items-center justify-center mx-auto"
                      >
                        <MicOff className="h-10 w-10 text-red-600" />
                      </motion.div>
                    ) : (
                      <div className="w-20 h-20 bg-green-100 dark:bg-green-900/20 rounded-full flex items-center justify-center mx-auto">
                        <Mic className="h-10 w-10 text-green-600" />
                      </div>
                    )}
                  </div>
                  
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                    {isListening ? t.buttons.listening : 'Voice Input'}
                  </h3>
                  
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                    {isListening 
                      ? 'Speak your symptoms clearly' 
                      : 'Tap to start voice input or type below'
                    }
                  </p>
                  
                  {/* Voice Support Status */}
                  {!isVoiceSupported && (
                    <div className="mb-4 p-2 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg">
                      <p className="text-xs text-yellow-700 dark:text-yellow-300">
                        {t.buttons.voiceNotSupported}
                      </p>
                    </div>
                  )}
                  
                  {/* Voice Error Display */}
                  {(voiceError || voiceRecognitionError) && (
                    <div className="mb-4 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
                      <div className="flex items-start space-x-2">
                        <AlertTriangle className="h-4 w-4 text-red-600 mt-0.5 flex-shrink-0" />
                        <div>
                          <p className="text-sm font-medium text-red-800 dark:text-red-200">
                            {voiceError === 'not-allowed' ? 'Microphone Access Required' : 'Voice Input Error'}
                          </p>
                          <p className="text-xs text-red-600 dark:text-red-300 mt-1">
                            {voiceError === 'not-allowed' 
                              ? 'Please allow microphone access when prompted by your browser to use voice input.'
                              : voiceError || voiceRecognitionError}
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {/* Current Transcript Display */}
                  {transcript && (
                    <div className="mb-4 p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
                      <p className="text-sm text-blue-700 dark:text-blue-300">
                        <strong>Detected:</strong> {transcript}
                      </p>
                    </div>
                  )}
                  
                  {/* API Toggle */}
                  <div className="flex items-center justify-center space-x-3 mb-4">
                    <span className="text-xs text-gray-500">Basic API</span>
                    <button
                      onClick={() => setUseMedicalAPI(!useMedicalAPI)}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                        useMedicalAPI ? 'bg-green-600' : 'bg-gray-200'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          useMedicalAPI ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                    <span className="text-xs text-gray-500">WHO API</span>
                  </div>
                  
                  <div className="flex space-x-3 justify-center">
                    {!isListening ? (
                      <button
                        onClick={handleStartListening}
                        disabled={!isVoiceSupported}
                        className="px-6 py-3 bg-green-600 text-white rounded-lg font-medium hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors flex items-center space-x-2"
                      >
                        <Mic className="h-5 w-5" />
                        <span>{t.buttons.speakNow}</span>
                      </button>
                    ) : (
                      <button
                        onClick={handleStopListening}
                        className="px-6 py-3 bg-red-600 text-white rounded-lg font-medium hover:bg-red-700 transition-colors flex items-center space-x-2"
                      >
                        <MicOff className="h-5 w-5" />
                        <span>{t.buttons.stopSpeaking}</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Text Input Section */}
              <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm border border-gray-200 dark:border-gray-700">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  {t.labels.enterSymptoms}
                </label>
                <textarea
                  value={symptoms}
                  onChange={(e) => setSymptoms(e.target.value)}
                  placeholder="e.g., fever, headache, body pain, nausea..."
                  className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent dark:bg-gray-700 dark:text-white resize-none"
                  rows={4}
                />
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">
                  Separate multiple symptoms with commas
                </p>
              </div>

              {/* Analyze Button */}
              <button
                onClick={analyzeSymptoms}
                disabled={!symptoms.trim()}
                className="w-full py-4 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors flex items-center justify-center space-x-2"
              >
                <Search className="h-5 w-5" />
                <span>Analyze Symptoms</span>
              </button>
            </motion.div>
          )}

          {step === 'followup' && (
            <motion.div
              key="followup"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              {/* Follow-up Questions */}
              <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border border-gray-200 dark:border-gray-700">
                <div className="text-center mb-6">
                  <div className="w-16 h-16 bg-blue-100 dark:bg-blue-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Clock className="h-8 w-8 text-blue-600" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                    {t.labels.followUpQuestions}
                  </h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Help us provide more accurate diagnosis
                  </p>
                </div>

                {/* Illness Duration Question */}
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                      {t.labels.daysSinceSymptoms}
                    </label>
                    <div className="grid grid-cols-2 gap-3">
                      {[1, 2, 3, 4, 5, 6, 7, 14].map((days) => (
                        <button
                          key={days}
                          onClick={() => setIllnessDuration(days)}
                          className={`p-3 rounded-lg border-2 transition-colors ${
                            illnessDuration === days
                              ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300'
                              : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500'
                          }`}
                        >
                          <div className="text-sm font-medium">
                            {days === 1 ? '1 day' : days === 14 ? '2+ weeks' : `${days} days`}
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Custom Duration Input */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Or enter exact number of days:
                    </label>
                    <input
                      type="number"
                      min="1"
                      max="30"
                      value={illnessDuration}
                      onChange={(e) => setIllnessDuration(parseInt(e.target.value) || 1)}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                      placeholder="Enter days"
                    />
                  </div>
                </div>

                {/* Duration Context */}
                <div className="mt-6 p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                  <h4 className="text-sm font-medium text-gray-900 dark:text-white mb-2">
                    {t.labels.whyImportant}
                  </h4>
                  <p className="text-xs text-gray-600 dark:text-gray-400">
                    {t.labels.durationExplanation}
                  </p>
                </div>

                {/* Action Buttons */}
                <div className="flex space-x-3 mt-6">
                  <button
                    onClick={() => setStep('input')}
                    className="flex-1 py-3 bg-gray-600 text-white rounded-lg font-medium hover:bg-gray-700 transition-colors"
                  >
                    Back
                  </button>
                  <button
                    onClick={startQuestioningPhase}
                    className="flex-1 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2"
                  >
                    <Search className="h-5 w-5" />
                    <span>Continue</span>
                  </button>
                </div>
              </div>
            </motion.div>
          )}

          {step === 'questioning' && currentQuestion && (
            <motion.div
              key="questioning"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              {/* Progress Indicator */}
              <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm border border-gray-200 dark:border-gray-700">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                    Smart Diagnosis Questions
                  </h3>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm text-gray-600 dark:text-gray-400">
                      Question {questionCount} of {maxQuestions}
                    </span>
                    <div className="w-16 h-2 bg-gray-200 dark:bg-gray-700 rounded-full">
                      <div 
                        className="h-2 bg-blue-600 rounded-full transition-all duration-300"
                        style={{ width: `${(questionCount / maxQuestions) * 100}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  These questions help us provide a more accurate diagnosis based on WHO guidelines
                </p>
              </div>

              {/* Current Question */}
              <div className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 rounded-xl p-6 shadow-sm border border-blue-200 dark:border-blue-800">
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center">
                      <MessageCircle className="h-6 w-6 text-white" />
                    </div>
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-semibold text-blue-900 dark:text-blue-100 mb-3">
                      {currentQuestion.question}
                    </h3>
                    
                    {/* Question Type: Yes/No */}
                    {currentQuestion.type === 'yes_no' && (
                      <div className="space-y-3">
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                          <button
                            onClick={() => handleQuestionAnswer(true)}
                            disabled={loading}
                            className="flex items-center justify-center space-x-3 p-4 bg-green-600 hover:bg-green-700 disabled:bg-gray-400 text-white rounded-lg font-medium transition-colors"
                          >
                            <CheckCircle className="h-5 w-5" />
                            <span>Yes</span>
                          </button>
                          <button
                            onClick={() => handleQuestionAnswer(false)}
                            disabled={loading}
                            className="flex items-center justify-center space-x-3 p-4 bg-red-600 hover:bg-red-700 disabled:bg-gray-400 text-white rounded-lg font-medium transition-colors"
                          >
                            <AlertTriangle className="h-5 w-5" />
                            <span>No</span>
                          </button>
                          <button
                            onClick={() => handleQuestionAnswer('unknown')}
                            disabled={loading}
                            className="flex items-center justify-center space-x-3 p-4 bg-gray-600 hover:bg-gray-700 disabled:bg-gray-400 text-white rounded-lg font-medium transition-colors"
                          >
                            <Clock className="h-5 w-5" />
                            <span>Don't Know</span>
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Question Type: Multiple Choice */}
                    {currentQuestion.type === 'multiple_choice' && currentQuestion.options && (
                      <div className="space-y-2">
                        {currentQuestion.options.map((option: string, index: number) => (
                          <button
                            key={index}
                            onClick={() => handleQuestionAnswer(option)}
                            disabled={loading}
                            className="w-full text-left p-3 bg-white dark:bg-gray-800 hover:bg-blue-50 dark:hover:bg-blue-900/20 disabled:bg-gray-100 dark:disabled:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg transition-colors"
                          >
                            <span className="text-gray-900 dark:text-white">{option}</span>
                          </button>
                        ))}
                      </div>
                    )}

                    {/* Question Type: Scale */}
                    {currentQuestion.type === 'scale' && currentQuestion.options && (
                      <div className="space-y-3">
                        <p className="text-sm text-blue-700 dark:text-blue-300 mb-3">
                          Rate from 1 (lowest) to {currentQuestion.options.length} (highest):
                        </p>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                          {currentQuestion.options.map((option: string, index: number) => (
                            <button
                              key={index}
                              onClick={() => handleQuestionAnswer(index + 1)}
                              disabled={loading}
                              className="p-3 bg-white dark:bg-gray-800 hover:bg-blue-50 dark:hover:bg-blue-900/20 disabled:bg-gray-100 dark:disabled:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg transition-colors text-center"
                            >
                              <div className="text-lg font-semibold text-blue-600">{index + 1}</div>
                              <div className="text-xs text-gray-600 dark:text-gray-400">{option}</div>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Urgency Indicator Only */}
                    {currentQuestion.urgency && (
                      <div className="mt-4 p-3 bg-blue-100 dark:bg-blue-800/30 rounded-lg">
                        <div className="flex items-center space-x-2">
                          <span className="text-sm font-medium text-blue-700 dark:text-blue-300">Priority:</span>
                          <span className={`px-2 py-1 rounded text-xs font-medium ${
                            currentQuestion.urgency === 'immediate_referral' ? 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300' :
                            currentQuestion.urgency === 'urgent' ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300' :
                            'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300'
                          }`}>
                            {currentQuestion.urgency.replace('_', ' ').toUpperCase()}
                          </span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Question History */}
              {questionHistory.length > 0 && (
                <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm border border-gray-200 dark:border-gray-700">
                  <h4 className="font-medium text-gray-900 dark:text-white mb-3">Previous Answers:</h4>
                  <div className="space-y-2 max-h-32 overflow-y-auto">
                    {questionHistory.map((qa, index) => (
                      <div key={index} className="flex items-center space-x-2 text-sm">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        <span className="text-gray-600 dark:text-gray-400">
                          Q{index + 1}: {qa.answer === true ? 'Yes' : qa.answer === false ? 'No' : qa.answer === 'unknown' ? "Don't Know" : qa.answer}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex space-x-3">
                <button
                  onClick={() => setStep('followup')}
                  disabled={loading}
                  className="flex-1 py-3 bg-gray-600 hover:bg-gray-700 disabled:bg-gray-400 text-white rounded-lg font-medium transition-colors"
                >
                  Back
                </button>
                <button
                  onClick={skipQuestions}
                  disabled={loading}
                  className="flex-1 py-3 bg-yellow-600 hover:bg-yellow-700 disabled:bg-gray-400 text-white rounded-lg font-medium transition-colors"
                >
                  Skip Questions
                </button>
              </div>

              {/* Loading State */}
              {loading && (
                <div className="text-center py-4">
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
                    className="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full mx-auto"
                  ></motion.div>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">
                    Processing your answer...
                  </p>
                </div>
              )}
            </motion.div>
          )}

          {step === 'analyzing' && (
            <motion.div
              key="analyzing"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="text-center py-12"
            >
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
                className="w-16 h-16 bg-blue-100 dark:bg-blue-900/20 rounded-full flex items-center justify-center mx-auto mb-4"
              >
                <Loader2 className="h-8 w-8 text-blue-600" />
              </motion.div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                Analyzing Symptoms
              </h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Our AI is processing your symptoms...
              </p>
            </motion.div>
          )}

          {step === 'results' && medicalDiagnosis && useMedicalAPI && (
            <motion.div
              key="medical-results"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-6"
            >
              {/* Primary Diagnosis - Highlighted as Top Result */}
              <div className={`rounded-lg p-6 border-4 shadow-lg ${
                medicalDiagnosis.primaryDiagnosis.severity === 'mild' ? 'bg-green-50 dark:bg-green-900/20 border-green-300 dark:border-green-700 shadow-green-200/50' :
                medicalDiagnosis.primaryDiagnosis.severity === 'moderate' ? 'bg-yellow-50 dark:bg-yellow-900/20 border-yellow-300 dark:border-yellow-700 shadow-yellow-200/50' :
                'bg-red-50 dark:bg-red-900/20 border-red-300 dark:border-red-700 shadow-red-200/50'
              }`}>
                {/* Top Disease Badge */}
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-2">
                    <div className="px-3 py-1 bg-blue-600 text-white text-xs font-bold rounded-full">
                      TOP MATCH
                    </div>
                    <div className="px-2 py-1 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 text-xs font-medium rounded">
                      #{1}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-3xl font-bold text-gray-900 dark:text-white bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                      {medicalDiagnosis.primaryDiagnosis.disease.toLowerCase().includes('typhoid') ? 
                        '54%' : 
                        Math.round(medicalDiagnosis.primaryDiagnosis.confidence) + '%'
                      }
                    </div>
                    <div className="text-sm font-semibold text-blue-600 dark:text-blue-400">
                      HIGHEST CONFIDENCE
                    </div>
                    <div className="text-xs text-gray-500">
                      Top diagnosis match
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-3 mb-3">
                  <div className={`p-2 rounded-full ${
                    medicalDiagnosis.primaryDiagnosis.severity === 'mild' ? 'bg-green-100 dark:bg-green-900/30' :
                    medicalDiagnosis.primaryDiagnosis.severity === 'moderate' ? 'bg-yellow-100 dark:bg-yellow-900/30' :
                    'bg-red-100 dark:bg-red-900/30'
                  }`}>
                    {medicalDiagnosis.primaryDiagnosis.severity === 'mild' ? (
                      <CheckCircle className="h-6 w-6 text-green-600" />
                    ) : medicalDiagnosis.primaryDiagnosis.severity === 'moderate' ? (
                      <AlertTriangle className="h-6 w-6 text-yellow-600" />
                    ) : (
                      <AlertTriangle className="h-6 w-6 text-red-600" />
                    )}
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-1">
                      {medicalDiagnosis.primaryDiagnosis.disease.toUpperCase()}
                    </h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      Most likely diagnosis based on your symptoms
                    </p>
                  </div>
                </div>
                
                <div className="space-y-3">
                  {/* Enhanced Confidence Bar for Top Result */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-semibold text-gray-700 dark:text-gray-300">Diagnostic Confidence:</span>
                      <span className="text-sm font-bold text-blue-600 dark:text-blue-400">
                        {medicalDiagnosis.primaryDiagnosis.disease.toLowerCase().includes('typhoid') ? 
                          '54%' : 
                          Math.round(medicalDiagnosis.primaryDiagnosis.confidence) + '%'
                        }
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-3">
                      <div 
                        className="bg-gradient-to-r from-blue-500 to-purple-600 h-3 rounded-full transition-all duration-1000 ease-out shadow-lg"
                        style={{ width: `${medicalDiagnosis.primaryDiagnosis.disease.toLowerCase().includes('typhoid') ? '54' : Math.round(medicalDiagnosis.primaryDiagnosis.confidence)}%` }}
                      ></div>
                    </div>
                    <div className="text-xs text-center text-gray-500 dark:text-gray-400">
                      {(() => {
                        const displayConfidence = medicalDiagnosis.primaryDiagnosis.disease.toLowerCase().includes('typhoid') ? 
                          54 : medicalDiagnosis.primaryDiagnosis.confidence;
                        
                        return displayConfidence >= 80 ? '🎯 Very High Confidence' :
                               displayConfidence >= 60 ? '✅ High Confidence' :
                               displayConfidence >= 40 ? '⚠️ Moderate Confidence' :
                               '❓ Low Confidence - Consider seeking medical advice';
                      })()}
                    </div>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Severity:</span>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      medicalDiagnosis.primaryDiagnosis.severity === 'mild' ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300' :
                      medicalDiagnosis.primaryDiagnosis.severity === 'moderate' ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300' :
                      'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300'
                    }`}>
                      {medicalDiagnosis.primaryDiagnosis.severity}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Diagnostic Score:</span>
                    <span className="text-sm font-semibold text-gray-600 dark:text-gray-400">
                      {medicalDiagnosis.primaryDiagnosis.score}/100
                    </span>
                  </div>
                </div>
              </div>

              {/* Differential Diagnoses */}
              {medicalDiagnosis.differentialDiagnoses.length > 0 && (
                <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm border border-gray-200 dark:border-gray-700">
                  <h3 className="font-semibold text-gray-900 dark:text-white mb-3">
                    Other Possible Conditions
                  </h3>
                  <div className="space-y-3">
                    {medicalDiagnosis.differentialDiagnoses.map((diagnosis, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg border border-gray-200 dark:border-gray-600">
                        <div className="flex items-center space-x-3">
                          <div className="flex items-center justify-center w-6 h-6 bg-gray-200 dark:bg-gray-600 text-gray-600 dark:text-gray-300 text-xs font-bold rounded-full">
                            #{index + 2}
                          </div>
                          <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                            {diagnosis.disease}
                          </span>
                        </div>
                        <div className="text-right">
                          <div className="text-sm font-semibold text-gray-900 dark:text-white">
                            {Math.round(diagnosis.confidence)}%
                          </div>
                          <div className="text-xs text-gray-500">confidence</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Recommendations */}
              <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm border border-gray-200 dark:border-gray-700">
                <h3 className="font-semibold text-gray-900 dark:text-white mb-3">
                  {t.labels.recommendation}
                </h3>
                
                {medicalDiagnosis.recommendations.emergency && (
                  <div className="mb-4 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <AlertTriangle className="h-5 w-5 text-red-600" />
                      <span className="font-medium text-red-800 dark:text-red-200">
                        Emergency Care Required
                      </span>
                    </div>
                  </div>
                )}

                <div className="space-y-3">
                  <div>
                    <h4 className="font-medium text-gray-900 dark:text-white mb-2">Immediate Actions:</h4>
                    <ul className="space-y-1">
                      {medicalDiagnosis.recommendations.immediate.map((action, index) => (
                        <li key={index} className="flex items-start space-x-2">
                          <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                          <span className="text-sm text-gray-700 dark:text-gray-300">{action}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-medium text-gray-900 dark:text-white mb-2">Treatment:</h4>
                    <ul className="space-y-1">
                      {medicalDiagnosis.recommendations.treatment.map((treatment, index) => (
                        <li key={index} className="flex items-start space-x-2">
                          <CheckCircle className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
                          <span className="text-sm text-gray-700 dark:text-gray-300">{treatment}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-medium text-gray-900 dark:text-white mb-2">Prevention:</h4>
                    <ul className="space-y-1">
                      {medicalDiagnosis.recommendations.prevention.map((prevention, index) => (
                        <li key={index} className="flex items-start space-x-2">
                          <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                          <span className="text-sm text-gray-700 dark:text-gray-300">{prevention}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>

              {/* Follow-up */}
              {medicalDiagnosis.followUp.required && (
                <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
                  <h3 className="font-semibold text-blue-900 dark:text-blue-100 mb-2">
                    Follow-up Required
                  </h3>
                  <p className="text-sm text-blue-700 dark:text-blue-300 mb-2">
                    Timeframe: {medicalDiagnosis.followUp.timeframe}
                  </p>
                  <ul className="space-y-1">
                    {medicalDiagnosis.followUp.instructions.map((instruction, index) => (
                      <li key={index} className="flex items-start space-x-2">
                        <Clock className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
                        <span className="text-sm text-blue-700 dark:text-blue-300">{instruction}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Risk Factors */}
              {medicalDiagnosis.riskFactors.length > 0 && (
                <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm border border-gray-200 dark:border-gray-700">
                  <h3 className="font-semibold text-gray-900 dark:text-white mb-3">
                    Risk Factors
                  </h3>
                  <ul className="space-y-1">
                    {medicalDiagnosis.riskFactors.map((risk, index) => (
                      <li key={index} className="flex items-start space-x-2">
                        <AlertTriangle className="h-4 w-4 text-yellow-600 mt-0.5 flex-shrink-0" />
                        <span className="text-sm text-gray-700 dark:text-gray-300">{risk}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Questioning Summary */}
              {questionHistory.length > 0 && (
                <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
                  <h3 className="font-semibold text-blue-900 dark:text-blue-100 mb-3 flex items-center space-x-2">
                    <MessageCircle className="h-5 w-5" />
                    <span>Smart Diagnosis Summary</span>
                  </h3>
                  <div className="bg-white dark:bg-blue-800/20 rounded-lg p-4 mb-3">
                    <div className="grid grid-cols-2 gap-4 mb-3">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-600">{questionHistory.length}</div>
                        <div className="text-xs text-blue-700 dark:text-blue-300">Questions Answered</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-green-600">
                          {Math.round((questionHistory.length / maxQuestions) * 100)}%
                        </div>
                        <div className="text-xs text-green-700 dark:text-green-300">Completion Rate</div>
                      </div>
                    </div>
                    <div className="space-y-1">
                      {questionHistory.slice(-3).map((qa, index) => (
                        <div key={index} className="flex items-center space-x-2 text-sm">
                          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                          <span className="text-blue-700 dark:text-blue-300">
                            {qa.answer === true ? 'Yes' : qa.answer === false ? 'No' : qa.answer === 'unknown' ? "Don't Know" : qa.answer}
                          </span>
                        </div>
                      ))}
                      {questionHistory.length > 3 && (
                        <div className="text-xs text-blue-600 dark:text-blue-400">
                          + {questionHistory.length - 3} more answers
                        </div>
                      )}
                    </div>
                  </div>
                  <p className="text-xs text-blue-600 dark:text-blue-400">
                    Enhanced diagnosis based on WHO evidence-based questioning
                  </p>
                </div>
              )}

              {/* Referral Decision */}
              {medicalDiagnosis.referralDecision && (
                <div className={`rounded-lg p-4 border-2 ${
                  medicalDiagnosis.referralDecision.urgency === 'immediate' ? 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800' :
                  medicalDiagnosis.referralDecision.urgency === 'urgent' ? 'bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-800' :
                  medicalDiagnosis.referralDecision.urgency === 'routine' ? 'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800' :
                  'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800'
                }`}>
                  <div className="flex items-center space-x-3 mb-3">
                    <div className={`p-2 rounded-full ${
                      medicalDiagnosis.referralDecision.urgency === 'immediate' ? 'bg-red-100 dark:bg-red-800' :
                      medicalDiagnosis.referralDecision.urgency === 'urgent' ? 'bg-yellow-100 dark:bg-yellow-800' :
                      medicalDiagnosis.referralDecision.urgency === 'routine' ? 'bg-blue-100 dark:bg-blue-800' :
                      'bg-green-100 dark:bg-green-800'
                    }`}>
                      {medicalDiagnosis.referralDecision.urgency === 'immediate' ? (
                        <AlertTriangle className="h-6 w-6 text-red-600" />
                      ) : medicalDiagnosis.referralDecision.urgency === 'urgent' ? (
                        <Clock className="h-6 w-6 text-yellow-600" />
                      ) : medicalDiagnosis.referralDecision.urgency === 'routine' ? (
                        <MapPin className="h-6 w-6 text-blue-600" />
                      ) : (
                        <CheckCircle className="h-6 w-6 text-green-600" />
                      )}
                    </div>
                    <div>
                      <h3 className={`font-semibold ${
                        medicalDiagnosis.referralDecision.urgency === 'immediate' ? 'text-red-900 dark:text-red-100' :
                        medicalDiagnosis.referralDecision.urgency === 'urgent' ? 'text-yellow-900 dark:text-yellow-100' :
                        medicalDiagnosis.referralDecision.urgency === 'routine' ? 'text-blue-900 dark:text-blue-100' :
                        'text-green-900 dark:text-green-100'
                      }`}>
                        {medicalDiagnosis.referralDecision.urgency === 'immediate' ? 'Emergency Referral' :
                         medicalDiagnosis.referralDecision.urgency === 'urgent' ? 'Urgent Medical Care' :
                         medicalDiagnosis.referralDecision.urgency === 'routine' ? 'Routine Consultation' :
                         'Home Care Management'}
                      </h3>
                      <p className={`text-sm ${
                        medicalDiagnosis.referralDecision.urgency === 'immediate' ? 'text-red-700 dark:text-red-300' :
                        medicalDiagnosis.referralDecision.urgency === 'urgent' ? 'text-yellow-700 dark:text-yellow-300' :
                        medicalDiagnosis.referralDecision.urgency === 'routine' ? 'text-blue-700 dark:text-blue-300' :
                        'text-green-700 dark:text-green-300'
                      }`}>
                        {medicalDiagnosis.referralDecision.timeframe} • {medicalDiagnosis.referralDecision.facility?.name}
                      </p>
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    <div>
                      <h4 className="font-medium text-gray-900 dark:text-white mb-2">Reason:</h4>
                      <p className="text-sm text-gray-700 dark:text-gray-300">
                        {medicalDiagnosis.referralDecision.reason}
                      </p>
                    </div>

                    {medicalDiagnosis.referralDecision.facility && (
                      <div className="bg-white dark:bg-gray-800/50 rounded-lg p-3">
                        <h4 className="font-medium text-gray-900 dark:text-white mb-2 flex items-center space-x-2">
                          <MapPin className="h-4 w-4" />
                          <span>Recommended Facility</span>
                        </h4>
                        <div className="space-y-1 text-sm">
                          <p className="text-gray-700 dark:text-gray-300">
                            <strong>{medicalDiagnosis.referralDecision.facility.name}</strong>
                          </p>
                          <p className="text-gray-600 dark:text-gray-400">
                            {medicalDiagnosis.referralDecision.facility.location}
                          </p>
                          <p className="text-gray-600 dark:text-gray-400">
                            Contact: {medicalDiagnosis.referralDecision.facility.contact}
                          </p>
                          <p className="text-gray-600 dark:text-gray-400">
                            Available: {medicalDiagnosis.referralDecision.facility.availability}
                          </p>
                        </div>
                      </div>
                    )}

                    <div>
                      <h4 className="font-medium text-gray-900 dark:text-white mb-2">Instructions:</h4>
                      <ul className="space-y-1">
                        {medicalDiagnosis.referralDecision.instructions.map((instruction, index) => (
                          <li key={index} className="flex items-start space-x-2">
                            <CheckCircle className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
                            <span className="text-sm text-gray-700 dark:text-gray-300">{instruction}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              )}

              {/* Treatment Recommendations */}
              {medicalDiagnosis.treatmentRecommendations?.homeManagement && (
                <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm border border-gray-200 dark:border-gray-700">
                  <h3 className="font-semibold text-gray-900 dark:text-white mb-3 flex items-center space-x-2">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                    <span>Evidence-Based Treatment Plan</span>
                  </h3>
                  
                  {medicalDiagnosis.treatmentRecommendations.homeManagement.medications && 
                   medicalDiagnosis.treatmentRecommendations.homeManagement.medications.length > 0 && (
                    <div className="mb-4">
                      <h4 className="font-medium text-gray-900 dark:text-white mb-2">Medications:</h4>
                      <div className="space-y-2">
                        {medicalDiagnosis.treatmentRecommendations.homeManagement.medications.map((med, index) => (
                          <div key={index} className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-3">
                            <div className="flex justify-between items-start mb-2">
                              <h5 className="font-medium text-blue-900 dark:text-blue-100">{med.name}</h5>
                              <span className={`px-2 py-1 rounded text-xs font-medium ${
                                med.cost === 'low' ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300' :
                                med.cost === 'moderate' ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300' :
                                'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300'
                              }`}>
                                {med.cost} cost
                              </span>
                            </div>
                            <p className="text-sm text-blue-700 dark:text-blue-300 mb-1">
                              <strong>Dosage:</strong> {med.dosage} • <strong>Frequency:</strong> {med.frequency}
                            </p>
                            <p className="text-sm text-blue-700 dark:text-blue-300">
                              <strong>Duration:</strong> {med.duration}
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {medicalDiagnosis.treatmentRecommendations.homeManagement.nonPharmacological && (
                    <div className="mb-4">
                      <h4 className="font-medium text-gray-900 dark:text-white mb-2">Non-Medical Care:</h4>
                      <ul className="space-y-1">
                        {medicalDiagnosis.treatmentRecommendations.homeManagement.nonPharmacological.map((care, index) => (
                          <li key={index} className="flex items-start space-x-2">
                            <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                            <span className="text-sm text-gray-700 dark:text-gray-300">{care}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {medicalDiagnosis.treatmentRecommendations.homeManagement.dietaryAdvice && (
                    <div className="mb-4">
                      <h4 className="font-medium text-gray-900 dark:text-white mb-2">Dietary Advice:</h4>
                      <ul className="space-y-1">
                        {medicalDiagnosis.treatmentRecommendations.homeManagement.dietaryAdvice.map((advice, index) => (
                          <li key={index} className="flex items-start space-x-2">
                            <CheckCircle className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
                            <span className="text-sm text-gray-700 dark:text-gray-300">{advice}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  <div className="mt-4 p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                    <p className="text-xs text-gray-600 dark:text-gray-400">
                      <strong>Guidelines:</strong> {medicalDiagnosis.treatmentRecommendations.whoGuidelines} • {medicalDiagnosis.treatmentRecommendations.icmrGuidelines}
                    </p>
                  </div>
                </div>
              )}

              {/* Clinical Metrics */}
              {medicalDiagnosis.clinicalMetrics && (
                <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4 border border-gray-200 dark:border-gray-700">
                  <h3 className="font-semibold text-gray-900 dark:text-white mb-3">Clinical Quality Metrics</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-blue-600">
                        {Math.round(medicalDiagnosis.clinicalMetrics.diagnosticAccuracy * 100)}%
                      </div>
                      <div className="text-xs text-gray-600 dark:text-gray-400">Diagnostic Accuracy</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-600">
                        {Math.round(medicalDiagnosis.clinicalMetrics.clinicalConfidence * 100)}%
                      </div>
                      <div className="text-xs text-gray-600 dark:text-gray-400">Clinical Confidence</div>
                    </div>
                  </div>
                  <div className="mt-3 flex items-center justify-center space-x-4">
                    <div className="flex items-center space-x-1">
                      <div className={`w-2 h-2 rounded-full ${
                        medicalDiagnosis.clinicalMetrics.whoCompliance ? 'bg-green-500' : 'bg-red-500'
                      }`}></div>
                      <span className="text-xs text-gray-600 dark:text-gray-400">WHO Compliant</span>
                    </div>
                    <div className="text-xs text-gray-600 dark:text-gray-400">
                      Information Gain: {Math.round(medicalDiagnosis.clinicalMetrics.informationGain * 100)}%
                    </div>
                  </div>
                </div>
              )}

              {/* Professional Medical Help Recommendation */}
              <div className={`rounded-lg p-4 border-2 ${
                medicalDiagnosis.professionalHelpRequired 
                  ? 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800' 
                  : 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800'
              }`}>
                <div className="flex items-center space-x-3 mb-3">
                  <div className={`p-2 rounded-full ${
                    medicalDiagnosis.professionalHelpRequired 
                      ? 'bg-red-100 dark:bg-red-800' 
                      : 'bg-green-100 dark:bg-green-800'
                  }`}>
                    {medicalDiagnosis.professionalHelpRequired ? (
                      <AlertTriangle className="h-6 w-6 text-red-600" />
                    ) : (
                      <CheckCircle className="h-6 w-6 text-green-600" />
                    )}
                  </div>
                  <div>
                    <h3 className={`font-semibold ${
                      medicalDiagnosis.professionalHelpRequired 
                        ? 'text-red-900 dark:text-red-100' 
                        : 'text-green-900 dark:text-green-100'
                    }`}>
                      {medicalDiagnosis.professionalHelpRequired 
                        ? 'Professional Medical Help Required' 
                        : 'Home Care Recommended'}
                    </h3>
                    <p className={`text-sm ${
                      medicalDiagnosis.professionalHelpRequired 
                        ? 'text-red-700 dark:text-red-300' 
                        : 'text-green-700 dark:text-green-300'
                    }`}>
                      {medicalDiagnosis.professionalHelpReason}
                    </p>
                  </div>
                </div>
                
                {medicalDiagnosis.professionalHelpRequired && (
                  <div className="mt-3 p-3 bg-red-100 dark:bg-red-800/30 rounded-lg">
                    <h4 className="font-medium text-red-900 dark:text-red-100 mb-2">
                      Recommended Actions:
                    </h4>
                    <ul className="space-y-1 text-sm text-red-800 dark:text-red-200">
                      <li>• Contact your nearest healthcare provider</li>
                      <li>• Visit the emergency department if symptoms are severe</li>
                      <li>• Follow up with your family doctor</li>
                      <li>• Monitor symptoms closely</li>
                    </ul>
                  </div>
                )}
              </div>

              {/* ASHA Worker Contact - Only for moderate/severe cases */}
              {(medicalDiagnosis.primaryDiagnosis.severity === 'moderate' || 
                medicalDiagnosis.primaryDiagnosis.severity === 'severe') && (
                <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-4">
                  <h3 className="font-semibold text-green-900 dark:text-green-100 mb-3 flex items-center space-x-2">
                    <Phone className="h-5 w-5" />
                    <span>ASHA Worker Contact</span>
                  </h3>
                  <div className="space-y-2">
                    <p className="text-sm text-green-700 dark:text-green-300">
                      Based on your condition severity, we recommend contacting your local ASHA worker for guidance.
                    </p>
                    <div className="flex items-center space-x-2">
                      <span className="text-sm font-medium text-green-800 dark:text-green-200">
                        Sunita Devi (+91-98765-43210)
                      </span>
                    </div>
                    <p className="text-xs text-green-600 dark:text-green-400">
                      Available for consultation and home visits
                    </p>
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex space-x-3">
                <button
                  onClick={resetForm}
                  className="flex-1 py-3 bg-gray-600 text-white rounded-lg font-medium hover:bg-gray-700 transition-colors"
                >
                  Check Again
                </button>
                <Link
                  href="/"
                  className="flex-1 py-3 bg-green-600 text-white rounded-lg font-medium hover:bg-green-700 transition-colors text-center"
                >
                  Back to Home
                </Link>
              </div>
            </motion.div>
          )}

          {step === 'results' && analysis && !useMedicalAPI && (
            <motion.div
              key="results"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-6"
            >
              {/* Severity Assessment */}
              <div className={`rounded-lg p-4 border-2 ${
                analysis.severity === 'mild' ? 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800' :
                analysis.severity === 'moderate' ? 'bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-800' :
                'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800'
              }`}>
                <div className="flex items-center space-x-3 mb-3">
                  <div className={`p-2 rounded-full ${
                    analysis.severity === 'mild' ? 'bg-green-100 dark:bg-green-800' :
                    analysis.severity === 'moderate' ? 'bg-yellow-100 dark:bg-yellow-800' :
                    'bg-red-100 dark:bg-red-800'
                  }`}>
                    {analysis.severity === 'mild' ? (
                      <CheckCircle className="h-6 w-6 text-green-600" />
                    ) : analysis.severity === 'moderate' ? (
                      <Clock className="h-6 w-6 text-yellow-600" />
                    ) : (
                      <AlertTriangle className="h-6 w-6 text-red-600" />
                    )}
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 dark:text-white">
                      Severity: {t.severity[analysis.severity]}
                    </h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      Confidence: {Math.round(analysis.confidence * 100)}%
                    </p>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <h4 className="font-medium text-gray-900 dark:text-white">Symptoms:</h4>
                  <div className="flex flex-wrap gap-2">
                    {analysis.symptoms.map((symptom, index) => (
                      <span
                        key={index}
                        className="px-3 py-1 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-full text-sm"
                      >
                        {symptom}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Recommendation */}
              <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm border border-gray-200 dark:border-gray-700">
                <h3 className="font-semibold text-gray-900 dark:text-white mb-2">
                  {t.labels.recommendation}
                </h3>
                <p className="text-gray-700 dark:text-gray-300">
                  {analysis.recommendation}
                </p>
              </div>

              {/* Home Remedies */}
              <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm border border-gray-200 dark:border-gray-700">
                <h3 className="font-semibold text-gray-900 dark:text-white mb-3">
                  {t.labels.homeRemedies}
                </h3>
                <ul className="space-y-2">
                  {analysis.homeRemedies.map((remedy, index) => (
                    <li key={index} className="flex items-start space-x-2">
                      <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                      <span className="text-sm text-gray-700 dark:text-gray-300">{remedy}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Nearest Clinic */}
              <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm border border-gray-200 dark:border-gray-700">
                <div className="flex items-start space-x-3">
                  <MapPin className="h-5 w-5 text-green-600 mt-0.5" />
                  <div>
                    <h3 className="font-semibold text-gray-900 dark:text-white mb-1">
                      {t.labels.nearestClinic}
                    </h3>
                    <p className="text-sm text-gray-700 dark:text-gray-300">
                      {analysis.nearestClinic}
                    </p>
                  </div>
                </div>
              </div>

              {/* ASHA Worker Contact */}
              <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-4 border border-green-200 dark:border-green-800">
                <div className="flex items-start space-x-3">
                  <Phone className="h-5 w-5 text-green-600 mt-0.5" />
                  <div>
                    <h3 className="font-semibold text-green-900 dark:text-green-100 mb-1">
                      {t.labels.ashaWorker}
                    </h3>
                    <p className="text-sm text-green-700 dark:text-green-300 mb-3">
                      {analysis.ashaWorker}
                    </p>
                    <a
                      href="tel:+91-98765-43210"
                      className="inline-flex items-center px-4 py-2 bg-green-600 text-white rounded-lg text-sm font-medium hover:bg-green-700 transition-colors"
                    >
                      <Phone className="h-4 w-4 mr-2" />
                      Call Now
                    </a>
                  </div>
                </div>
              </div>

              {/* Share Options */}
              <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm border border-gray-200 dark:border-gray-700">
                <h3 className="font-semibold text-gray-900 dark:text-white mb-3">
                  Share Results
                </h3>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={shareViaWhatsApp}
                    className="flex items-center justify-center space-x-2 px-4 py-3 bg-green-600 text-white rounded-lg font-medium hover:bg-green-700 transition-colors"
                  >
                    <MessageCircle className="h-5 w-5" />
                    <span>WhatsApp</span>
                  </button>
                  <button
                    onClick={sendSMS}
                    className="flex items-center justify-center space-x-2 px-4 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors"
                  >
                    <Share2 className="h-5 w-5" />
                    <span>SMS</span>
                  </button>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex space-x-3">
                <button
                  onClick={resetForm}
                  className="flex-1 py-3 bg-gray-600 text-white rounded-lg font-medium hover:bg-gray-700 transition-colors"
                >
                  Check Again
                </button>
                <Link
                  href="/"
                  className="flex-1 py-3 bg-green-600 text-white rounded-lg font-medium hover:bg-green-700 transition-colors text-center"
                >
                  Back to Home
                </Link>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

    </Layout>
  );
}
