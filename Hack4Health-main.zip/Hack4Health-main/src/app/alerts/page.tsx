'use client';

import React, { useState, useEffect } from 'react';
import Layout from '@/components/Layout';
import { useLanguage } from '@/contexts/LanguageContext';
import { mockApi, OutbreakAlertResponse, apiUtils } from '@/lib/mockApi';
import { 
  AlertTriangle, 
  MapPin, 
  Clock, 
  Share2, 
  MessageCircle,
  ArrowLeft,
  Bell,
  Shield,
  TrendingUp,
  Users,
  Phone
} from 'lucide-react';
import { motion } from 'framer-motion';
import Link from 'next/link';

export default function AlertsPage() {
  const { t, currentLanguage } = useLanguage();
  const [alerts, setAlerts] = useState<OutbreakAlertResponse | null>(null);
  const [locationAlerts, setLocationAlerts] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [userPincode] = useState('751001'); // Mock user pincode

  useEffect(() => {
    const loadAlerts = async () => {
      try {
        // Load general outbreak alerts
        const data = await mockApi.getOutbreakAlerts(userPincode, currentLanguage);
        setAlerts(data);

        // Load location-based alerts
        const locationResponse = await fetch(`/api/location-alerts?pincode=${userPincode}&language=${currentLanguage}`);
        if (locationResponse.ok) {
          const locationData = await locationResponse.json();
          setLocationAlerts(locationData);
        }
      } catch (error) {
        console.error('Error loading alerts:', error);
      } finally {
        setLoading(false);
      }
    };

    loadAlerts();
  }, [userPincode, currentLanguage]);

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'low': return 'text-green-600 bg-green-100 dark:bg-green-900/20';
      case 'moderate': return 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900/20';
      case 'high': return 'text-red-600 bg-red-100 dark:bg-red-900/20';
      default: return 'text-gray-600 bg-gray-100 dark:bg-gray-900/20';
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'low': return '🟢';
      case 'moderate': return '🟡';
      case 'high': return '🔴';
      default: return '⚪';
    }
  };

  const shareAlert = async (alert: any) => {
    const message = `Health Alert - ${alert.disease}:
Severity: ${alert.severity}
Affected Areas: ${alert.affectedAreas.join(', ')}
Recommendation: ${alert.recommendation}
Prevention: ${alert.prevention.join(', ')}`;
    
    const whatsappUrl = `https://wa.me/919876543210?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  const sendSMSAlert = async (alert: any) => {
    try {
      await mockApi.sendSMS(
        `Health Alert: ${alert.disease} outbreak in your area. ${alert.recommendation}`,
        '+91-98765-43210'
      );
      alert('SMS alert sent successfully!');
    } catch (error) {
      console.error('Error sending SMS:', error);
    }
  };

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[50vh]">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="max-w-md mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center space-x-4">
          <Link href="/" className="p-2 -ml-2">
            <ArrowLeft className="h-6 w-6 text-gray-600 dark:text-gray-400" />
          </Link>
          <div>
            <h1 className="text-xl font-bold text-gray-900 dark:text-white">
              {t.navigation.alerts}
            </h1>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Health alerts and outbreak notifications
            </p>
          </div>
        </div>

        {/* User Area Alert */}
        {alerts?.userAreaAlert && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className={`rounded-lg p-4 border-2 ${
              alerts.userAreaAlert.severity === 'low' ? 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800' :
              alerts.userAreaAlert.severity === 'moderate' ? 'bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-800' :
              'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800'
            }`}
          >
            <div className="flex items-start space-x-3">
              <div className="p-2 bg-white dark:bg-gray-800 rounded-full">
                <AlertTriangle className="h-6 w-6 text-orange-600" />
              </div>
              <div className="flex-1">
                <div className="flex items-center space-x-2 mb-2">
                  <h3 className="font-semibold text-gray-900 dark:text-white">
                    Your Area Alert
                  </h3>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getSeverityColor(alerts.userAreaAlert.severity)}`}>
                    {getSeverityIcon(alerts.userAreaAlert.severity)} {alerts.userAreaAlert.severity.toUpperCase()}
                  </span>
                </div>
                <h4 className="font-medium text-gray-900 dark:text-white mb-2">
                  {alerts.userAreaAlert.disease}
                </h4>
                <p className="text-sm text-gray-700 dark:text-gray-300 mb-3">
                  {alerts.userAreaAlert.recommendation}
                </p>
                <div className="flex items-center space-x-2">
                  <div className="flex-1 bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                    <div 
                      className="bg-red-500 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${alerts.userAreaAlert.riskLevel * 10}%` }}
                    ></div>
                  </div>
                  <span className="text-xs text-gray-600 dark:text-gray-400">
                    Risk: {alerts.userAreaAlert.riskLevel}/10
                  </span>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Active Alerts */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm border border-gray-200 dark:border-gray-700"
        >
          <div className="flex items-center space-x-2 mb-4">
            <Bell className="h-5 w-5 text-orange-600" />
            <h2 className="font-semibold text-gray-900 dark:text-white">
              Active Outbreak Alerts
            </h2>
          </div>
          
          <div className="space-y-4">
            {alerts?.activeAlerts.map((alert, index) => (
              <div key={index} className="border border-gray-200 dark:border-gray-700 rounded-lg p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center space-x-2">
                    <h3 className="font-semibold text-gray-900 dark:text-white">
                      {alert.disease}
                    </h3>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getSeverityColor(alert.severity)}`}>
                      {getSeverityIcon(alert.severity)} {alert.severity.toUpperCase()}
                    </span>
                  </div>
                  <div className="flex items-center space-x-1 text-xs text-gray-500 dark:text-gray-400">
                    <Clock className="h-3 w-3" />
                    <span>{apiUtils.getTimeAgo(alert.lastUpdated)}</span>
                  </div>
                </div>
                
                <div className="space-y-3">
                  {/* Affected Areas */}
                  <div>
                    <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Affected Areas:
                    </h4>
                    <div className="flex flex-wrap gap-1">
                      {alert.affectedAreas.map((area, areaIndex) => (
                        <span
                          key={areaIndex}
                          className="px-2 py-1 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded text-xs"
                        >
                          {area}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Recommendation */}
                  <div>
                    <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Recommendation:
                    </h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {alert.recommendation}
                    </p>
                  </div>

                  {/* Symptoms */}
                  <div>
                    <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Symptoms:
                    </h4>
                    <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                      {alert.symptoms.map((symptom, symptomIndex) => (
                        <li key={symptomIndex} className="flex items-center space-x-2">
                          <span className="w-1 h-1 bg-gray-400 rounded-full"></span>
                          <span>{symptom}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Prevention */}
                  <div>
                    <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Prevention:
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {alert.prevention.map((prevention, preventionIndex) => (
                        <span
                          key={preventionIndex}
                          className="px-3 py-1 bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-300 rounded-full text-xs"
                        >
                          {prevention}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Share Actions */}
                  <div className="flex space-x-2 pt-2">
                    <button
                      onClick={() => shareAlert(alert)}
                      className="flex-1 flex items-center justify-center space-x-2 px-3 py-2 bg-green-600 text-white rounded-lg text-sm font-medium hover:bg-green-700 transition-colors"
                    >
                      <MessageCircle className="h-4 w-4" />
                      <span>WhatsApp</span>
                    </button>
                    <button
                      onClick={() => sendSMSAlert(alert)}
                      className="flex-1 flex items-center justify-center space-x-2 px-3 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors"
                    >
                      <Share2 className="h-4 w-4" />
                      <span>SMS</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Prevention Tips */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4 border border-blue-200 dark:border-blue-800"
        >
          <div className="flex items-start space-x-3">
            <Shield className="h-5 w-5 text-blue-600 mt-0.5" />
            <div>
              <h3 className="font-semibold text-blue-900 dark:text-blue-100 mb-2">
                General Prevention Tips
              </h3>
              <ul className="text-sm text-blue-700 dark:text-blue-300 space-y-1">
                <li>• Wash hands frequently with soap and water</li>
                <li>• Use mosquito nets and repellents</li>
                <li>• Avoid stagnant water around your home</li>
                <li>• Keep your surroundings clean</li>
                <li>• Seek medical help if symptoms persist</li>
              </ul>
            </div>
          </div>
        </motion.div>

        {/* Location-Based Disease Alerts */}
        {locationAlerts && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="space-y-4"
          >
            <div className="flex items-center space-x-2 mb-4">
              <MapPin className="h-5 w-5 text-blue-600" />
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
                Location-Based Alerts
              </h2>
            </div>
            
            <div className="text-sm text-gray-600 dark:text-gray-400 mb-4 p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
              <p><strong>Location:</strong> {locationAlerts.location.district}, {locationAlerts.location.state}</p>
              <p><strong>Pincode:</strong> {locationAlerts.location.pincode}</p>
              <p><strong>Current Season:</strong> {locationAlerts.location.currentSeason}</p>
            </div>

            {locationAlerts.alertDetails.map((alert: any, index: number) => (
              <div
                key={index}
                className={`rounded-lg p-4 border-2 ${
                  (alert.severity || 'low') === 'low' ? 'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800' :
                  (alert.severity || 'low') === 'moderate' ? 'bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-800' :
                  'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800'
                }`}
              >
                <div className="flex items-start space-x-3">
                  <div className={`p-2 rounded-full ${
                    (alert.severity || 'low') === 'low' ? 'bg-blue-100 dark:bg-blue-800' :
                    (alert.severity || 'low') === 'moderate' ? 'bg-yellow-100 dark:bg-yellow-800' :
                    'bg-red-100 dark:bg-red-800'
                  }`}>
                    {(alert.severity || 'low') === 'high' ? (
                      <AlertTriangle className="h-5 w-5 text-red-600" />
                    ) : (alert.severity || 'low') === 'moderate' ? (
                      <Shield className="h-5 w-5 text-yellow-600" />
                    ) : (
                      <Bell className="h-5 w-5 text-blue-600" />
                    )}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <h3 className="font-semibold text-gray-900 dark:text-white">
                        {alert.title}
                      </h3>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getSeverityColor(alert.severity || 'low')}`}>
                        {(alert.severity || 'low').toUpperCase()}
                      </span>
                    </div>
                    <p className="text-sm text-gray-700 dark:text-gray-300 mb-3">
                      {alert.message}
                    </p>
                    <div className="mb-3">
                      <h4 className="text-sm font-medium text-gray-900 dark:text-white mb-1">
                        Diseases:
                      </h4>
                      <div className="flex flex-wrap gap-1">
                        {alert.diseases.map((disease: string, idx: number) => (
                          <span
                            key={idx}
                            className="px-2 py-1 bg-gray-100 dark:bg-gray-700 text-xs rounded-full text-gray-700 dark:text-gray-300"
                          >
                            {disease.replace('_', ' ')}
                          </span>
                        ))}
                      </div>
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-gray-900 dark:text-white mb-1">
                        Recommendations:
                      </h4>
                      <ul className="text-xs text-gray-600 dark:text-gray-400 space-y-1">
                        {alert.recommendations.map((rec: string, idx: number) => (
                          <li key={idx}>• {rec}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </motion.div>
        )}

        {/* Emergency Contacts */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm border border-gray-200 dark:border-gray-700"
        >
          <div className="flex items-center space-x-2 mb-3">
            <Phone className="h-5 w-5 text-green-600" />
            <h3 className="font-semibold text-gray-900 dark:text-white">
              Emergency Contacts
            </h3>
          </div>
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600 dark:text-gray-400">Health Emergency</span>
              <a 
                href="tel:108"
                className="text-sm text-red-600 hover:text-red-700 font-medium"
              >
                108
              </a>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600 dark:text-gray-400">ASHA Worker</span>
              <a 
                href="tel:+91-98765-43210"
                className="text-sm text-green-600 hover:text-green-700 font-medium"
              >
                Sunita Devi
              </a>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600 dark:text-gray-400">District Health Office</span>
              <a 
                href="tel:+91-6752-222123"
                className="text-sm text-blue-600 hover:text-blue-700 font-medium"
              >
                Puri DHO
              </a>
            </div>
          </div>
        </motion.div>
      </div>
    </Layout>
  );
}
