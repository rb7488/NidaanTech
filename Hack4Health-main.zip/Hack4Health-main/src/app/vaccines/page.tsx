'use client';

import React, { useState, useEffect } from 'react';
import Layout from '@/components/Layout';
import { useLanguage } from '@/contexts/LanguageContext';
import { mockApi, VaccinationResponse } from '@/lib/mockApi';
import { getNearbyCenters, getASHAWorker } from '@/lib/odishaData';
import { 
  Syringe, 
  Calendar, 
  MapPin, 
  Phone, 
  Clock, 
  Users,
  Plus,
  ArrowLeft,
  Bell,
  Share2,
  MessageCircle,
  CheckCircle,
  AlertCircle
} from 'lucide-react';
import { motion } from 'framer-motion';
import Link from 'next/link';

export default function VaccinesPage() {
  const { t } = useLanguage();
  const [vaccinationData, setVaccinationData] = useState<VaccinationResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [userPincode] = useState('751001'); // Mock user pincode
  const [selectedMember, setSelectedMember] = useState(0);

  useEffect(() => {
    const loadVaccinationData = async () => {
      try {
        const data = await mockApi.getVaccinationSchedule(userPincode, []);
        setVaccinationData(data);
      } catch (error) {
        console.error('Error loading vaccination data:', error);
      } finally {
        setLoading(false);
      }
    };

    loadVaccinationData();
  }, [userPincode]);

  const nearbyCenters = getNearbyCenters(userPincode, 3);
  const ashaWorker = getASHAWorker(userPincode);

  const shareVaccinationReminder = async (member: any) => {
    const message = `Vaccination Reminder:
Name: ${member.name}
Age: ${member.age} years
Due Vaccines: ${member.dueVaccines.join(', ')}
Next Due Date: ${member.nextDueDate}
Vaccination Center: ${vaccinationData?.vaccinationCenter}`;
    
    const whatsappUrl = `https://wa.me/919876543210?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  const sendSMSReminder = async (member: any) => {
    try {
      await mockApi.sendSMS(
        `Vaccination reminder for ${member.name}: ${member.dueVaccines.join(', ')} due on ${member.nextDueDate}`,
        '+91-98765-43210'
      );
      alert('SMS reminder sent successfully!');
    } catch (error) {
      console.error('Error sending SMS:', error);
    }
  };

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[50vh]">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="max-w-md mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center space-x-4">
          <Link href="/" className="p-2 -ml-2">
            <ArrowLeft className="h-6 w-6 text-gray-600 dark:text-gray-400" />
          </Link>
          <div>
            <h1 className="text-xl font-bold text-gray-900 dark:text-white">
              {t.navigation.vaccines}
            </h1>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Track vaccination schedules
            </p>
          </div>
        </div>

        {/* Family Members */}
        {vaccinationData && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm border border-gray-200 dark:border-gray-700"
          >
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-semibold text-gray-900 dark:text-white flex items-center space-x-2">
                <Users className="h-5 w-5" />
                <span>{t.labels.familyMembers}</span>
              </h2>
              <button className="p-2 bg-green-100 dark:bg-green-900/20 text-green-600 rounded-full hover:bg-green-200 dark:hover:bg-green-900/40 transition-colors">
                <Plus className="h-4 w-4" />
              </button>
            </div>
            
            <div className="space-y-3">
              {vaccinationData.familyMembers.map((member, index) => (
                <div
                  key={index}
                  className={`p-3 rounded-lg border-2 cursor-pointer transition-colors ${
                    selectedMember === index
                      ? 'border-green-500 bg-green-50 dark:bg-green-900/20'
                      : 'border-gray-200 dark:border-gray-700 hover:border-green-300'
                  }`}
                  onClick={() => setSelectedMember(index)}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium text-gray-900 dark:text-white">
                        {member.name}
                      </h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        {member.age} years old
                      </p>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center space-x-1 text-orange-600">
                        <AlertCircle className="h-4 w-4" />
                        <span className="text-sm font-medium">
                          {member.dueVaccines.length} due
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Selected Member Details */}
        {vaccinationData && vaccinationData.familyMembers[selectedMember] && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm border border-gray-200 dark:border-gray-700"
          >
            <h2 className="font-semibold text-gray-900 dark:text-white mb-4 flex items-center space-x-2">
              <Syringe className="h-5 w-5" />
              <span>Vaccination Schedule</span>
            </h2>
            
            <div className="space-y-4">
              {/* Due Vaccines */}
              <div>
                <h3 className="font-medium text-gray-900 dark:text-white mb-2">
                  {t.labels.dueVaccines}
                </h3>
                <div className="flex flex-wrap gap-2">
                  {vaccinationData.familyMembers[selectedMember].dueVaccines.map((vaccine, index) => (
                    <span
                      key={index}
                      className="px-3 py-1 bg-orange-100 dark:bg-orange-900/20 text-orange-800 dark:text-orange-300 rounded-full text-sm font-medium"
                    >
                      {vaccine}
                    </span>
                  ))}
                </div>
              </div>

              {/* Next Due Date */}
              <div className="flex items-center space-x-3 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                <Calendar className="h-5 w-5 text-blue-600" />
                <div>
                  <p className="text-sm font-medium text-blue-900 dark:text-blue-100">
                    {t.labels.nextDueDate}
                  </p>
                  <p className="text-sm text-blue-700 dark:text-blue-300">
                    {vaccinationData.familyMembers[selectedMember].nextDueDate}
                  </p>
                </div>
              </div>

              {/* Reminder Actions */}
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => shareVaccinationReminder(vaccinationData.familyMembers[selectedMember])}
                  className="flex items-center justify-center space-x-2 px-4 py-3 bg-green-600 text-white rounded-lg font-medium hover:bg-green-700 transition-colors"
                >
                  <MessageCircle className="h-4 w-4" />
                  <span>WhatsApp</span>
                </button>
                <button
                  onClick={() => sendSMSReminder(vaccinationData.familyMembers[selectedMember])}
                  className="flex items-center justify-center space-x-2 px-4 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors"
                >
                  <Share2 className="h-4 w-4" />
                  <span>SMS</span>
                </button>
              </div>
            </div>
          </motion.div>
        )}

        {/* Vaccination Centers */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm border border-gray-200 dark:border-gray-700"
        >
          <h2 className="font-semibold text-gray-900 dark:text-white mb-4 flex items-center space-x-2">
            <MapPin className="h-5 w-5" />
            <span>Nearby Vaccination Centers</span>
          </h2>
          
          <div className="space-y-3">
            {nearbyCenters.map((center) => (
              <div key={center.id} className="border border-gray-200 dark:border-gray-700 rounded-lg p-3">
                <h3 className="font-medium text-gray-900 dark:text-white mb-1">
                  {center.name}
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                  {center.address}
                </p>
                <div className="flex items-center space-x-4 text-xs text-gray-500 dark:text-gray-400">
                  <div className="flex items-center space-x-1">
                    <Clock className="h-3 w-3" />
                    <span>{center.timings}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Phone className="h-3 w-3" />
                    <span>{center.phone}</span>
                  </div>
                </div>
                <div className="mt-2">
                  <div className="flex flex-wrap gap-1">
                    {center.services.slice(0, 3).map((service, index) => (
                      <span
                        key={index}
                        className="px-2 py-1 bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-300 rounded text-xs"
                      >
                        {service}
                      </span>
                    ))}
                    {center.services.length > 3 && (
                      <span className="px-2 py-1 bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 rounded text-xs">
                        +{center.services.length - 3} more
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* ASHA Worker Contact */}
        {ashaWorker && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-green-50 dark:bg-green-900/20 rounded-lg p-4 border border-green-200 dark:border-green-800"
          >
            <div className="flex items-start space-x-3">
              <div className="p-2 bg-green-100 dark:bg-green-800 rounded-full">
                <Users className="h-5 w-5 text-green-600" />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-green-900 dark:text-green-100 mb-1">
                  {t.labels.ashaWorker}
                </h3>
                <p className="text-sm text-green-700 dark:text-green-300 mb-2">
                  {ashaWorker.name} - {ashaWorker.experience} years experience
                </p>
                <p className="text-sm text-green-700 dark:text-green-300 mb-3">
                  Languages: {ashaWorker.languages.join(', ')}
                </p>
                <a
                  href={`tel:${ashaWorker.phone}`}
                  className="inline-flex items-center px-4 py-2 bg-green-600 text-white rounded-lg text-sm font-medium hover:bg-green-700 transition-colors"
                >
                  <Phone className="h-4 w-4 mr-2" />
                  Call {ashaWorker.name}
                </a>
              </div>
            </div>
          </motion.div>
        )}

        {/* Vaccination Schedule Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4 border border-blue-200 dark:border-blue-800"
        >
          <div className="flex items-start space-x-3">
            <CheckCircle className="h-5 w-5 text-blue-600 mt-0.5" />
            <div>
              <h3 className="font-semibold text-blue-900 dark:text-blue-100 mb-1">
                Vaccination Schedule
              </h3>
              <p className="text-sm text-blue-700 dark:text-blue-300 mb-2">
                Keep your family protected with timely vaccinations. Regular immunization prevents serious diseases.
              </p>
              <ul className="text-xs text-blue-700 dark:text-blue-300 space-y-1">
                <li>• BCG: At birth</li>
                <li>• OPV: 6, 10, 14 weeks</li>
                <li>• DPT: 6, 10, 14 weeks</li>
                <li>• Measles: 9-12 months</li>
              </ul>
            </div>
          </div>
        </motion.div>
      </div>
    </Layout>
  );
}
