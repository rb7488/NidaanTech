'use client';

import React, { useState, useEffect } from 'react';
import Layout from '@/components/Layout';
import { useLanguage } from '@/contexts/LanguageContext';
import { mockApi, OutbreakAlertResponse, HealthTipResponse } from '@/lib/mockApi';
import { 
  Heart, 
  AlertTriangle, 
  Syringe, 
  Search, 
  MapPin, 
  Phone,
  Share2,
  MessageCircle,
  Calendar,
  TrendingUp,
  Shield,
  Users
} from 'lucide-react';
import { motion } from 'framer-motion';
import Link from 'next/link';

export default function Home() {
  const { t, currentLanguage } = useLanguage();
  const [alerts, setAlerts] = useState<OutbreakAlertResponse | null>(null);
  const [healthTips, setHealthTips] = useState<HealthTipResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [userPincode] = useState('751001'); // Mock user pincode

  useEffect(() => {
    const loadData = async () => {
      try {
        const [alertsData, tipsData] = await Promise.all([
          mockApi.getOutbreakAlerts(userPincode, currentLanguage),
          mockApi.getHealthTips(userPincode, currentLanguage)
        ]);
        setAlerts(alertsData);
        setHealthTips(tipsData);
      } catch (error) {
        console.error('Error loading data:', error);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [userPincode, currentLanguage]);

  const quickActions = [
    {
      title: t.buttons.checkSymptoms,
      icon: Search,
      href: '/symptoms',
      color: 'bg-blue-500 hover:bg-blue-600',
      description: 'Check your symptoms'
    },
    {
      title: t.navigation.vaccines,
      icon: Syringe,
      href: '/vaccines',
      color: 'bg-green-500 hover:bg-green-600',
      description: 'Vaccination schedule'
    },
    {
      title: t.buttons.emergencyContact,
      icon: Phone,
      href: 'tel:+91-98765-43210',
      color: 'bg-red-500 hover:bg-red-600',
      description: 'Emergency contact'
    },
    {
      title: t.navigation.alerts,
      icon: AlertTriangle,
      href: '/alerts',
      color: 'bg-orange-500 hover:bg-orange-600',
      description: 'Health alerts'
    }
  ];

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[50vh]">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="max-w-md mx-auto space-y-6">
        {/* Welcome Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center py-6"
        >
          <div className="flex items-center justify-center mb-4">
            <Heart className="h-12 w-12 text-green-600" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
            {t.messages.welcomeMessage}
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Your health companion for rural Odisha
          </p>
        </motion.div>

        {/* Current Location */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm border border-gray-200 dark:border-gray-700"
        >
          <div className="flex items-center space-x-3">
            <MapPin className="h-5 w-5 text-green-600" />
            <div>
              <p className="text-sm font-medium text-gray-900 dark:text-white">
                {t.labels.currentLocation}
              </p>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Puri, Odisha (751001)
              </p>
            </div>
          </div>
        </motion.div>

        {/* Active Alerts */}
        {alerts?.userAreaAlert && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4"
          >
            <div className="flex items-start space-x-3">
              <AlertTriangle className="h-5 w-5 text-red-600 mt-0.5" />
              <div className="flex-1">
                <h3 className="font-semibold text-red-900 dark:text-red-100 mb-1">
                  {alerts.userAreaAlert.disease} Alert
                </h3>
                <p className="text-sm text-red-700 dark:text-red-300 mb-2">
                  {alerts.userAreaAlert.recommendation}
                </p>
                <div className="flex space-x-2">
                  <button className="text-xs bg-red-100 dark:bg-red-800 text-red-800 dark:text-red-200 px-3 py-1 rounded-full">
                    Risk Level: {alerts.userAreaAlert.riskLevel}/10
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Quick Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="grid grid-cols-2 gap-4"
        >
          {quickActions.map((action, index) => {
            const Icon = action.icon;
            return (
              <Link
                key={action.href}
                href={action.href}
                className="block"
              >
                <motion.div
                  whileTap={{ scale: 0.95 }}
                  className={`${action.color} text-white rounded-lg p-4 text-center transition-colors`}
                >
                  <Icon className="h-8 w-8 mx-auto mb-2" />
                  <h3 className="font-semibold text-sm mb-1">{action.title}</h3>
                  <p className="text-xs opacity-90">{action.description}</p>
                </motion.div>
              </Link>
            );
          })}
        </motion.div>

        {/* Health Tips */}
        {healthTips && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm border border-gray-200 dark:border-gray-700"
          >
            <div className="flex items-center space-x-2 mb-3">
              <Shield className="h-5 w-5 text-green-600" />
              <h3 className="font-semibold text-gray-900 dark:text-white">
                Health Tips
              </h3>
            </div>
            <div className="space-y-3">
              {healthTips.tips.slice(0, 2).map((tip, index) => (
                <div key={index} className="border-l-4 border-green-500 pl-3">
                  <h4 className="font-medium text-sm text-gray-900 dark:text-white mb-1">
                    {tip.title}
                  </h4>
                  <p className="text-xs text-gray-600 dark:text-gray-400">
                    {tip.content}
                  </p>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Weather-based Advice */}
        {healthTips?.weatherBased && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4"
          >
            <div className="flex items-start space-x-3">
              <TrendingUp className="h-5 w-5 text-blue-600 mt-0.5" />
              <div>
                <h3 className="font-semibold text-blue-900 dark:text-blue-100 mb-1">
                  {healthTips.weatherBased.condition}
                </h3>
                <p className="text-sm text-blue-700 dark:text-blue-300">
                  {healthTips.weatherBased.advice}
                </p>
              </div>
            </div>
          </motion.div>
        )}

        {/* Emergency Contacts */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm border border-gray-200 dark:border-gray-700"
        >
          <div className="flex items-center space-x-2 mb-3">
            <Users className="h-5 w-5 text-green-600" />
            <h3 className="font-semibold text-gray-900 dark:text-white">
              Emergency Contacts
            </h3>
          </div>
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600 dark:text-gray-400">ASHA Worker</span>
              <a 
                href="tel:+91-98765-43210"
                className="text-sm text-green-600 hover:text-green-700 font-medium"
              >
                Sunita Devi
              </a>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600 dark:text-gray-400">Emergency</span>
              <a 
                href="tel:108"
                className="text-sm text-red-600 hover:text-red-700 font-medium"
              >
                108
              </a>
            </div>
          </div>
        </motion.div>
      </div>
    </Layout>
  );
}
