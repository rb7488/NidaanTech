import { NextRequest, NextResponse } from 'next/server';
import { medicalDiagnosisEngine, DiagnosisRequest } from '@/lib/medicalDiagnosis';
import { translations } from '@/lib/translations';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { 
      symptoms, 
      age, 
      gender, 
      pregnancy, 
      travelHistory, 
      comorbidities, 
      pincode, 
      language = 'english',
      illnessDuration
    } = body;

    // Validate required fields
    if (!symptoms || !Array.isArray(symptoms) || symptoms.length === 0) {
      return NextResponse.json(
        { error: 'Symptoms array is required and must not be empty' },
        { status: 400 }
      );
    }

    // Create diagnosis request
    const diagnosisRequest: DiagnosisRequest = {
      symptoms,
      age,
      gender,
      pregnancy,
      travelHistory,
      comorbidities,
      pincode,
      language,
      illnessDuration
    };

    // Get diagnosis from medical engine
    const diagnosis = medicalDiagnosisEngine.diagnose(diagnosisRequest);

    // Get translations for the specified language
    const t = translations[language] || translations.english;

    // Localize the response
    const localizedResponse = localizeDiagnosisResponse(diagnosis, t);

    return NextResponse.json(localizedResponse);
  } catch (error) {
    console.error('Medical diagnosis error:', error);
    return NextResponse.json(
      { error: 'Failed to process medical diagnosis' },
      { status: 500 }
    );
  }
}

// Function to localize diagnosis response
function localizeDiagnosisResponse(diagnosis: any, t: any) {
  // Map disease names to localized versions
  const diseaseNames: Record<string, string> = {
    malaria: t.labels.malaria || 'Malaria',
    dengue: t.labels.dengue || 'Dengue',
    cholera: t.labels.cholera || 'Cholera',
    diarrhea: t.labels.diarrhea || 'Acute Diarrhea',
    unknown: t.labels.unknown || 'Unknown Condition'
  };

  // Map severity levels
  const severityNames: Record<string, string> = {
    mild: t.severity.mild || 'Mild',
    moderate: t.severity.moderate || 'Moderate',
    severe: t.severity.severe || 'Severe'
  };

  return {
    ...diagnosis,
    primaryDiagnosis: {
      ...diagnosis.primaryDiagnosis,
      disease: diseaseNames[diagnosis.primaryDiagnosis.disease] || diagnosis.primaryDiagnosis.disease,
      severity: severityNames[diagnosis.primaryDiagnosis.severity] || diagnosis.primaryDiagnosis.severity
    },
    differentialDiagnoses: diagnosis.differentialDiagnoses.map((dd: any) => ({
      ...dd,
      disease: diseaseNames[dd.disease] || dd.disease
    })),
    recommendations: {
      ...diagnosis.recommendations,
      immediate: diagnosis.recommendations.immediate.map((rec: string) => 
        localizeRecommendation(rec, t)
      ),
      treatment: diagnosis.recommendations.treatment.map((rec: string) => 
        localizeRecommendation(rec, t)
      ),
      prevention: diagnosis.recommendations.prevention.map((rec: string) => 
        localizeRecommendation(rec, t)
      )
    },
    followUp: {
      ...diagnosis.followUp,
      instructions: diagnosis.followUp.instructions.map((inst: string) => 
        localizeInstruction(inst, t)
      )
    }
  };
}

// Function to localize individual recommendations
function localizeRecommendation(recommendation: string, t: any): string {
  const recommendationMap: Record<string, string> = {
    'Seek immediate medical attention': t.messages.emergencyContacted || 'Seek immediate medical attention',
    'Go to nearest hospital': t.labels.nearestClinic || 'Go to nearest hospital',
    'Monitor symptoms closely': t.labels.monitorSymptoms || 'Monitor symptoms closely',
    'Rest and hydration': t.results.homeRemedies.rest + ' ' + t.results.homeRemedies.hydration || 'Rest and hydration',
    'Take prescribed medications': t.labels.takeMedications || 'Take prescribed medications',
    'Practice good hygiene': t.results.healthTips.hygiene.content || 'Practice good hygiene',
    'Use mosquito nets': t.results.outbreakAlerts.dengue.prevention[3] || 'Use mosquito nets',
    'Eliminate standing water': t.results.outbreakAlerts.dengue.prevention[2] || 'Eliminate standing water',
    'Wash hands frequently': t.results.healthTips.hygiene.content || 'Wash hands frequently',
    'Drink safe water': t.results.healthTips.monsoon.content || 'Drink safe water'
  };

  return recommendationMap[recommendation] || recommendation;
}

// Function to localize instructions
function localizeInstruction(instruction: string, t: any): string {
  const instructionMap: Record<string, string> = {
    'Monitor symptoms': t.labels.monitorSymptoms || 'Monitor symptoms',
    'Take prescribed medications': t.labels.takeMedications || 'Take prescribed medications',
    'Rest and hydrate': t.results.homeRemedies.rest + ' ' + t.results.homeRemedies.hydration || 'Rest and hydrate',
    'Seek care if symptoms worsen': t.messages.seekCare || 'Seek care if symptoms worsen',
    'Monitor for dehydration signs': t.labels.monitorDehydration || 'Monitor for dehydration signs',
    'Monitor for complications due to existing conditions': t.labels.monitorComplications || 'Monitor for complications due to existing conditions'
  };

  return instructionMap[instruction] || instruction;
}

// GET endpoint for health check
export async function GET() {
  return NextResponse.json({
    status: 'healthy',
    message: 'Medical Diagnosis API is running',
    supportedDiseases: ['malaria', 'dengue', 'cholera', 'diarrhea'],
    version: '1.0.0'
  });
}

