import { NextRequest, NextResponse } from 'next/server';
import { mockApi } from '@/lib/mockApi';

export async function POST(request: NextRequest) {
  try {
    const { symptoms, pincode, language = 'english' } = await request.json();
    
    // Use mockApi to get localized response
    const result = await mockApi.analyzeSymptoms(symptoms, pincode, language);
    
    return NextResponse.json(result);
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to analyze symptoms' },
      { status: 500 }
    );
  }
}
