import { NextRequest, NextResponse } from 'next/server';
import { getLocationDiseaseData, getSeasonalDiseases, getEndemicDiseases, getCommonDiseases, getCurrentSeason } from '@/lib/locationDiseases';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const pincode = searchParams.get('pincode');
    const language = searchParams.get('language') || 'english';

    if (!pincode) {
      return NextResponse.json(
        { error: 'Pincode is required' },
        { status: 400 }
      );
    }

    // Get location-based disease data
    const locationData = getLocationDiseaseData(pincode);
    if (!locationData) {
      return NextResponse.json(
        { error: 'Location data not found for this pincode' },
        { status: 404 }
      );
    }

    const currentSeason = getCurrentSeason();
    const seasonalDiseases = getSeasonalDiseases(pincode);
    const endemicDiseases = getEndemicDiseases(pincode);
    const commonDiseases = getCommonDiseases(pincode);

    // Generate location-based alerts
    const alerts = [];

    // Seasonal disease alerts
    if (seasonalDiseases.length > 0) {
      alerts.push({
        type: 'seasonal',
        severity: 'moderate',
        title: `${currentSeason.charAt(0).toUpperCase() + currentSeason.slice(1)} Disease Alert`,
        message: `Common ${currentSeason} diseases in your area: ${seasonalDiseases.join(', ')}`,
        diseases: seasonalDiseases,
        recommendations: [
          'Take preventive measures',
          'Maintain good hygiene',
          'Avoid stagnant water',
          'Use mosquito repellents'
        ]
      });
    }

    // Endemic disease alerts
    if (endemicDiseases.length > 0) {
      alerts.push({
        type: 'endemic',
        severity: 'high',
        title: 'Endemic Disease Alert',
        message: `These diseases are endemic in your area: ${endemicDiseases.join(', ')}`,
        diseases: endemicDiseases,
        recommendations: [
          'Get vaccinated if available',
          'Take extra precautions',
          'Monitor symptoms closely',
          'Seek immediate medical help if symptoms appear'
        ]
      });
    }

    // Common disease alerts
    if (commonDiseases.length > 0) {
      alerts.push({
        type: 'common',
        severity: 'low',
        title: 'Common Diseases in Your Area',
        message: `Frequently reported diseases: ${commonDiseases.join(', ')}`,
        diseases: commonDiseases,
        recommendations: [
          'Stay informed about symptoms',
          'Practice preventive measures',
          'Maintain good health habits'
        ]
      });
    }

    // Generate specific disease awareness messages
    const diseaseAwareness = {
      malaria: {
        title: 'Malaria Prevention',
        message: 'Use mosquito nets, repellents, and eliminate standing water',
        symptoms: ['fever', 'chills', 'headache', 'body aches'],
        prevention: ['mosquito nets', 'repellents', 'eliminate standing water', 'wear long sleeves']
      },
      dengue: {
        title: 'Dengue Prevention',
        message: 'Prevent mosquito breeding and protect yourself from bites',
        symptoms: ['high fever', 'severe headache', 'eye pain', 'muscle pain'],
        prevention: ['eliminate standing water', 'use mosquito repellents', 'wear protective clothing', 'use screens on windows']
      },
      cholera: {
        title: 'Cholera Prevention',
        message: 'Ensure safe drinking water and proper sanitation',
        symptoms: ['watery diarrhea', 'vomiting', 'dehydration'],
        prevention: ['boil water', 'wash hands frequently', 'avoid street food', 'maintain hygiene']
      },
      diarrhea: {
        title: 'Diarrhea Prevention',
        message: 'Maintain food and water hygiene',
        symptoms: ['loose stools', 'abdominal cramps', 'dehydration'],
        prevention: ['wash hands', 'drink clean water', 'avoid contaminated food', 'maintain hygiene']
      },
      seasonal_fever: {
        title: 'Seasonal Fever Prevention',
        message: 'Stay hydrated and maintain good hygiene',
        symptoms: ['fever', 'headache', 'body aches', 'fatigue'],
        prevention: ['stay hydrated', 'rest adequately', 'maintain hygiene', 'avoid close contact with sick people']
      },
      hay_fever: {
        title: 'Hay Fever Management',
        message: 'Avoid allergens and use appropriate medications',
        symptoms: ['sneezing', 'runny nose', 'itchy eyes', 'nasal congestion'],
        prevention: ['avoid allergens', 'use air purifiers', 'keep windows closed', 'wash bedding regularly']
      },
      typhoid: {
        title: 'Typhoid Prevention',
        message: 'Get vaccinated and practice safe food habits',
        symptoms: ['high fever', 'headache', 'abdominal pain', 'diarrhea'],
        prevention: ['get vaccinated', 'avoid street food', 'drink clean water', 'maintain hygiene']
      },
      common_cold: {
        title: 'Common Cold Prevention',
        message: 'Maintain good hygiene and avoid close contact',
        symptoms: ['runny nose', 'sneezing', 'sore throat', 'cough'],
        prevention: ['wash hands frequently', 'avoid close contact', 'cover mouth when coughing', 'maintain hygiene']
      }
    };

    // Filter awareness messages based on location diseases
    const relevantAwareness: Record<string, any> = {};
    [...seasonalDiseases, ...endemicDiseases, ...commonDiseases].forEach(disease => {
      if (diseaseAwareness[disease as keyof typeof diseaseAwareness]) {
        relevantAwareness[disease] = diseaseAwareness[disease as keyof typeof diseaseAwareness];
      }
    });

    return NextResponse.json({
      location: `${locationData.district}, ${locationData.state}`,
      pincode: locationData.pincode,
      state: locationData.state,
      district: locationData.district,
      currentSeason,
      endemicDiseases: endemicDiseases,
      seasonalDiseases: seasonalDiseases,
      commonDiseases: commonDiseases,
      riskLevel: endemicDiseases.length > 2 ? 'high' : endemicDiseases.length > 0 ? 'medium' : 'low',
      alerts: alerts.map(alert => alert.message),
      alertDetails: alerts,
      diseaseAwareness: relevantAwareness,
      riskFactors: locationData.riskFactors,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Error fetching location alerts:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

