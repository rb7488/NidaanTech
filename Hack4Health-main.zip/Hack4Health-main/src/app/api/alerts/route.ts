import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const pincode = searchParams.get('pincode') || '751001';
    
    // Simulate processing delay
    await new Promise(resolve => setTimeout(resolve, 600));
    
    const response = {
      activeAlerts: [
        {
          disease: "Dengue",
          severity: "moderate",
          affectedAreas: ["751001", "751012", "752001"],
          recommendation: "Use mosquito nets, eliminate standing water, wear protective clothing",
          symptoms: ["High fever", "Severe headache", "Pain behind eyes", "Muscle and joint pain"],
          prevention: ["Use mosquito repellent", "Wear long sleeves", "Eliminate standing water", "Use bed nets"],
          lastUpdated: new Date().toISOString()
        },
        {
          disease: "Malaria",
          severity: "low",
          affectedAreas: ["768001", "768002"],
          recommendation: "Take preventive measures, use mosquito nets",
          symptoms: ["Fever", "Chills", "Sweating", "Headache"],
          prevention: ["Use mosquito nets", "Apply repellent", "Wear protective clothing"],
          lastUpdated: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString()
        }
      ],
      userAreaAlert: {
        disease: "Dengue",
        severity: "moderate",
        recommendation: "High risk area. Take extra precautions.",
        riskLevel: 7
      }
    };
    
    return NextResponse.json(response);
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to fetch alerts' },
      { status: 500 }
    );
  }
}
