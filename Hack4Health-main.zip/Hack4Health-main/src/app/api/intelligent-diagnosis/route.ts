import { NextRequest, NextResponse } from 'next/server';
import { medicalDiagnosisEngine, DiagnosisRequest } from '@/lib/medicalDiagnosis';
import { Answer } from '@/lib/questionEngine';
import { translations } from '@/lib/translations';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { 
      symptoms, 
      age, 
      gender, 
      pregnancy, 
      travelHistory, 
      comorbidities, 
      pincode, 
      language = 'english',
      illnessDuration,
      conversationHistory = [],
      currentMedications = [],
      allergies = [],
      action = 'diagnose' // 'diagnose' or 'answer_question'
    } = body;

    // Validate required fields
    if (!symptoms || !Array.isArray(symptoms) || symptoms.length === 0) {
      return NextResponse.json(
        { error: 'Symptoms array is required and must not be empty' },
        { status: 400 }
      );
    }

    // Create diagnosis request with enhanced features
    const diagnosisRequest: DiagnosisRequest = {
      symptoms,
      age,
      gender,
      pregnancy,
      travelHistory,
      comorbidities,
      pincode,
      language,
      illnessDuration,
      conversationHistory,
      currentMedications,
      allergies,
      enableIntelligentQuestions: true,
      enableReferralDecision: true,
      enableTreatmentRecommendations: true
    };

    let diagnosis;

    if (action === 'answer_question') {
      // Process question answer
      const { questionId, answer, currentResult } = body;
      
      if (!questionId || answer === undefined || !currentResult) {
        return NextResponse.json(
          { error: 'Question ID, answer, and current result are required for answer_question action' },
          { status: 400 }
        );
      }

      const answerObj: Answer = {
        questionId,
        answer,
        timestamp: new Date()
      };

      diagnosis = medicalDiagnosisEngine.processQuestionAnswer(
        currentResult,
        answerObj,
        diagnosisRequest
      );
    } else {
      // Initial diagnosis
      diagnosis = medicalDiagnosisEngine.diagnose(diagnosisRequest);
    }

    // Get translations for the specified language
    const t = translations[language] || translations.english;

    // Localize the response
    const localizedResponse = localizeDiagnosisResponse(diagnosis, t);

    return NextResponse.json(localizedResponse);
  } catch (error) {
    console.error('Intelligent diagnosis error:', error);
    return NextResponse.json(
      { error: 'Failed to process intelligent medical diagnosis' },
      { status: 500 }
    );
  }
}

// Function to localize enhanced diagnosis response
function localizeDiagnosisResponse(diagnosis: any, t: any) {
  // Map disease names to localized versions
  const diseaseNames: Record<string, string> = {
    tuberculosis: t.labels.tuberculosis || 'Tuberculosis',
    malaria: t.labels.malaria || 'Malaria',
    dengue: t.labels.dengue || 'Dengue',
    chikungunya: t.labels.chikungunya || 'Chikungunya',
    cholera: t.labels.cholera || 'Cholera',
    typhoid: t.labels.typhoid || 'Typhoid',
    hepatitis_a: t.labels.hepatitis_a || 'Hepatitis A',
    respiratory: t.labels.respiratory || 'Respiratory Infection',
    gastroenteritis: t.labels.gastroenteritis || 'Gastroenteritis',
    skin_infection: t.labels.skin_infection || 'Skin Infection',
    diarrhea: t.labels.diarrhea || 'Acute Diarrhea',
    unknown: t.labels.unknown || 'Unknown Condition'
  };

  // Map severity levels
  const severityNames: Record<string, string> = {
    mild: t.severity.mild || 'Mild',
    moderate: t.severity.moderate || 'Moderate',
    severe: t.severity.severe || 'Severe'
  };

  // Map urgency levels
  const urgencyNames: Record<string, string> = {
    immediate: t.urgency?.immediate || 'Immediate',
    urgent: t.urgency?.urgent || 'Urgent',
    routine: t.urgency?.routine || 'Routine',
    home_care: t.urgency?.home_care || 'Home Care'
  };

  return {
    ...diagnosis,
    primaryDiagnosis: {
      ...diagnosis.primaryDiagnosis,
      disease: diseaseNames[diagnosis.primaryDiagnosis.disease] || diagnosis.primaryDiagnosis.disease,
      severity: severityNames[diagnosis.primaryDiagnosis.severity] || diagnosis.primaryDiagnosis.severity
    },
    differentialDiagnoses: diagnosis.differentialDiagnoses.map((dd: any) => ({
      ...dd,
      disease: diseaseNames[dd.disease] || dd.disease
    })),
    recommendations: {
      ...diagnosis.recommendations,
      immediate: diagnosis.recommendations.immediate.map((rec: string) => 
        localizeRecommendation(rec, t)
      ),
      treatment: diagnosis.recommendations.treatment.map((rec: string) => 
        localizeRecommendation(rec, t)
      ),
      prevention: diagnosis.recommendations.prevention.map((rec: string) => 
        localizeRecommendation(rec, t)
      )
    },
    followUp: {
      ...diagnosis.followUp,
      instructions: diagnosis.followUp.instructions.map((inst: string) => 
        localizeInstruction(inst, t)
      )
    },
    // Localize intelligent questions
    intelligentQuestions: diagnosis.intelligentQuestions ? {
      ...diagnosis.intelligentQuestions,
      nextQuestion: diagnosis.intelligentQuestions.nextQuestion ? {
        ...diagnosis.intelligentQuestions.nextQuestion,
        question: localizeQuestion(diagnosis.intelligentQuestions.nextQuestion.question, t)
      } : null
    } : undefined,
    // Localize referral decision
    referralDecision: diagnosis.referralDecision ? {
      ...diagnosis.referralDecision,
      urgency: urgencyNames[diagnosis.referralDecision.urgency] || diagnosis.referralDecision.urgency,
      reason: localizeReferralReason(diagnosis.referralDecision.reason, t),
      instructions: diagnosis.referralDecision.instructions.map((inst: string) => 
        localizeInstruction(inst, t)
      )
    } : undefined,
    // Treatment recommendations are already comprehensive
    treatmentRecommendations: diagnosis.treatmentRecommendations ? {
      ...diagnosis.treatmentRecommendations,
      condition: diseaseNames[diagnosis.treatmentRecommendations.condition] || diagnosis.treatmentRecommendations.condition
    } : undefined
  };
}

// Function to localize individual recommendations
function localizeRecommendation(recommendation: string, t: any): string {
  const recommendationMap: Record<string, string> = {
    'Seek immediate medical attention': t.messages?.emergencyContacted || 'Seek immediate medical attention',
    'Go to nearest hospital': t.labels?.nearestClinic || 'Go to nearest hospital',
    'Monitor symptoms closely': t.labels?.monitorSymptoms || 'Monitor symptoms closely',
    'Rest and hydration': (t.results?.homeRemedies?.rest || 'Rest') + ' and ' + (t.results?.homeRemedies?.hydration || 'hydration'),
    'Take prescribed medications': t.labels?.takeMedications || 'Take prescribed medications',
    'Practice good hygiene': t.results?.healthTips?.hygiene?.content || 'Practice good hygiene',
    'Use mosquito nets': t.results?.outbreakAlerts?.dengue?.prevention?.[3] || 'Use mosquito nets',
    'Eliminate standing water': t.results?.outbreakAlerts?.dengue?.prevention?.[2] || 'Eliminate standing water',
    'Wash hands frequently': t.results?.healthTips?.hygiene?.content || 'Wash hands frequently',
    'Drink safe water': t.results?.healthTips?.monsoon?.content || 'Drink safe water'
  };

  return recommendationMap[recommendation] || recommendation;
}

// Function to localize instructions
function localizeInstruction(instruction: string, t: any): string {
  const instructionMap: Record<string, string> = {
    'Monitor symptoms': t.labels?.monitorSymptoms || 'Monitor symptoms',
    'Take prescribed medications': t.labels?.takeMedications || 'Take prescribed medications',
    'Rest and hydrate': (t.results?.homeRemedies?.rest || 'Rest') + ' and ' + (t.results?.homeRemedies?.hydration || 'hydrate'),
    'Seek care if symptoms worsen': t.messages?.seekCare || 'Seek care if symptoms worsen',
    'Monitor for dehydration signs': t.labels?.monitorDehydration || 'Monitor for dehydration signs',
    'Monitor for complications due to existing conditions': t.labels?.monitorComplications || 'Monitor for complications due to existing conditions',
    'Call emergency services immediately': t.messages?.callEmergency || 'Call emergency services immediately',
    'Accompany patient to hospital': t.labels?.accompanyPatient || 'Accompany patient to hospital',
    'Visit healthcare facility within 24 hours': t.labels?.visit24Hours || 'Visit healthcare facility within 24 hours'
  };

  return instructionMap[instruction] || instruction;
}

// Function to localize questions
function localizeQuestion(question: string, t: any): string {
  // This would ideally be a comprehensive mapping of all questions
  // For now, return the original question as questions are already in multiple languages
  return question;
}

// Function to localize referral reasons
function localizeReferralReason(reason: string, t: any): string {
  const reasonMap: Record<string, string> = {
    'Immediate medical attention required': t.messages?.immediateAttention || 'Immediate medical attention required',
    'Medical evaluation needed within 24 hours': t.messages?.evaluation24Hours || 'Medical evaluation needed within 24 hours',
    'Medical consultation recommended': t.messages?.consultationRecommended || 'Medical consultation recommended',
    'Mild symptoms can be managed with home care': t.messages?.homeCareManagement || 'Mild symptoms can be managed with home care'
  };

  // Check if reason starts with any mapped phrase
  for (const [key, value] of Object.entries(reasonMap)) {
    if (reason.includes(key)) {
      return reason.replace(key, value);
    }
  }

  return reason;
}

// GET endpoint for health check and capabilities
export async function GET() {
  return NextResponse.json({
    status: 'healthy',
    message: 'Intelligent Medical Diagnosis API is running',
    features: [
      'WHO/ICMR evidence-based diagnosis',
      'Intelligent question generation',
      'Clinical decision support',
      'Referral recommendations',
      'Treatment guidelines',
      'Performance metrics'
    ],
    supportedDiseases: [
      'tuberculosis',
      'malaria', 
      'dengue',
      'chikungunya',
      'cholera',
      'typhoid',
      'hepatitis_a',
      'respiratory_infections',
      'gastroenteritis',
      'skin_infections'
    ],
    languages: ['english', 'hindi', 'odia'],
    version: '2.0.0',
    whoCompliance: true,
    icmrGuidelines: true
  });
}
