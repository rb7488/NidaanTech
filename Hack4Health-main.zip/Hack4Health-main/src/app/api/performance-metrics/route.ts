import { NextRequest, NextResponse } from 'next/server';
import { medicalDiagnosisEngine, MedicalDiagnosisResult } from '@/lib/medicalDiagnosis';

// In-memory storage for demo purposes
// In production, this would be stored in a database
let consultationResults: MedicalDiagnosisResult[] = [];

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { action, data } = body;

    if (action === 'record') {
      // Record a consultation result
      if (!data || !data.primaryDiagnosis) {
        return NextResponse.json(
          { error: 'Valid consultation result data is required' },
          { status: 400 }
        );
      }

      // Add timestamp and ID for tracking
      const resultWithMetadata = {
        ...data,
        id: generateConsultationId(),
        timestamp: new Date().toISOString(),
        location: data.location || 'unknown'
      };

      consultationResults.push(resultWithMetadata);

      return NextResponse.json({
        success: true,
        message: 'Consultation result recorded',
        consultationId: resultWithMetadata.id
      });
    }

    if (action === 'metrics') {
      // Get performance metrics
      const metrics = medicalDiagnosisEngine.getPerformanceMetrics(consultationResults);
      
      // Add additional system metrics
      const enhancedMetrics = {
        ...metrics,
        systemMetrics: getSystemMetrics(),
        qualityMetrics: getQualityMetrics(consultationResults),
        geographicDistribution: getGeographicDistribution(consultationResults),
        timeSeriesData: getTimeSeriesData(consultationResults),
        whoComplianceDetails: getWHOComplianceDetails(consultationResults)
      };

      return NextResponse.json(enhancedMetrics);
    }

    if (action === 'clear') {
      // Clear all recorded data (admin function)
      consultationResults = [];
      return NextResponse.json({
        success: true,
        message: 'All consultation data cleared'
      });
    }

    return NextResponse.json(
      { error: 'Invalid action. Supported actions: record, metrics, clear' },
      { status: 400 }
    );

  } catch (error) {
    console.error('Performance metrics error:', error);
    return NextResponse.json(
      { error: 'Failed to process performance metrics request' },
      { status: 500 }
    );
  }
}

export async function GET() {
  try {
    // Return current system metrics
    const metrics = medicalDiagnosisEngine.getPerformanceMetrics(consultationResults);
    
    const enhancedMetrics = {
      ...metrics,
      systemStatus: {
        uptime: process.uptime(),
        memoryUsage: process.memoryUsage(),
        nodeVersion: process.version,
        platform: process.platform
      },
      apiHealth: {
        status: 'healthy',
        lastUpdated: new Date().toISOString(),
        totalRequests: consultationResults.length
      },
      whoCompliance: {
        rate: metrics.whoComplianceRate,
        target: 0.95, // 95% WHO compliance target
        status: metrics.whoComplianceRate >= 0.95 ? 'excellent' : 
                metrics.whoComplianceRate >= 0.85 ? 'good' : 'needs_improvement'
      },
      diagnosticAccuracy: {
        current: metrics.averageDiagnosticAccuracy,
        target: 0.85, // 85% diagnostic accuracy target (WHO standard)
        status: metrics.averageDiagnosticAccuracy >= 0.85 ? 'excellent' : 
                metrics.averageDiagnosticAccuracy >= 0.75 ? 'good' : 'needs_improvement'
      }
    };

    return NextResponse.json(enhancedMetrics);
  } catch (error) {
    console.error('Performance metrics GET error:', error);
    return NextResponse.json(
      { error: 'Failed to retrieve performance metrics' },
      { status: 500 }
    );
  }
}

// Helper functions
function generateConsultationId(): string {
  return `consultation_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

function getSystemMetrics() {
  return {
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    memoryUsage: process.memoryUsage(),
    cpuUsage: process.cpuUsage(),
    nodeVersion: process.version,
    platform: process.platform,
    totalConsultations: consultationResults.length,
    consultationsToday: consultationResults.filter(r => 
      new Date(r.timestamp).toDateString() === new Date().toDateString()
    ).length
  };
}

function getQualityMetrics(results: any[]) {
  if (results.length === 0) {
    return {
      averageConfidence: 0,
      highConfidenceRate: 0,
      emergencyDetectionRate: 0,
      appropriateReferralRate: 0
    };
  }

  const totalResults = results.length;
  
  const averageConfidence = results.reduce((sum, r) => 
    sum + (r.primaryDiagnosis?.confidence || 0), 0) / totalResults;

  const highConfidenceRate = results.filter(r => 
    (r.primaryDiagnosis?.confidence || 0) >= 80).length / totalResults;

  const emergencyDetectionRate = results.filter(r => 
    r.recommendations?.emergency === true).length / totalResults;

  const appropriateReferralRate = results.filter(r => 
    r.referralDecision?.urgency === 'immediate' && r.primaryDiagnosis?.severity === 'severe' ||
    r.referralDecision?.urgency === 'urgent' && r.primaryDiagnosis?.severity === 'moderate'
  ).length / totalResults;

  return {
    averageConfidence,
    highConfidenceRate,
    emergencyDetectionRate,
    appropriateReferralRate,
    qualityScore: (averageConfidence/100 + highConfidenceRate + appropriateReferralRate) / 3
  };
}

function getGeographicDistribution(results: any[]) {
  const distribution: Record<string, number> = {};
  
  results.forEach(r => {
    const location = r.location || 'unknown';
    distribution[location] = (distribution[location] || 0) + 1;
  });

  return distribution;
}

function getTimeSeriesData(results: any[]) {
  const dailyData: Record<string, {
    consultations: number;
    averageAccuracy: number;
    severeCases: number;
    emergencies: number;
  }> = {};

  results.forEach(r => {
    const date = new Date(r.timestamp).toISOString().split('T')[0];
    
    if (!dailyData[date]) {
      dailyData[date] = {
        consultations: 0,
        averageAccuracy: 0,
        severeCases: 0,
        emergencies: 0
      };
    }

    dailyData[date].consultations += 1;
    dailyData[date].averageAccuracy += (r.clinicalMetrics?.diagnosticAccuracy || 0);
    
    if (r.primaryDiagnosis?.severity === 'severe') {
      dailyData[date].severeCases += 1;
    }
    
    if (r.recommendations?.emergency === true) {
      dailyData[date].emergencies += 1;
    }
  });

  // Calculate averages
  Object.keys(dailyData).forEach(date => {
    const dayData = dailyData[date];
    dayData.averageAccuracy = dayData.averageAccuracy / dayData.consultations;
  });

  return dailyData;
}

function getWHOComplianceDetails(results: any[]) {
  if (results.length === 0) {
    return {
      overallCompliance: 0,
      complianceByDisease: {},
      nonCompliantReasons: []
    };
  }

  const totalResults = results.length;
  const compliantResults = results.filter(r => 
    r.clinicalMetrics?.whoCompliance === true).length;

  const overallCompliance = compliantResults / totalResults;

  // Compliance by disease
  const complianceByDisease: Record<string, { total: number; compliant: number; rate: number }> = {};
  
  results.forEach(r => {
    const disease = r.primaryDiagnosis?.disease || 'unknown';
    
    if (!complianceByDisease[disease]) {
      complianceByDisease[disease] = { total: 0, compliant: 0, rate: 0 };
    }
    
    complianceByDisease[disease].total += 1;
    
    if (r.clinicalMetrics?.whoCompliance === true) {
      complianceByDisease[disease].compliant += 1;
    }
  });

  // Calculate rates
  Object.keys(complianceByDisease).forEach(disease => {
    const data = complianceByDisease[disease];
    data.rate = data.compliant / data.total;
  });

  // Common non-compliance reasons (simplified for demo)
  const nonCompliantReasons = [
    'Missing WHO reference in guidelines',
    'Insufficient diagnostic criteria',
    'Incomplete emergency indicators',
    'Inadequate symptom mapping'
  ];

  return {
    overallCompliance,
    complianceByDisease,
    nonCompliantReasons,
    target: 0.95,
    status: overallCompliance >= 0.95 ? 'excellent' : 
            overallCompliance >= 0.85 ? 'good' : 'needs_improvement'
  };
}
