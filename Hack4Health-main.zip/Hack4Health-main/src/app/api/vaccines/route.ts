import { NextRequest, NextResponse } from 'next/server';
import { 
  vaccinationSchedule, 
  vaccinationCenters,
  getVaccinesByAge,
  getOverdueVaccines,
  getUpcomingVaccines,
  getVaccinationCentersByPincode,
  calculateVaccinationStatus
} from '@/lib/vaccinationData';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const pincode = searchParams.get('pincode') || '751001';
    const language = searchParams.get('language') || 'english';
    const userId = searchParams.get('userId') || 'default';

    // Simulate processing delay
    await new Promise(resolve => setTimeout(resolve, 800));

    // Mock user data - in real implementation, this would come from user database
    const mockUserData = {
      name: "Rick Astley",
      dateOfBirth: "2022-06-15", // 2 years old
      completedVaccines: ["bcg_birth", "opv_0", "hep_b_birth", "pentavalent_1", "opv_1", "fipv_1", "rotavirus_1", "pcv_1"],
      familyMembers: [
        {
          name: "Rick Astley Jr.",
          dateOfBirth: "2022-06-15",
          completedVaccines: ["bcg_birth", "opv_0", "hep_b_birth", "pentavalent_1", "opv_1"]
        },
        {
          name: "Priya Astley",
          dateOfBirth: "2018-03-10", // 6 years old
          completedVaccines: ["bcg_birth", "opv_0", "hep_b_birth", "pentavalent_1", "pentavalent_2", "pentavalent_3", "measles_rubella_1", "dpt_booster_1"]
        }
      ]
    };

    // Calculate vaccination status for main user
    const vaccinationStatus = calculateVaccinationStatus(
      mockUserData.dateOfBirth, 
      mockUserData.completedVaccines
    );

    // Get vaccination centers for the pincode
    const nearbyVaccinationCenters = getVaccinationCentersByPincode(pincode);
    
    // If no centers found for exact pincode, get some default centers
    const availableCenters = nearbyVaccinationCenters.length > 0 
      ? nearbyVaccinationCenters 
      : vaccinationCenters.slice(0, 3);

    // Calculate family members' vaccination status
    const familyVaccinationStatus = mockUserData.familyMembers.map(member => {
      const memberStatus = calculateVaccinationStatus(member.dateOfBirth, member.completedVaccines);
      return {
        name: member.name,
        age: Math.floor(memberStatus.currentAge / 12), // Convert to years
        ageInMonths: memberStatus.currentAge,
        dueVaccines: memberStatus.overdue.concat(memberStatus.upcoming).slice(0, 3).map(v => v.vaccineName),
        nextDueDate: memberStatus.overdue.length > 0 
          ? "Overdue" 
          : memberStatus.upcoming.length > 0 
            ? "Next 30 days" 
            : "Up to date",
        overdueCount: memberStatus.overdue.length,
        upcomingCount: memberStatus.upcoming.length
      };
    });

    // Prepare response data
    const vaccinationData = {
      userInfo: {
        name: mockUserData.name,
        age: Math.floor(vaccinationStatus.currentAge / 12),
        ageInMonths: vaccinationStatus.currentAge,
        nextDueDate: vaccinationStatus.overdue.length > 0 
          ? "Overdue vaccines" 
          : vaccinationStatus.upcoming.length > 0 
            ? vaccinationStatus.upcoming[0].ageMonthsOrRule 
            : "Up to date",
        lastVaccinated: vaccinationStatus.completed.length > 0 
          ? "Recently completed" 
          : "No records",
        completionRate: Math.round((vaccinationStatus.completed.length / 
          Math.max(vaccinationStatus.completed.length + vaccinationStatus.overdue.length + vaccinationStatus.upcoming.length, 1)) * 100) || 0
      },
      
      // Legacy fields for backward compatibility
      dueVaccines: vaccinationStatus.upcoming.concat(vaccinationStatus.overdue).slice(0, 4).map(v => v.vaccineName),
      nextDueDate: vaccinationStatus.upcoming.length > 0 
        ? vaccinationStatus.upcoming[0].ageMonthsOrRule 
        : vaccinationStatus.overdue.length > 0 
          ? "Overdue" 
          : "Up to date",
      vaccinationCenter: availableCenters.length > 0 
        ? `${availableCenters[0].name} - ${availableCenters[0].operatingHours}` 
        : "No centers found",
      reminderSet: true,
      familyMembers: familyVaccinationStatus,
      
      // Enhanced data
      upcomingVaccines: vaccinationStatus.upcoming.concat(vaccinationStatus.overdue).slice(0, 5).map(vaccine => ({
        name: vaccine.vaccineName,
        dueDate: vaccine.ageMonthsOrRule,
        ageGroup: vaccine.ageCategory,
        location: availableCenters[0]?.name || "Nearest PHC",
        importance: vaccine.priority === 'essential' ? 'Essential' : vaccine.priority === 'recommended' ? 'Recommended' : 'Optional',
        isOverdue: vaccinationStatus.overdue.includes(vaccine),
        protectsAgainst: vaccine.protectsAgainst.join(', '),
        administrationRoute: vaccine.administrationRoute,
        sideEffects: vaccine.sideEffects.join(', '),
        contraindications: vaccine.contraindications.join(', '),
        specialNotes: vaccine.specialNotes || ''
      })),
      
      completedVaccines: vaccinationStatus.completed.map(vaccine => ({
        name: vaccine.vaccineName,
        dateGiven: "Completed", // In real app, would have actual dates
        nextDue: vaccine.isBooster ? "Booster due later" : "Series complete",
        batchNumber: `BATCH-${vaccine.id.toUpperCase()}`,
        protectsAgainst: vaccine.protectsAgainst.join(', '),
        administrationRoute: vaccine.administrationRoute
      })),
      
      vaccinationCenters: availableCenters.map(center => ({
        name: center.name,
        address: center.address,
        distance: "2-5 km", // In real app, would calculate actual distance
        timings: center.operatingHours,
        contact: center.contactNumber,
        availableVaccines: center.availableVaccines,
        type: center.type,
        hasRefrigeration: center.hasRefrigeration,
        emergencyServices: center.emergencyServices
      })),

      // Additional statistics
      statistics: {
        totalVaccinesInSchedule: vaccinationSchedule.filter(v => 
          v.ageInMonths !== undefined && v.ageInMonths <= vaccinationStatus.currentAge + 24
        ).length,
        completedCount: vaccinationStatus.completed.length,
        overdueCount: vaccinationStatus.overdue.length,
        upcomingCount: vaccinationStatus.upcoming.length,
        completionPercentage: Math.round((vaccinationStatus.completed.length / 
          Math.max(vaccinationStatus.completed.length + vaccinationStatus.overdue.length, 1)) * 100)
      },

      // WHO compliance
      whoCompliance: {
        essentialVaccinesCompleted: vaccinationStatus.completed.filter(v => v.priority === 'essential').length,
        totalEssentialVaccines: vaccinationSchedule.filter(v => 
          v.priority === 'essential' && 
          v.ageInMonths !== undefined && 
          v.ageInMonths <= vaccinationStatus.currentAge
        ).length,
        isWhoCompliant: vaccinationStatus.overdue.filter(v => v.priority === 'essential').length === 0
      }
    };

    return NextResponse.json(vaccinationData);
  } catch (error) {
    console.error('Error fetching vaccination data:', error);
    return NextResponse.json(
      { error: 'Failed to fetch vaccination data' },
      { status: 500 }
    );
  }
}

// POST endpoint for updating vaccination records
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, vaccineId, dateGiven, batchNumber, centerId } = body;

    // In real implementation, this would update the database
    console.log('Vaccination record updated:', { userId, vaccineId, dateGiven, batchNumber, centerId });

    return NextResponse.json({
      success: true,
      message: 'Vaccination record updated successfully',
      vaccineId,
      dateGiven
    });
  } catch (error) {
    console.error('Error updating vaccination record:', error);
    return NextResponse.json(
      { error: 'Failed to update vaccination record' },
      { status: 500 }
    );
  }
}