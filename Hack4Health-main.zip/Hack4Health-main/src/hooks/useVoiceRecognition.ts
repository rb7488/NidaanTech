'use client';

import { useState, useEffect, useRef, useCallback } from 'react';

interface VoiceRecognitionOptions {
  language: string;
  continuous?: boolean;
  interimResults?: boolean;
  maxAlternatives?: number;
}

interface VoiceRecognitionResult {
  transcript: string;
  confidence: number;
  isFinal: boolean;
}

interface UseVoiceRecognitionReturn {
  isListening: boolean;
  transcript: string;
  error: string | null;
  isSupported: boolean;
  startListening: () => void;
  stopListening: () => void;
  resetTranscript: () => void;
}

// Language mapping for Web Speech API
const getLanguageCode = (language: string): string => {
  const languageMap: Record<string, string> = {
    english: 'en-IN',
    hindi: 'hi-IN',
    odia: 'or-IN'
  };
  return languageMap[language] || 'en-IN';
};

export const useVoiceRecognition = (
  options: VoiceRecognitionOptions
): UseVoiceRecognitionReturn => {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isSupported, setIsSupported] = useState(false);
  
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);
  const finalTranscriptRef = useRef<string>('');
  const isProcessingRef = useRef<boolean>(false);

  // Check if speech recognition is supported
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      setIsSupported(!!SpeechRecognition);
      
      if (SpeechRecognition) {
        recognitionRef.current = new SpeechRecognition();
      }
    }
  }, []);

  // Configure speech recognition
  useEffect(() => {
    if (!recognitionRef.current) return;

    const recognition = recognitionRef.current;
    
    recognition.continuous = options.continuous ?? true;
    recognition.interimResults = options.interimResults ?? true;
    recognition.maxAlternatives = options.maxAlternatives ?? 1;
    recognition.lang = getLanguageCode(options.language);

    recognition.onstart = () => {
      setIsListening(true);
      setError(null);
    };

    recognition.onresult = (event: SpeechRecognitionEvent) => {
      if (isProcessingRef.current) return; // Prevent duplicate processing
      
      isProcessingRef.current = true;
      
      let currentFinalTranscript = '';
      let interimTranscript = '';

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const result = event.results[i];
        const transcriptText = result[0].transcript.trim();

        if (result.isFinal) {
          currentFinalTranscript += transcriptText;
        } else {
          interimTranscript += transcriptText;
        }
      }

      // Only add new final transcript that hasn't been added before
      if (currentFinalTranscript && !finalTranscriptRef.current.includes(currentFinalTranscript)) {
        finalTranscriptRef.current += (finalTranscriptRef.current ? ' ' : '') + currentFinalTranscript;
        setTranscript(finalTranscriptRef.current + (interimTranscript ? ' ' + interimTranscript : ''));
      } else if (interimTranscript) {
        // Show interim results without adding to final
        setTranscript(finalTranscriptRef.current + (finalTranscriptRef.current ? ' ' : '') + interimTranscript);
      }
      
      // Auto-stop after 3 seconds of silence for final results
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
      
      if (currentFinalTranscript) {
        timeoutRef.current = setTimeout(() => {
          if (recognitionRef.current && isListening) {
            recognitionRef.current.stop();
          }
        }, 3000);
      }
      
      // Reset processing flag after a short delay
      setTimeout(() => {
        isProcessingRef.current = false;
      }, 100);
    };

    recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
      setError(event.error);
      setIsListening(false);
      
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };

    recognition.onend = () => {
      setIsListening(false);
      
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };

    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, [options.language, options.continuous, options.interimResults, options.maxAlternatives, isListening]);

  const startListening = useCallback(() => {
    if (!recognitionRef.current || !isSupported) {
      setError('Speech recognition not supported');
      return;
    }

    try {
      setError(null);
      finalTranscriptRef.current = '';
      isProcessingRef.current = false;
      
      // Let the SpeechRecognition API handle permission requests natively
      recognitionRef.current.start();
    } catch (err: unknown) {
      const error = err as Error;
      if (error.name === 'NotAllowedError' || error.message?.includes('not-allowed')) {
        setError('not-allowed');
      } else {
        setError('Failed to start speech recognition');
      }
      console.error('Speech recognition error:', err);
    }
  }, [isSupported]);

  const stopListening = useCallback(() => {
    if (recognitionRef.current && isListening) {
      recognitionRef.current.stop();
    }
    
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
  }, [isListening]);

  const resetTranscript = useCallback(() => {
    setTranscript('');
    setError(null);
    finalTranscriptRef.current = '';
    isProcessingRef.current = false;
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (recognitionRef.current && isListening) {
        recognitionRef.current.stop();
      }
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, [isListening]);

  return {
    isListening,
    transcript,
    error,
    isSupported,
    startListening,
    stopListening,
    resetTranscript
  };
};

// Extend the Window interface for TypeScript
declare global {
  interface Window {
    SpeechRecognition: typeof SpeechRecognition;
    webkitSpeechRecognition: typeof SpeechRecognition;
  }
}
