'use client';

import React from 'react';
import Navigation from './Navigation';

interface LayoutProps {
  children: React.ReactNode;
  showNavigation?: boolean;
}

export default function Layout({ children, showNavigation = true }: LayoutProps) {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Main Content */}
      <main className={`${showNavigation ? 'pb-32' : 'pb-4'} pt-4 px-4`}>
        {children}
      </main>
      
      {/* Bottom Navigation */}
      {showNavigation && <Navigation />}
    </div>
  );
}
