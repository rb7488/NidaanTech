'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { 
  Home, 
  Syringe, 
  Search, 
  AlertTriangle, 
  User,
  Globe,
  Sun,
  Moon
} from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTheme } from '@/contexts/ThemeContext';
import { motion } from 'framer-motion';

interface NavigationProps {
  className?: string;
}

export default function Navigation({ className = '' }: NavigationProps) {
  const pathname = usePathname();
  const { t, currentLanguage, setLanguage, availableLanguages, languageNames, languageFlags } = useLanguage();
  const { isDark, toggleTheme } = useTheme();

  const navItems = [
    { href: '/', icon: Home, label: t.navigation.home },
    { href: '/vaccines', icon: Syringe, label: t.navigation.vaccines },
    { href: '/symptoms', icon: Search, label: t.navigation.symptoms },
    { href: '/alerts', icon: AlertTriangle, label: t.navigation.alerts },
    { href: '/profile', icon: User, label: t.navigation.profile },
  ];

  const isActive = (href: string) => {
    if (href === '/') {
      return pathname === '/';
    }
    return pathname.startsWith(href);
  };

  return (
    <div className={`fixed bottom-0 left-0 right-0 z-50 ${className}`}>
      {/* Language and Theme Selector - Above Navigation */}
      <div className="bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 px-4 py-2">
        <div className="flex items-center justify-between max-w-md mx-auto">
          {/* Language Selector */}
          <div className="flex items-center space-x-2">
            <Globe className="h-4 w-4 text-gray-600 dark:text-gray-400" />
            <select
              value={currentLanguage}
              onChange={(e) => setLanguage(e.target.value)}
              className="text-xs bg-transparent border-none outline-none text-gray-700 dark:text-gray-300"
            >
              {availableLanguages.map((lang) => (
                <option key={lang} value={lang}>
                  {languageFlags[lang as keyof typeof languageFlags]} {languageNames[lang as keyof typeof languageNames]}
                </option>
              ))}
            </select>
          </div>

          {/* Theme Toggle */}
          <button
            onClick={toggleTheme}
            className="p-2 rounded-full bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
            aria-label={t.buttons.toggleTheme}
          >
            {isDark ? (
              <Sun className="h-4 w-4 text-yellow-500" />
            ) : (
              <Moon className="h-4 w-4 text-gray-600" />
            )}
          </button>
        </div>
      </div>

      {/* Bottom Navigation */}
      <nav className="bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 px-4 py-2">
        <div className="flex items-center justify-around max-w-md mx-auto">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = isActive(item.href);
            
            return (
              <Link
                key={item.href}
                href={item.href}
                className="flex flex-col items-center justify-center p-2 min-w-[60px] transition-colors"
              >
                <motion.div
                  whileTap={{ scale: 0.95 }}
                  className={`p-2 rounded-full transition-colors ${
                    active
                      ? 'bg-green-100 dark:bg-green-900 text-green-600 dark:text-green-400'
                      : 'text-gray-600 dark:text-gray-400 hover:text-green-600 dark:hover:text-green-400'
                  }`}
                >
                  <Icon className="h-5 w-5" />
                </motion.div>
                <span className={`text-xs mt-1 transition-colors ${
                  active
                    ? 'text-green-600 dark:text-green-400 font-medium'
                    : 'text-gray-600 dark:text-gray-400'
                }`}>
                  {item.label}
                </span>
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
