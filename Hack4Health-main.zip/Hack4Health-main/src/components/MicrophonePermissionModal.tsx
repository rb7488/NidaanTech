'use client';

import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Mic, X, AlertTriangle, Smartphone, Settings } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

interface MicrophonePermissionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRetry: () => void;
  error: string | null;
}

export default function MicrophonePermissionModal({
  isOpen,
  onClose,
  onRetry,
  error
}: MicrophonePermissionModalProps) {
  const { t } = useLanguage();

  const isMobile = typeof window !== 'undefined' && 
    /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="bg-white dark:bg-gray-800 rounded-lg p-6 max-w-md w-full mx-4 shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-red-100 dark:bg-red-900/20 rounded-full">
                  <Mic className="h-6 w-6 text-red-600" />
                </div>
                <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
                  Microphone Access Required
                </h2>
              </div>
              <button
                onClick={onClose}
                className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors"
              >
                <X className="h-5 w-5 text-gray-500" />
              </button>
            </div>

            {/* Error Message */}
            {error === 'not-allowed' && (
              <div className="mb-4 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
                <div className="flex items-start space-x-2">
                  <AlertTriangle className="h-5 w-5 text-red-600 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-sm font-medium text-red-800 dark:text-red-200">
                      {t.buttons.microphonePermissionDenied}
                    </p>
                    <p className="text-xs text-red-600 dark:text-red-300 mt-1">
                      Voice input requires microphone access to work properly.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Instructions */}
            <div className="space-y-4">
              <p className="text-sm text-gray-600 dark:text-gray-400">
                To use voice input for symptom analysis, please allow microphone access when prompted by your browser.
              </p>

              {/* Mobile Instructions */}
              {isMobile && (
                <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-3">
                  <div className="flex items-start space-x-2">
                    <Smartphone className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm font-medium text-blue-800 dark:text-blue-200 mb-2">
                        Mobile Instructions:
                      </p>
                      <ol className="text-xs text-blue-700 dark:text-blue-300 space-y-1 list-decimal list-inside">
                        <li>Tap &quot;Allow&quot; when the browser asks for microphone permission</li>
                        <li>If you accidentally denied access, tap the lock icon in your address bar</li>
                        <li>Select &quot;Permissions&quot; and enable microphone access</li>
                        <li>Refresh the page and try again</li>
                      </ol>
                    </div>
                  </div>
                </div>
              )}

              {/* Desktop Instructions */}
              {!isMobile && (
                <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-3">
                  <div className="flex items-start space-x-2">
                    <Settings className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm font-medium text-green-800 dark:text-green-200 mb-2">
                        Desktop Instructions:
                      </p>
                      <ol className="text-xs text-green-700 dark:text-green-300 space-y-1 list-decimal list-inside">
                        <li>Click &quot;Allow&quot; when the browser asks for microphone permission</li>
                        <li>If blocked, click the microphone icon in your address bar</li>
                        <li>Select &quot;Always allow&quot; for this site</li>
                        <li>Reload the page if needed</li>
                      </ol>
                    </div>
                  </div>
                </div>
              )}

              {/* Privacy Note */}
              <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-3">
                <p className="text-xs text-gray-600 dark:text-gray-400">
                  <strong>Privacy Note:</strong> Your voice data is processed locally in your browser and is not stored or transmitted to any servers. We only use it to convert your speech to text for symptom analysis.
                </p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex space-x-3 mt-6">
              <button
                onClick={onClose}
                className="flex-1 px-4 py-2 text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-lg font-medium hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  onRetry();
                  onClose();
                }}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2"
              >
                <Mic className="h-4 w-4" />
                <span>Try Again</span>
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
