// Intelligent Question Generation Engine with WHO/ICMR Guidelines
// Based on evidence-based medicine and clinical decision support

export interface Question {
  id: string;
  question: string;
  whoReference: string;
  weight: number;
  urgency?: 'immediate_referral' | 'urgent' | 'routine';
  followUp?: string;
  riskMultiplier?: number;
  pattern?: string;
  environmental?: boolean;
  warningSign?: boolean;
  severity?: 'mild' | 'moderate' | 'severe';
  pathognomonic?: boolean;
  threshold?: string;
  dehydrationSign?: boolean;
  jaundice?: boolean;
  riskFactor?: boolean;
  flu_indicator?: string;
  systemic?: boolean;
  bacterial_indicator?: boolean;
  seasonal?: boolean;
  allergic_pattern?: boolean;
  cellulitis_signs?: boolean;
  roseSpots?: boolean;
  options?: string[];
  type: 'yes_no' | 'multiple_choice' | 'text' | 'scale';
  category: 'symptom' | 'risk_factor' | 'duration' | 'severity' | 'pattern';
}

export interface Answer {
  questionId: string;
  answer: string | number | boolean;
  timestamp: Date;
  confidence?: number;
}

export interface UserProfile {
  age?: number;
  gender?: 'male' | 'female';
  pregnancy?: boolean;
  location?: string;
  comorbidities?: string[];
  travelHistory?: string[];
}

export interface Symptom {
  name: string;
  severity: number;
  duration: number;
  pattern: string;
}

// TB Screening Questions based on WHO Guidelines
export const tbQuestions: Question[] = [
  {
    id: 'tb_cough_duration',
    question: 'Have you been coughing for more than 2 weeks?',
    whoReference: 'WHO TB Screening Guidelines 2021',
    weight: 0.9,
    type: 'yes_no',
    category: 'symptom',
    pathognomonic: true
  },
  {
    id: 'tb_hemoptysis',
    question: 'Have you coughed up blood or blood-stained sputum?',
    whoReference: 'WHO Consolidated TB Guidelines',
    weight: 0.95,
    urgency: 'immediate_referral',
    type: 'yes_no',
    category: 'symptom'
  },
  {
    id: 'tb_weight_loss',
    question: 'Have you lost weight without trying to?',
    whoReference: 'WHO TB Symptom Screening',
    weight: 0.8,
    followUp: 'How much weight? Over what period?',
    type: 'yes_no',
    category: 'symptom'
  },
  {
    id: 'tb_night_sweats',
    question: 'Do you have night sweats that soak your clothes?',
    whoReference: 'WHO TB Clinical Guidelines',
    weight: 0.7,
    type: 'yes_no',
    category: 'symptom'
  },
  {
    id: 'tb_risk_factors',
    question: 'Are you HIV positive or have diabetes?',
    whoReference: 'WHO TB Risk Factors',
    weight: 0.8,
    riskMultiplier: 3.0,
    type: 'multiple_choice',
    category: 'risk_factor',
    options: ['Neither', 'HIV positive', 'Diabetes', 'Both']
  },
  {
    id: 'tb_contact_history',
    question: 'Have you been in close contact with someone who has TB?',
    whoReference: 'WHO TB Contact Investigation',
    weight: 0.85,
    riskMultiplier: 2.5,
    type: 'yes_no',
    category: 'risk_factor'
  },
  {
    id: 'tb_living_conditions',
    question: 'Do you live in crowded conditions with poor ventilation?',
    whoReference: 'WHO TB Environmental Risk Factors',
    weight: 0.6,
    environmental: true,
    type: 'yes_no',
    category: 'risk_factor'
  }
];

// Malaria Screening Questions based on WHO Guidelines
export const malariaQuestions: Question[] = [
  {
    id: 'malaria_fever_pattern',
    question: 'Does your fever come and go in cycles?',
    whoReference: 'WHO Malaria Guidelines 2023',
    weight: 0.85,
    pattern: 'Classic intermittent fever',
    type: 'yes_no',
    category: 'pattern'
  },
  {
    id: 'malaria_chills',
    question: 'Do you shiver uncontrollably when fever starts?',
    whoReference: 'WHO Clinical Features of Malaria',
    weight: 0.8,
    type: 'yes_no',
    category: 'symptom'
  },
  {
    id: 'malaria_mosquitoes',
    question: 'Are you in an area with many mosquitoes?',
    whoReference: 'WHO Vector Control Guidelines',
    weight: 0.6,
    environmental: true,
    type: 'yes_no',
    category: 'risk_factor'
  },
  {
    id: 'malaria_travel_endemic',
    question: 'Have you traveled to malaria-endemic areas in the last month?',
    whoReference: 'WHO Malaria Travel Guidelines',
    weight: 0.9,
    riskMultiplier: 2.0,
    type: 'yes_no',
    category: 'risk_factor'
  },
  {
    id: 'malaria_severe_symptoms',
    question: 'Do you have confusion, seizures, or difficulty breathing?',
    whoReference: 'WHO Severe Malaria Guidelines',
    weight: 0.95,
    urgency: 'immediate_referral',
    severity: 'severe',
    type: 'multiple_choice',
    category: 'symptom',
    options: ['None', 'Confusion', 'Seizures', 'Difficulty breathing', 'Multiple symptoms']
  }
];

// Dengue Screening Questions based on WHO Guidelines
export const dengueQuestions: Question[] = [
  {
    id: 'dengue_rash',
    question: 'Have you noticed any red spots or rash on your skin?',
    whoReference: 'WHO Dengue Clinical Management',
    weight: 0.8,
    type: 'yes_no',
    category: 'symptom'
  },
  {
    id: 'dengue_bleeding',
    question: 'Any bleeding from nose, gums, or unusual bruising?',
    whoReference: 'WHO Dengue Warning Signs',
    weight: 0.9,
    warningSign: true,
    urgency: 'urgent',
    type: 'multiple_choice',
    category: 'symptom',
    options: ['None', 'Nose bleeding', 'Gum bleeding', 'Easy bruising', 'Multiple bleeding']
  },
  {
    id: 'dengue_abdominal_pain',
    question: 'Severe stomach pain or persistent vomiting?',
    whoReference: 'WHO Dengue Severe Complications',
    weight: 0.85,
    severity: 'severe',
    warningSign: true,
    type: 'yes_no',
    category: 'symptom'
  },
  {
    id: 'dengue_platelet_symptoms',
    question: 'Do you feel extremely weak or have rapid pulse?',
    whoReference: 'WHO Dengue Shock Syndrome',
    weight: 0.88,
    urgency: 'urgent',
    type: 'yes_no',
    category: 'symptom'
  }
];

// Chikungunya Assessment Questions
export const chikungunyaQuestions: Question[] = [
  {
    id: 'chikungunya_joint_pain',
    question: 'Do you have severe joint pain that prevents normal movement?',
    whoReference: 'WHO Chikungunya Guidelines',
    weight: 0.9,
    pathognomonic: true,
    type: 'yes_no',
    category: 'symptom'
  },
  {
    id: 'chikungunya_joint_pattern',
    question: 'Which joints hurt most?',
    whoReference: 'WHO Chikungunya Clinical Features',
    weight: 0.8,
    pattern: 'symmetric_polyarthritis',
    type: 'multiple_choice',
    category: 'pattern',
    options: ['Hands/wrists', 'Ankles/feet', 'Knees', 'Multiple joints', 'Spine/back']
  }
];

// Cholera/Severe Diarrhea Questions
export const choleraQuestions: Question[] = [
  {
    id: 'cholera_stool_frequency',
    question: 'How many loose stools have you had in the last 24 hours?',
    whoReference: 'WHO Cholera Case Definition',
    weight: 0.9,
    threshold: '>3 stools = significant',
    type: 'multiple_choice',
    category: 'symptom',
    options: ['1-2', '3-5', '6-10', '10-15', 'More than 15']
  },
  {
    id: 'cholera_rice_water',
    question: 'Is the stool watery like rice water?',
    whoReference: 'WHO Cholera Clinical Description',
    weight: 0.95,
    pathognomonic: true,
    type: 'yes_no',
    category: 'symptom'
  },
  {
    id: 'cholera_stool_volume',
    question: 'Are you passing large amounts of watery stool each time?',
    whoReference: 'WHO Cholera Volume Assessment',
    weight: 0.85,
    type: 'yes_no',
    category: 'symptom'
  },
  {
    id: 'cholera_dehydration_signs',
    question: 'Do you have dry mouth, sunken eyes, or skin that stays up when pinched?',
    whoReference: 'WHO Dehydration Assessment',
    weight: 0.9,
    dehydrationSign: true,
    warningSign: true,
    type: 'multiple_choice',
    category: 'symptom',
    options: ['None', 'Dry mouth', 'Sunken eyes', 'Skin tenting', 'Multiple signs']
  },
  {
    id: 'cholera_thirst_weakness',
    question: 'Are you feeling very thirsty and extremely weak?',
    whoReference: 'WHO Dehydration Symptoms',
    weight: 0.8,
    type: 'yes_no',
    category: 'symptom'
  },
  {
    id: 'cholera_vomiting',
    question: 'Are you vomiting frequently along with diarrhea?',
    whoReference: 'WHO Cholera Clinical Features',
    weight: 0.75,
    type: 'yes_no',
    category: 'symptom'
  },
  {
    id: 'cholera_no_fever',
    question: 'Do you have diarrhea WITHOUT fever?',
    whoReference: 'WHO Cholera Differential Diagnosis',
    weight: 0.7,
    type: 'yes_no',
    category: 'symptom'
  },
  {
    id: 'cholera_water_source',
    question: 'Have you consumed unsafe water, street food, or raw vegetables recently?',
    whoReference: 'WHO Cholera Prevention Guidelines',
    weight: 0.8,
    riskFactor: true,
    type: 'multiple_choice',
    category: 'risk_factor',
    options: ['None', 'Unsafe water', 'Street food', 'Raw vegetables', 'Multiple sources']
  },
  {
    id: 'cholera_community_outbreak',
    question: 'Are others in your area also having severe diarrhea?',
    whoReference: 'WHO Cholera Outbreak Investigation',
    weight: 0.85,
    environmental: true,
    type: 'yes_no',
    category: 'risk_factor'
  },
  {
    id: 'cholera_rapid_onset',
    question: 'Did the diarrhea start suddenly and become severe quickly?',
    whoReference: 'WHO Cholera Onset Pattern',
    weight: 0.75,
    type: 'yes_no',
    category: 'pattern'
  }
];

// Typhoid Assessment Questions
export const typhoidQuestions: Question[] = [
  {
    id: 'typhoid_fever_headache_combo',
    question: 'Do you have both fever and severe headache together?',
    whoReference: 'WHO Typhoid Guidelines 2018',
    weight: 0.85,
    pathognomonic: true,
    type: 'yes_no',
    category: 'symptom'
  },
  {
    id: 'typhoid_sustained_fever',
    question: 'Have you had continuous fever for more than a week?',
    whoReference: 'WHO Typhoid Guidelines 2018',
    weight: 0.9,
    pattern: 'sustained_fever',
    type: 'yes_no',
    category: 'duration'
  },
  {
    id: 'typhoid_rose_spots',
    question: 'Any rose-colored spots on your chest or abdomen?',
    whoReference: 'WHO Typhoid Clinical Features',
    weight: 0.95,
    roseSpots: true,
    pathognomonic: true,
    type: 'yes_no',
    category: 'symptom'
  },
  {
    id: 'typhoid_headache_pattern',
    question: 'Is your headache severe and gets worse with the fever?',
    whoReference: 'WHO Typhoid Symptoms',
    weight: 0.8,
    type: 'yes_no',
    category: 'symptom'
  },
  {
    id: 'typhoid_abdominal_pain',
    question: 'Do you have stomach pain or discomfort with the fever?',
    whoReference: 'WHO Typhoid Abdominal Symptoms',
    weight: 0.75,
    type: 'yes_no',
    category: 'symptom'
  },
  {
    id: 'typhoid_constipation_diarrhea',
    question: 'Are you having constipation or loose stools?',
    whoReference: 'WHO Typhoid GI Symptoms',
    weight: 0.7,
    type: 'multiple_choice',
    category: 'symptom',
    options: ['Neither', 'Constipation', 'Loose stools', 'Both alternating']
  },
  {
    id: 'typhoid_weakness',
    question: 'Do you feel extremely weak and tired?',
    whoReference: 'WHO Typhoid Systemic Symptoms',
    weight: 0.65,
    type: 'yes_no',
    category: 'symptom'
  },
  {
    id: 'typhoid_food_water_exposure',
    question: 'Have you eaten street food or drunk untreated water recently?',
    whoReference: 'WHO Typhoid Risk Factors',
    weight: 0.6,
    riskFactor: true,
    type: 'yes_no',
    category: 'risk_factor'
  }
];

// Hepatitis A Screening Questions
export const hepatitisAQuestions: Question[] = [
  {
    id: 'hepatitis_jaundice',
    question: 'Have you noticed yellowing of eyes or skin?',
    whoReference: 'WHO Hepatitis Guidelines',
    weight: 0.95,
    jaundice: true,
    pathognomonic: true,
    type: 'yes_no',
    category: 'symptom'
  },
  {
    id: 'hepatitis_dark_urine',
    question: 'Is your urine dark colored like tea?',
    whoReference: 'WHO Viral Hepatitis Guidelines',
    weight: 0.8,
    type: 'yes_no',
    category: 'symptom'
  },
  {
    id: 'hepatitis_food_exposure',
    question: 'Have you eaten from street vendors recently?',
    whoReference: 'WHO HAV Transmission Routes',
    weight: 0.6,
    riskFactor: true,
    type: 'yes_no',
    category: 'risk_factor'
  }
];

// Respiratory Disease Questions
export const respiratoryQuestions: Question[] = [
  {
    id: 'respiratory_onset',
    question: 'Did symptoms start suddenly (within hours) or gradually?',
    whoReference: 'WHO Influenza Guidelines',
    weight: 0.9, // Increased from 0.8
    flu_indicator: 'sudden_onset',
    type: 'multiple_choice',
    category: 'pattern',
    options: ['Suddenly (within hours)', 'Gradually over days', 'Gradually over weeks']
  },
  {
    id: 'respiratory_systemic',
    question: 'Do you have severe body aches and fatigue?',
    whoReference: 'WHO Seasonal Influenza',
    weight: 0.85, // Increased from 0.8
    systemic: true,
    type: 'yes_no',
    category: 'symptom'
  },
  {
    id: 'respiratory_throat',
    question: 'Is your throat very painful when swallowing?',
    whoReference: 'WHO Streptococcal Guidelines',
    weight: 0.85, // Increased from 0.8
    bacterial_indicator: true,
    type: 'scale',
    category: 'severity',
    options: ['No pain', 'Mild pain', 'Moderate pain', 'Severe pain', 'Extreme pain']
  },
  {
    id: 'common_cold_nasal_symptoms',
    question: 'Do you have runny nose, sneezing, and nasal congestion?',
    whoReference: 'WHO Common Cold Guidelines',
    weight: 0.95, // High weight for common cold identification
    pathognomonic: true,
    type: 'yes_no',
    category: 'symptom'
  },
  {
    id: 'common_cold_mild_fever',
    question: 'Is your fever mild or absent (less than 101°F/38.3°C)?',
    whoReference: 'WHO Common Cold vs Flu',
    weight: 0.8,
    type: 'yes_no',
    category: 'symptom'
  },
  {
    id: 'common_cold_gradual_onset',
    question: 'Did your symptoms develop slowly over 2-3 days?',
    whoReference: 'WHO Viral Upper Respiratory Infection',
    weight: 0.85,
    type: 'yes_no',
    category: 'pattern'
  }
];

// Seasonal Fever Questions
export const seasonalFeverQuestions: Question[] = [
  {
    id: 'seasonal_fever_timing',
    question: 'Does your fever occur during specific seasons (monsoon, winter)?',
    whoReference: 'WHO Seasonal Disease Guidelines',
    weight: 0.85, // Increased from 0.7
    seasonal: true,
    pathognomonic: true, // Added pathognomonic flag for seasonal patterns
    type: 'multiple_choice',
    category: 'pattern',
    options: ['No pattern', 'Monsoon season', 'Winter season', 'Summer season', 'Year-round']
  },
  {
    id: 'seasonal_fever_recurrence',
    question: 'Have you had similar fever episodes in previous years?',
    whoReference: 'WHO Seasonal Disease Patterns',
    weight: 0.9, // Increased from 0.75
    pathognomonic: true, // Strong indicator for seasonal fever
    type: 'yes_no',
    category: 'pattern'
  },
  {
    id: 'seasonal_community_fever',
    question: 'Are others in your community also having fever?',
    whoReference: 'WHO Outbreak Investigation',
    weight: 0.9, // Increased from 0.8
    environmental: true,
    type: 'yes_no',
    category: 'risk_factor'
  },
  {
    id: 'seasonal_fever_mild_symptoms',
    question: 'Along with fever, do you have runny nose, sneezing, or mild cough?',
    whoReference: 'WHO Viral Fever Guidelines',
    weight: 0.8, // Increased from 0.6
    type: 'multiple_choice',
    category: 'symptom',
    options: ['None', 'Runny nose', 'Sneezing', 'Mild cough', 'All of these']
  },
  {
    id: 'seasonal_fever_body_ache',
    question: 'Do you have mild body aches with the fever?',
    whoReference: 'WHO Viral Syndrome Guidelines',
    weight: 0.75, // Increased from 0.65
    type: 'yes_no',
    category: 'symptom'
  }
];

// Allergic Rhinitis/Hay Fever Questions
export const allergyQuestions: Question[] = [
  {
    id: 'allergy_seasonal',
    question: 'Do symptoms worsen around certain plants or seasons?',
    whoReference: 'WHO Allergic Rhinitis Guidelines',
    weight: 0.9,
    seasonal: true,
    type: 'yes_no',
    category: 'pattern'
  },
  {
    id: 'allergy_eye_symptoms',
    question: 'Do you have itchy, watery eyes along with nasal symptoms?',
    whoReference: 'WHO ARIA Guidelines',
    weight: 0.85,
    allergic_pattern: true,
    type: 'yes_no',
    category: 'symptom'
  }
];

// Gastrointestinal Questions
export const gastroQuestions: Question[] = [
  {
    id: 'gastro_onset_pattern',
    question: 'When did vomiting and diarrhea start? Same time or one first?',
    whoReference: 'WHO Diarrheal Disease Guidelines',
    weight: 0.7,
    pattern: 'viral_vs_bacterial',
    type: 'multiple_choice',
    category: 'pattern',
    options: ['Same time', 'Vomiting first', 'Diarrhea first', 'Only vomiting', 'Only diarrhea']
  },
  {
    id: 'gastro_blood_mucus',
    question: 'Any blood or mucus in stool?',
    whoReference: 'WHO Dysentery Guidelines',
    weight: 0.9,
    bacterial_indicator: true,
    urgency: 'urgent',
    type: 'yes_no',
    category: 'symptom'
  }
];

// Skin Infection Questions
export const skinQuestions: Question[] = [
  {
    id: 'skin_cellulitis',
    question: 'Is the affected area red, warm, and swollen?',
    whoReference: 'WHO Skin Infection Guidelines',
    weight: 0.8,
    cellulitis_signs: true,
    type: 'yes_no',
    category: 'symptom'
  },
  {
    id: 'skin_drainage',
    question: 'Is there pus or drainage from the area?',
    whoReference: 'WHO Abscess Management',
    weight: 0.8,
    bacterial_indicator: true,
    type: 'yes_no',
    category: 'symptom'
  }
];

// Disease-specific question mapping
export const diseaseQuestionMap: Record<string, Question[]> = {
  tuberculosis: tbQuestions,
  malaria: malariaQuestions,
  dengue: dengueQuestions,
  chikungunya: chikungunyaQuestions,
  cholera: choleraQuestions,
  typhoid: typhoidQuestions,
  hepatitis_a: hepatitisAQuestions,
  respiratory: respiratoryQuestions,
  seasonal_fever: seasonalFeverQuestions,
  allergies: allergyQuestions,
  gastroenteritis: gastroQuestions,
  skin_infection: skinQuestions
};

// Question prioritization criteria
export interface QuestionPrioritization {
  whoEvidenceLevel: 'high' | 'medium' | 'low';
  icmrGuidelines: boolean;
  diagnosticAccuracy: number; // Sensitivity/Specificity
  culturalAdaptation: number;
  ruralAppropriateness: number;
}

// Question Engine Class
export class QuestionEngine {
  private conversationHistory: Answer[] = [];
  private currentDiseaseScores: Record<string, number> = {};
  private maxQuestionsPerSession = 10; // Increased from 7 to 10
  private minConfidenceGain = 0.1;
  private targetConfidence = 0.6; // 60% confidence target
  private minSymptomsForReduction = 3; // If fewer symptoms, ask more questions

  /**
   * Generate the next most informative question
   */
  generateNextQuestion(
    symptoms: Symptom[],
    diseaseScores: Record<string, number>,
    conversationHistory: Answer[],
    userProfile: UserProfile
  ): Question | null {
    this.conversationHistory = conversationHistory;
    this.currentDiseaseScores = diseaseScores;

    // Calculate current confidence level
    const currentConfidence = this.getCurrentConfidence(diseaseScores);
    
    // Determine max questions based on symptom count and confidence
    let effectiveMaxQuestions = this.maxQuestionsPerSession;
    if (symptoms.length < this.minSymptomsForReduction) {
      effectiveMaxQuestions = Math.min(15, this.maxQuestionsPerSession + 5); // Increase to 15 for limited symptoms
    }

    // Continue asking if confidence is below target and haven't reached max questions
    const shouldContinueAsking = currentConfidence < this.targetConfidence && 
                                conversationHistory.length < effectiveMaxQuestions;

    if (!shouldContinueAsking) {
      return null;
    }

    // Get all potential questions with enhanced candidate selection
    const candidateQuestions = this.getCandidateQuestions(diseaseScores, userProfile, symptoms);
    
    // Filter out already asked questions
    const askedQuestionIds = conversationHistory.map(a => a.questionId);
    const availableQuestions = candidateQuestions.filter(q => !askedQuestionIds.includes(q.id));

    if (availableQuestions.length === 0) {
      return null;
    }

    // Calculate information gain for each question
    const questionsWithGain = availableQuestions.map(question => ({
      question,
      informationGain: this.calculateInformationGain(question, diseaseScores),
      confidenceBoost: this.calculateConfidenceBoost(question, diseaseScores)
    }));

    // Sort by confidence boost and information gain
    questionsWithGain.sort((a, b) => {
      // Prioritize urgent questions
      if (a.question.urgency === 'immediate_referral' && b.question.urgency !== 'immediate_referral') {
        return -1;
      }
      if (b.question.urgency === 'immediate_referral' && a.question.urgency !== 'immediate_referral') {
        return 1;
      }

      // Prioritize pathognomonic symptoms
      if (a.question.pathognomonic && !b.question.pathognomonic) {
        return -1;
      }
      if (b.question.pathognomonic && !a.question.pathognomonic) {
        return 1;
      }

      // Then by confidence boost potential
      if (Math.abs(a.confidenceBoost - b.confidenceBoost) > 0.05) {
        return b.confidenceBoost - a.confidenceBoost;
      }

      // Finally by information gain
      return b.informationGain - a.informationGain;
    });

    const bestQuestion = questionsWithGain[0];
    
    // Lower threshold for information gain when confidence is low
    const minGainThreshold = currentConfidence < 0.4 ? 0.05 : this.minConfidenceGain;
    
    if (bestQuestion.informationGain < minGainThreshold) {
      return null;
    }

    return bestQuestion.question;
  }

  /**
   * Calculate information gain for a question
   */
  calculateInformationGain(
    question: Question,
    currentDiseaseDistribution: Record<string, number>
  ): number {
    // Higher weight questions provide more information
    let gain = question.weight * 0.4;

    // Pathognomonic symptoms provide high information gain
    if (question.pathognomonic) {
      gain += 0.3;
    }

    // Warning signs are high priority
    if (question.warningSign || question.urgency === 'immediate_referral') {
      gain += 0.5;
    }

    // Questions that can differentiate between top diseases are valuable
    const topDiseases = Object.entries(currentDiseaseDistribution)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 3)
      .map(([disease]) => disease);

    const relevantDiseases = this.getRelevantDiseases(question);
    const differentiationValue = topDiseases.filter(disease => 
      relevantDiseases.includes(disease)
    ).length;

    gain += differentiationValue * 0.2;

    // Environmental and risk factor questions have moderate gain
    if (question.environmental || question.riskFactor) {
      gain += 0.15;
    }

    return Math.min(1.0, gain);
  }

  /**
   * Validate WHO compliance of a question
   */
  validateWHOCompliance(question: Question): boolean {
    // Must have WHO reference
    if (!question.whoReference || !question.whoReference.includes('WHO')) {
      return false;
    }

    // Must have appropriate weight (evidence-based)
    if (question.weight < 0.1 || question.weight > 1.0) {
      return false;
    }

    // Pathognomonic symptoms should have high weight
    if (question.pathognomonic && question.weight < 0.8) {
      return false;
    }

    // Warning signs must have urgency classification
    if (question.warningSign && !question.urgency) {
      return false;
    }

    return true;
  }

  /**
   * Calculate current confidence level based on disease scores
   */
  private getCurrentConfidence(diseaseScores: Record<string, number>): number {
    if (Object.keys(diseaseScores).length === 0) return 0;

    const scores = Object.values(diseaseScores).sort((a, b) => b - a);
    const topScore = scores[0] || 0;
    const secondScore = scores[1] || 0;
    
    // Confidence based on separation between top two scores
    const separation = topScore - secondScore;
    const normalizedTop = Math.min(topScore / 100, 1.0); // Normalize to 0-1
    
    // Confidence increases with higher top score and greater separation
    return Math.min(0.95, normalizedTop * 0.7 + (separation / 100) * 0.3);
  }

  /**
   * Calculate potential confidence boost from asking a question
   */
  private calculateConfidenceBoost(
    question: Question,
    currentDiseaseDistribution: Record<string, number>
  ): number {
    // Higher boost for high-weight questions
    let boost = question.weight * 0.3;
    
    // Pathognomonic symptoms provide high confidence boost
    if (question.pathognomonic) {
      boost += 0.4;
    }
    
    // Warning signs provide moderate boost
    if (question.warningSign) {
      boost += 0.2;
    }
    
    // Urgent questions provide high boost
    if (question.urgency === 'immediate_referral') {
      boost += 0.3;
    } else if (question.urgency === 'urgent') {
      boost += 0.15;
    }
    
    return Math.min(1.0, boost);
  }

  /**
   * Get candidate questions based on current disease scores
   */
  private getCandidateQuestions(
    diseaseScores: Record<string, number>,
    userProfile: UserProfile,
    symptoms?: Symptom[]
  ): Question[] {
    const candidates: Question[] = [];

    // Get top 5 most likely diseases (increased for better coverage)
    const topDiseases = Object.entries(diseaseScores)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 5)
      .map(([disease]) => disease);

    // Add questions for top diseases
    topDiseases.forEach(disease => {
      const questions = diseaseQuestionMap[disease] || [];
      candidates.push(...questions);
    });

    // Add seasonal fever questions if fever is mentioned and symptoms are limited
    const hasLimitedSymptoms = symptoms && symptoms.length < this.minSymptomsForReduction;
    const hasFeverSymptom = symptoms?.some(s => s.name.toLowerCase().includes('fever'));
    
    if (hasLimitedSymptoms && hasFeverSymptom) {
      candidates.push(...seasonalFeverQuestions);
    }

    // Add more cholera questions if GI symptoms present
    const hasGISymptoms = symptoms?.some(s => 
      s.name.toLowerCase().includes('diarrhea') || 
      s.name.toLowerCase().includes('stomach') ||
      s.name.toLowerCase().includes('vomiting')
    );
    
    if (hasGISymptoms || topDiseases.includes('cholera')) {
      // Add extra cholera questions beyond the base set
      candidates.push(...choleraQuestions);
    }

    // Add typhoid questions if fever + headache combination
    const hasFever = symptoms?.some(s => s.name.toLowerCase().includes('fever'));
    const hasHeadache = symptoms?.some(s => s.name.toLowerCase().includes('headache'));
    
    if (hasFever && hasHeadache) {
      candidates.push(...typhoidQuestions);
    }

    // Add age-appropriate questions
    if (userProfile.age !== undefined) {
      if (userProfile.age < 5) {
        // Add pediatric-specific questions
        candidates.push(...this.getPediatricQuestions());
      } else if (userProfile.age > 65) {
        // Add geriatric-specific questions
        candidates.push(...this.getGeriatricQuestions());
      }
    }

    // Add pregnancy-specific questions
    if (userProfile.pregnancy) {
      candidates.push(...this.getPregnancyQuestions());
    }

    // Remove duplicates and validate WHO compliance
    const uniqueQuestions = candidates.filter((question, index, self) => 
      index === self.findIndex(q => q.id === question.id) &&
      this.validateWHOCompliance(question)
    );

    return uniqueQuestions;
  }

  /**
   * Get diseases relevant to a specific question
   */
  private getRelevantDiseases(question: Question): string[] {
    const relevantDiseases: string[] = [];

    for (const [disease, questions] of Object.entries(diseaseQuestionMap)) {
      if (questions.some(q => q.id === question.id)) {
        relevantDiseases.push(disease);
      }
    }

    return relevantDiseases;
  }

  /**
   * Get pediatric-specific questions
   */
  private getPediatricQuestions(): Question[] {
    return [
      {
        id: 'pediatric_feeding',
        question: 'Is the child feeding normally?',
        whoReference: 'WHO IMCI Guidelines',
        weight: 0.8,
        type: 'yes_no',
        category: 'symptom'
      },
      {
        id: 'pediatric_activity',
        question: 'Is the child playing and active as usual?',
        whoReference: 'WHO Child Health Guidelines',
        weight: 0.7,
        type: 'yes_no',
        category: 'symptom'
      }
    ];
  }

  /**
   * Get geriatric-specific questions
   */
  private getGeriatricQuestions(): Question[] {
    return [
      {
        id: 'geriatric_confusion',
        question: 'Any new confusion or changes in mental state?',
        whoReference: 'WHO Healthy Ageing Guidelines',
        weight: 0.8,
        urgency: 'urgent',
        type: 'yes_no',
        category: 'symptom'
      }
    ];
  }

  /**
   * Get pregnancy-specific questions
   */
  private getPregnancyQuestions(): Question[] {
    return [
      {
        id: 'pregnancy_bleeding',
        question: 'Any vaginal bleeding during pregnancy?',
        whoReference: 'WHO Maternal Health Guidelines',
        weight: 0.95,
        urgency: 'immediate_referral',
        type: 'yes_no',
        category: 'symptom'
      }
    ];
  }

  /**
   * Process answer and update disease probabilities
   */
  processAnswer(answer: Answer): Record<string, number> {
    this.conversationHistory.push(answer);
    
    // Update disease scores based on the answer
    const updatedScores = { ...this.currentDiseaseScores };
    
    // Find the question that was answered
    const allQuestions = Object.values(diseaseQuestionMap).flat();
    const answeredQuestion = allQuestions.find(q => q.id === answer.questionId);
    
    if (answeredQuestion) {
      const relevantDiseases = this.getRelevantDiseases(answeredQuestion);
      
      relevantDiseases.forEach(disease => {
        if (answer.answer === true || answer.answer === 'yes') {
          // Positive answer increases disease probability
          let scoreIncrease = answeredQuestion.weight * 10; // Scale weight for better impact
          
          // Apply higher weight for pathognomonic symptoms
          if (answeredQuestion.pathognomonic) {
            scoreIncrease *= 2.0;
          }
          
          // Apply higher weight for warning signs
          if (answeredQuestion.warningSign) {
            scoreIncrease *= 1.8;
          }
          
          // Apply urgency multiplier
          if (answeredQuestion.urgency === 'immediate_referral') {
            scoreIncrease *= 2.5;
          } else if (answeredQuestion.urgency === 'urgent') {
            scoreIncrease *= 1.5;
          }
          
          updatedScores[disease] = (updatedScores[disease] || 0) + scoreIncrease;
          
          // Apply risk multiplier if present
          if (answeredQuestion.riskMultiplier) {
            updatedScores[disease] *= answeredQuestion.riskMultiplier;
          }
        } else if (answer.answer === false || answer.answer === 'no') {
          // Negative answer decreases disease probability
          let scoreDecrease = answeredQuestion.weight * 5; // Less penalty for negative answers
          
          // Higher penalty for ruling out pathognomonic symptoms
          if (answeredQuestion.pathognomonic) {
            scoreDecrease *= 1.5;
          }
          
          updatedScores[disease] = Math.max(0, (updatedScores[disease] || 0) - scoreDecrease);
        } else if (answer.answer === 'unknown') {
          // Unknown answers have minimal impact but still provide some information
          let scoreAdjustment = answeredQuestion.weight * 2; // Small positive adjustment for uncertainty
          updatedScores[disease] = (updatedScores[disease] || 0) + scoreAdjustment;
        }
      });
    }
    
    this.currentDiseaseScores = updatedScores;
    return updatedScores;
  }

  /**
   * Get conversation summary for clinical decision support
   */
  getConversationSummary(): {
    totalQuestions: number;
    urgentFindings: Answer[];
    riskFactors: Answer[];
    pathognomonic: Answer[];
    confidence: number;
  } {
    const urgentFindings = this.conversationHistory.filter(answer => {
      const allQuestions = Object.values(diseaseQuestionMap).flat();
      const question = allQuestions.find(q => q.id === answer.questionId);
      return question?.urgency === 'immediate_referral' && answer.answer === true;
    });

    const riskFactors = this.conversationHistory.filter(answer => {
      const allQuestions = Object.values(diseaseQuestionMap).flat();
      const question = allQuestions.find(q => q.id === answer.questionId);
      return question?.riskFactor === true && answer.answer === true;
    });

    const pathognomonic = this.conversationHistory.filter(answer => {
      const allQuestions = Object.values(diseaseQuestionMap).flat();
      const question = allQuestions.find(q => q.id === answer.questionId);
      return question?.pathognomonic === true && answer.answer === true;
    });

    // Calculate overall confidence based on question quality and answers
    const totalWeight = this.conversationHistory.reduce((sum, answer) => {
      const allQuestions = Object.values(diseaseQuestionMap).flat();
      const question = allQuestions.find(q => q.id === answer.questionId);
      return sum + (question?.weight || 0);
    }, 0);

    const confidence = Math.min(0.95, totalWeight / this.maxQuestionsPerSession);

    return {
      totalQuestions: this.conversationHistory.length,
      urgentFindings,
      riskFactors,
      pathognomonic,
      confidence
    };
  }
}

// Export singleton instance
export const questionEngine = new QuestionEngine();
