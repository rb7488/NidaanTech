/**
 * Comprehensive Vaccination Dataset
 * Based on WHO guidelines, Indian immunization schedule, and international best practices
 */

export interface VaccineSchedule {
  id: string;
  vaccineName: string;
  ageMonthsOrRule: string;
  ageInMonths?: number;
  ageCategory: 'birth' | 'infant' | 'child' | 'adolescent' | 'adult' | 'pregnancy' | 'special';
  doseNumber?: number;
  isBooster?: boolean;
  description: string;
  protectsAgainst: string[];
  administrationRoute: 'oral' | 'intramuscular' | 'intradermal' | 'subcutaneous';
  sideEffects: string[];
  contraindications: string[];
  specialNotes?: string;
  isOptional?: boolean;
  priority: 'essential' | 'recommended' | 'optional';
  whoRecommended: boolean;
  indianSchedule: boolean;
}

export interface VaccinationCenter {
  id: string;
  name: string;
  address: string;
  pincode: string;
  district: string;
  state: string;
  type: 'government' | 'private' | 'ngo';
  availableVaccines: string[];
  operatingHours: string;
  contactNumber: string;
  hasRefrigeration: boolean;
  emergencyServices: boolean;
}

export interface VaccinationReminder {
  id: string;
  userId: string;
  vaccineId: string;
  dueDate: string;
  isOverdue: boolean;
  reminderSent: boolean;
  completed: boolean;
}

// Comprehensive WHO and Indian vaccination schedule
export const vaccinationSchedule: VaccineSchedule[] = [
  // Birth (0 months)
  {
    id: 'bcg_birth',
    vaccineName: 'BCG',
    ageMonthsOrRule: 'At birth (within 24h)',
    ageInMonths: 0,
    ageCategory: 'birth',
    doseNumber: 1,
    description: 'Bacillus Calmette-Guérin vaccine',
    protectsAgainst: ['Tuberculosis', 'Severe childhood tuberculosis', 'TB meningitis'],
    administrationRoute: 'intradermal',
    sideEffects: ['Local swelling', 'Small scar formation', 'Mild fever'],
    contraindications: ['Immunocompromised infants', 'HIV positive mothers', 'Severe illness'],
    priority: 'essential',
    whoRecommended: true,
    indianSchedule: true
  },
  {
    id: 'opv_0',
    vaccineName: 'OPV-0',
    ageMonthsOrRule: 'At birth',
    ageInMonths: 0,
    ageCategory: 'birth',
    doseNumber: 0,
    description: 'Oral Polio Vaccine zero dose',
    protectsAgainst: ['Poliomyelitis'],
    administrationRoute: 'oral',
    sideEffects: ['Very rare: vaccine-associated paralytic polio'],
    contraindications: ['Immunodeficiency', 'Severe diarrhea'],
    specialNotes: 'Early protection against polio, given before discharge from hospital',
    priority: 'essential',
    whoRecommended: true,
    indianSchedule: true
  },
  {
    id: 'hep_b_birth',
    vaccineName: 'Hepatitis B Birth Dose',
    ageMonthsOrRule: 'At birth (within 24h)',
    ageInMonths: 0,
    ageCategory: 'birth',
    doseNumber: 1,
    description: 'Hepatitis B vaccine birth dose',
    protectsAgainst: ['Hepatitis B', 'Perinatal transmission'],
    administrationRoute: 'intramuscular',
    sideEffects: ['Pain at injection site', 'Mild fever', 'Fatigue'],
    contraindications: ['Severe illness', 'Known allergy to vaccine components'],
    specialNotes: 'Prevents perinatal transmission of Hepatitis B',
    priority: 'essential',
    whoRecommended: true,
    indianSchedule: true
  },

  // 6 weeks (1.5 months)
  {
    id: 'pentavalent_1',
    vaccineName: 'Pentavalent-1 (DPT + HepB + Hib)',
    ageMonthsOrRule: '6 weeks',
    ageInMonths: 1.5,
    ageCategory: 'infant',
    doseNumber: 1,
    description: 'Five-in-one vaccine',
    protectsAgainst: ['Diphtheria', 'Pertussis', 'Tetanus', 'Hepatitis B', 'Haemophilus influenzae type b'],
    administrationRoute: 'intramuscular',
    sideEffects: ['Fever', 'Irritability', 'Pain at injection site', 'Drowsiness'],
    contraindications: ['Previous severe reaction', 'Progressive neurological disorder'],
    priority: 'essential',
    whoRecommended: true,
    indianSchedule: true
  },
  {
    id: 'opv_1',
    vaccineName: 'OPV-1',
    ageMonthsOrRule: '6 weeks',
    ageInMonths: 1.5,
    ageCategory: 'infant',
    doseNumber: 1,
    description: 'Oral Polio Vaccine first dose',
    protectsAgainst: ['Poliomyelitis'],
    administrationRoute: 'oral',
    sideEffects: ['Very rare: vaccine-associated paralytic polio'],
    contraindications: ['Immunodeficiency', 'Severe diarrhea'],
    priority: 'essential',
    whoRecommended: true,
    indianSchedule: true
  },
  {
    id: 'fipv_1',
    vaccineName: 'fIPV-1',
    ageMonthsOrRule: '6 weeks',
    ageInMonths: 1.5,
    ageCategory: 'infant',
    doseNumber: 1,
    description: 'Fractional Inactivated Polio Vaccine, intradermal',
    protectsAgainst: ['Poliomyelitis'],
    administrationRoute: 'intradermal',
    sideEffects: ['Local reaction', 'Mild pain'],
    contraindications: ['Severe illness', 'Bleeding disorders'],
    priority: 'essential',
    whoRecommended: true,
    indianSchedule: true
  },
  {
    id: 'rotavirus_1',
    vaccineName: 'Rotavirus-1',
    ageMonthsOrRule: '6 weeks',
    ageInMonths: 1.5,
    ageCategory: 'infant',
    doseNumber: 1,
    description: 'Rotavirus vaccine first dose',
    protectsAgainst: ['Rotavirus diarrhea', 'Severe gastroenteritis'],
    administrationRoute: 'oral',
    sideEffects: ['Mild diarrhea', 'Vomiting', 'Irritability'],
    contraindications: ['Immunodeficiency', 'Intussusception history'],
    priority: 'essential',
    whoRecommended: true,
    indianSchedule: true
  },
  {
    id: 'pcv_1',
    vaccineName: 'PCV-1',
    ageMonthsOrRule: '6 weeks',
    ageInMonths: 1.5,
    ageCategory: 'infant',
    doseNumber: 1,
    description: 'Pneumococcal Conjugate Vaccine',
    protectsAgainst: ['Pneumococcal pneumonia', 'Meningitis', 'Sepsis'],
    administrationRoute: 'intramuscular',
    sideEffects: ['Fever', 'Irritability', 'Pain at injection site'],
    contraindications: ['Severe illness', 'Previous severe reaction'],
    priority: 'essential',
    whoRecommended: true,
    indianSchedule: true
  },

  // 10 weeks (2.5 months)
  {
    id: 'pentavalent_2',
    vaccineName: 'Pentavalent-2',
    ageMonthsOrRule: '10 weeks',
    ageInMonths: 2.5,
    ageCategory: 'infant',
    doseNumber: 2,
    description: 'Second dose of DPT + HepB + Hib',
    protectsAgainst: ['Diphtheria', 'Pertussis', 'Tetanus', 'Hepatitis B', 'Haemophilus influenzae type b'],
    administrationRoute: 'intramuscular',
    sideEffects: ['Fever', 'Irritability', 'Pain at injection site'],
    contraindications: ['Previous severe reaction', 'Progressive neurological disorder'],
    priority: 'essential',
    whoRecommended: true,
    indianSchedule: true
  },
  {
    id: 'opv_2',
    vaccineName: 'OPV-2',
    ageMonthsOrRule: '10 weeks',
    ageInMonths: 2.5,
    ageCategory: 'infant',
    doseNumber: 2,
    description: 'Second polio dose',
    protectsAgainst: ['Poliomyelitis'],
    administrationRoute: 'oral',
    sideEffects: ['Very rare: vaccine-associated paralytic polio'],
    contraindications: ['Immunodeficiency', 'Severe diarrhea'],
    priority: 'essential',
    whoRecommended: true,
    indianSchedule: true
  },
  {
    id: 'rotavirus_2',
    vaccineName: 'Rotavirus-2',
    ageMonthsOrRule: '10 weeks',
    ageInMonths: 2.5,
    ageCategory: 'infant',
    doseNumber: 2,
    description: 'Second dose of rotavirus vaccine',
    protectsAgainst: ['Rotavirus diarrhea', 'Severe gastroenteritis'],
    administrationRoute: 'oral',
    sideEffects: ['Mild diarrhea', 'Vomiting', 'Irritability'],
    contraindications: ['Immunodeficiency', 'Intussusception history'],
    priority: 'essential',
    whoRecommended: true,
    indianSchedule: true
  },

  // 14 weeks (3.5 months)
  {
    id: 'pentavalent_3',
    vaccineName: 'Pentavalent-3',
    ageMonthsOrRule: '14 weeks',
    ageInMonths: 3.5,
    ageCategory: 'infant',
    doseNumber: 3,
    description: 'Third dose of DPT + HepB + Hib',
    protectsAgainst: ['Diphtheria', 'Pertussis', 'Tetanus', 'Hepatitis B', 'Haemophilus influenzae type b'],
    administrationRoute: 'intramuscular',
    sideEffects: ['Fever', 'Irritability', 'Pain at injection site'],
    contraindications: ['Previous severe reaction', 'Progressive neurological disorder'],
    priority: 'essential',
    whoRecommended: true,
    indianSchedule: true
  },
  {
    id: 'opv_3',
    vaccineName: 'OPV-3',
    ageMonthsOrRule: '14 weeks',
    ageInMonths: 3.5,
    ageCategory: 'infant',
    doseNumber: 3,
    description: 'Third polio dose',
    protectsAgainst: ['Poliomyelitis'],
    administrationRoute: 'oral',
    sideEffects: ['Very rare: vaccine-associated paralytic polio'],
    contraindications: ['Immunodeficiency', 'Severe diarrhea'],
    priority: 'essential',
    whoRecommended: true,
    indianSchedule: true
  },
  {
    id: 'fipv_2',
    vaccineName: 'fIPV-2',
    ageMonthsOrRule: '14 weeks',
    ageInMonths: 3.5,
    ageCategory: 'infant',
    doseNumber: 2,
    description: 'Second fractional IPV dose',
    protectsAgainst: ['Poliomyelitis'],
    administrationRoute: 'intradermal',
    sideEffects: ['Local reaction', 'Mild pain'],
    contraindications: ['Severe illness', 'Bleeding disorders'],
    priority: 'essential',
    whoRecommended: true,
    indianSchedule: true
  },
  {
    id: 'rotavirus_3',
    vaccineName: 'Rotavirus-3',
    ageMonthsOrRule: '14 weeks',
    ageInMonths: 3.5,
    ageCategory: 'infant',
    doseNumber: 3,
    description: 'Third rotavirus dose (if 3-dose schedule)',
    protectsAgainst: ['Rotavirus diarrhea', 'Severe gastroenteritis'],
    administrationRoute: 'oral',
    sideEffects: ['Mild diarrhea', 'Vomiting', 'Irritability'],
    contraindications: ['Immunodeficiency', 'Intussusception history'],
    priority: 'essential',
    whoRecommended: true,
    indianSchedule: true
  },
  {
    id: 'pcv_2',
    vaccineName: 'PCV-2',
    ageMonthsOrRule: '14 weeks',
    ageInMonths: 3.5,
    ageCategory: 'infant',
    doseNumber: 2,
    description: 'Second pneumococcal dose',
    protectsAgainst: ['Pneumococcal pneumonia', 'Meningitis', 'Sepsis'],
    administrationRoute: 'intramuscular',
    sideEffects: ['Fever', 'Irritability', 'Pain at injection site'],
    contraindications: ['Severe illness', 'Previous severe reaction'],
    priority: 'essential',
    whoRecommended: true,
    indianSchedule: true
  },

  // 9 months
  {
    id: 'measles_rubella_1',
    vaccineName: 'Measles-Rubella (MR-1)',
    ageMonthsOrRule: '9 months',
    ageInMonths: 9,
    ageCategory: 'infant',
    doseNumber: 1,
    description: 'First dose of MR vaccine',
    protectsAgainst: ['Measles', 'Rubella', 'Congenital rubella syndrome'],
    administrationRoute: 'subcutaneous',
    sideEffects: ['Fever', 'Rash', 'Joint pain', 'Swollen glands'],
    contraindications: ['Pregnancy', 'Immunodeficiency', 'Recent blood transfusion'],
    priority: 'essential',
    whoRecommended: true,
    indianSchedule: true
  },
  {
    id: 'je_1',
    vaccineName: 'JE-1',
    ageMonthsOrRule: '9 months (endemic districts)',
    ageInMonths: 9,
    ageCategory: 'infant',
    doseNumber: 1,
    description: 'Japanese Encephalitis vaccine',
    protectsAgainst: ['Japanese Encephalitis'],
    administrationRoute: 'subcutaneous',
    sideEffects: ['Pain at injection site', 'Fever', 'Headache'],
    contraindications: ['Severe illness', 'Previous severe reaction'],
    specialNotes: 'Only in endemic districts like Odisha, Assam, West Bengal',
    priority: 'essential',
    whoRecommended: true,
    indianSchedule: true
  },

  // 16-24 months
  {
    id: 'dpt_booster_1',
    vaccineName: 'DPT Booster-1',
    ageMonthsOrRule: '16-24 months',
    ageInMonths: 18,
    ageCategory: 'child',
    doseNumber: 1,
    isBooster: true,
    description: 'First DPT booster',
    protectsAgainst: ['Diphtheria', 'Pertussis', 'Tetanus'],
    administrationRoute: 'intramuscular',
    sideEffects: ['Fever', 'Pain at injection site', 'Irritability'],
    contraindications: ['Previous severe reaction', 'Progressive neurological disorder'],
    priority: 'essential',
    whoRecommended: true,
    indianSchedule: true
  },
  {
    id: 'opv_booster',
    vaccineName: 'OPV Booster',
    ageMonthsOrRule: '16-24 months',
    ageInMonths: 18,
    ageCategory: 'child',
    isBooster: true,
    description: 'OPV booster dose',
    protectsAgainst: ['Poliomyelitis'],
    administrationRoute: 'oral',
    sideEffects: ['Very rare: vaccine-associated paralytic polio'],
    contraindications: ['Immunodeficiency', 'Severe diarrhea'],
    priority: 'essential',
    whoRecommended: true,
    indianSchedule: true
  },
  {
    id: 'measles_rubella_2',
    vaccineName: 'Measles-Rubella (MR-2)',
    ageMonthsOrRule: '16-24 months',
    ageInMonths: 18,
    ageCategory: 'child',
    doseNumber: 2,
    description: 'Second dose of MR vaccine',
    protectsAgainst: ['Measles', 'Rubella', 'Congenital rubella syndrome'],
    administrationRoute: 'subcutaneous',
    sideEffects: ['Fever', 'Rash', 'Joint pain', 'Swollen glands'],
    contraindications: ['Pregnancy', 'Immunodeficiency', 'Recent blood transfusion'],
    priority: 'essential',
    whoRecommended: true,
    indianSchedule: true
  },

  // 5-6 years (School entry)
  {
    id: 'dpt_booster_2',
    vaccineName: 'DPT Booster-2',
    ageMonthsOrRule: '5-6 years',
    ageInMonths: 60,
    ageCategory: 'child',
    doseNumber: 2,
    isBooster: true,
    description: 'Second DPT booster at school entry',
    protectsAgainst: ['Diphtheria', 'Pertussis', 'Tetanus'],
    administrationRoute: 'intramuscular',
    sideEffects: ['Fever', 'Pain at injection site', 'Fatigue'],
    contraindications: ['Previous severe reaction', 'Progressive neurological disorder'],
    priority: 'essential',
    whoRecommended: true,
    indianSchedule: true
  },

  // 10 years
  {
    id: 'td_10_years',
    vaccineName: 'Td (Tetanus-Diphtheria)',
    ageMonthsOrRule: '10 years',
    ageInMonths: 120,
    ageCategory: 'child',
    description: 'Tetanus-Diphtheria booster',
    protectsAgainst: ['Tetanus', 'Diphtheria'],
    administrationRoute: 'intramuscular',
    sideEffects: ['Pain at injection site', 'Fever', 'Headache'],
    contraindications: ['Previous severe reaction', 'Severe illness'],
    priority: 'essential',
    whoRecommended: true,
    indianSchedule: true
  },

  // 16 years
  {
    id: 'td_16_years',
    vaccineName: 'Td (Tetanus-Diphtheria)',
    ageMonthsOrRule: '16 years',
    ageInMonths: 192,
    ageCategory: 'adolescent',
    description: 'Tetanus-Diphtheria booster for adolescents',
    protectsAgainst: ['Tetanus', 'Diphtheria'],
    administrationRoute: 'intramuscular',
    sideEffects: ['Pain at injection site', 'Fever', 'Headache'],
    contraindications: ['Previous severe reaction', 'Severe illness'],
    priority: 'essential',
    whoRecommended: true,
    indianSchedule: true
  },

  // Adolescent vaccines (9-14 years for girls)
  {
    id: 'hpv',
    vaccineName: 'HPV',
    ageMonthsOrRule: '9-14 years (girls)',
    ageInMonths: 132, // 11 years average
    ageCategory: 'adolescent',
    description: 'Human Papillomavirus vaccine',
    protectsAgainst: ['Cervical cancer', 'Genital warts', 'Other HPV-related cancers'],
    administrationRoute: 'intramuscular',
    sideEffects: ['Pain at injection site', 'Fever', 'Headache', 'Dizziness'],
    contraindications: ['Pregnancy', 'Severe illness', 'Previous severe reaction'],
    specialNotes: 'Prevents cervical cancer, best before sexual debut',
    priority: 'recommended',
    whoRecommended: true,
    indianSchedule: true
  },

  // Pregnancy vaccines
  {
    id: 'td_pregnancy',
    vaccineName: 'Td/Tt (Tetanus or Td booster)',
    ageMonthsOrRule: 'Pregnancy',
    ageCategory: 'pregnancy',
    description: 'Tetanus protection during pregnancy',
    protectsAgainst: ['Tetanus', 'Neonatal tetanus'],
    administrationRoute: 'intramuscular',
    sideEffects: ['Pain at injection site', 'Mild fever'],
    contraindications: ['Previous severe reaction'],
    specialNotes: 'Protects mother and newborn from tetanus',
    priority: 'essential',
    whoRecommended: true,
    indianSchedule: true
  },
  {
    id: 'covid_19_pregnancy',
    vaccineName: 'COVID-19',
    ageMonthsOrRule: 'Pregnancy',
    ageCategory: 'pregnancy',
    description: 'COVID-19 vaccination during pregnancy',
    protectsAgainst: ['COVID-19', 'Severe COVID-19 complications'],
    administrationRoute: 'intramuscular',
    sideEffects: ['Pain at injection site', 'Fever', 'Fatigue', 'Headache'],
    contraindications: ['Previous severe allergic reaction to vaccine'],
    specialNotes: 'As per Govt. of India recommendation during/after pregnancy',
    priority: 'recommended',
    whoRecommended: true,
    indianSchedule: true
  },
  {
    id: 'influenza_pregnancy',
    vaccineName: 'Influenza vaccine',
    ageMonthsOrRule: 'Pregnancy',
    ageCategory: 'pregnancy',
    description: 'Seasonal influenza vaccine',
    protectsAgainst: ['Seasonal influenza', 'Flu complications'],
    administrationRoute: 'intramuscular',
    sideEffects: ['Pain at injection site', 'Mild fever', 'Muscle aches'],
    contraindications: ['Severe egg allergy', 'Previous severe reaction'],
    specialNotes: 'Optional, protects mother and infant against flu',
    isOptional: true,
    priority: 'optional',
    whoRecommended: true,
    indianSchedule: false
  },
  {
    id: 'tdap_pregnancy',
    vaccineName: 'Tdap',
    ageMonthsOrRule: 'Pregnancy (27-36 weeks)',
    ageCategory: 'pregnancy',
    description: 'Tetanus, Diphtheria, and Pertussis vaccine',
    protectsAgainst: ['Tetanus', 'Diphtheria', 'Pertussis'],
    administrationRoute: 'intramuscular',
    sideEffects: ['Pain at injection site', 'Fever', 'Headache'],
    contraindications: ['Previous severe reaction'],
    specialNotes: 'Optional booster for pertussis protection in newborn',
    isOptional: true,
    priority: 'recommended',
    whoRecommended: true,
    indianSchedule: false
  },

  // Adult vaccines
  {
    id: 'rubella_adult_women',
    vaccineName: 'Rubella',
    ageMonthsOrRule: 'Adolescent/Adult Women',
    ageCategory: 'adult',
    description: 'Rubella vaccine for women of childbearing age',
    protectsAgainst: ['Rubella', 'Congenital rubella syndrome'],
    administrationRoute: 'subcutaneous',
    sideEffects: ['Fever', 'Rash', 'Joint pain', 'Swollen glands'],
    contraindications: ['Pregnancy', 'Immunodeficiency', 'Recent blood transfusion'],
    specialNotes: 'If not given earlier, prevents congenital rubella syndrome',
    priority: 'recommended',
    whoRecommended: true,
    indianSchedule: true
  },

  // Additional WHO recommended vaccines
  {
    id: 'hepatitis_a',
    vaccineName: 'Hepatitis A',
    ageMonthsOrRule: '12-23 months',
    ageInMonths: 15,
    ageCategory: 'child',
    description: 'Hepatitis A vaccine',
    protectsAgainst: ['Hepatitis A'],
    administrationRoute: 'intramuscular',
    sideEffects: ['Pain at injection site', 'Fever', 'Fatigue'],
    contraindications: ['Severe illness', 'Previous severe reaction'],
    isOptional: true,
    priority: 'recommended',
    whoRecommended: true,
    indianSchedule: false
  },
  {
    id: 'varicella',
    vaccineName: 'Varicella (Chickenpox)',
    ageMonthsOrRule: '12-15 months',
    ageInMonths: 13,
    ageCategory: 'child',
    description: 'Chickenpox vaccine',
    protectsAgainst: ['Chickenpox', 'Shingles'],
    administrationRoute: 'subcutaneous',
    sideEffects: ['Mild rash', 'Fever', 'Pain at injection site'],
    contraindications: ['Pregnancy', 'Immunodeficiency', 'Recent blood transfusion'],
    isOptional: true,
    priority: 'recommended',
    whoRecommended: true,
    indianSchedule: false
  },
  {
    id: 'mmr',
    vaccineName: 'MMR (Measles-Mumps-Rubella)',
    ageMonthsOrRule: '12-15 months',
    ageInMonths: 13,
    ageCategory: 'child',
    description: 'Combined MMR vaccine',
    protectsAgainst: ['Measles', 'Mumps', 'Rubella'],
    administrationRoute: 'subcutaneous',
    sideEffects: ['Fever', 'Rash', 'Joint pain', 'Swollen glands'],
    contraindications: ['Pregnancy', 'Immunodeficiency', 'Recent blood transfusion'],
    isOptional: true,
    priority: 'recommended',
    whoRecommended: true,
    indianSchedule: false
  }
];

// Vaccination centers data
export const vaccinationCenters: VaccinationCenter[] = [
  {
    id: 'puri_phc_1',
    name: 'Puri Primary Health Centre',
    address: 'Grand Road, Puri',
    pincode: '751001',
    district: 'Puri',
    state: 'Odisha',
    type: 'government',
    availableVaccines: ['BCG', 'OPV', 'Pentavalent', 'Rotavirus', 'PCV', 'MR', 'JE', 'DPT', 'Td', 'HPV'],
    operatingHours: 'Mon-Fri 9AM-5PM, Sat 9AM-1PM',
    contactNumber: '+91-6752-222333',
    hasRefrigeration: true,
    emergencyServices: false
  },
  {
    id: 'bhubaneswar_aiims',
    name: 'AIIMS Bhubaneswar',
    address: 'Sijua, Patrapada, Bhubaneswar',
    pincode: '751019',
    district: 'Khordha',
    state: 'Odisha',
    type: 'government',
    availableVaccines: ['All vaccines', 'Special vaccines', 'Travel vaccines'],
    operatingHours: '24/7',
    contactNumber: '+91-674-2476751',
    hasRefrigeration: true,
    emergencyServices: true
  },
  {
    id: 'delhi_safdarjung',
    name: 'Safdarjung Hospital',
    address: 'Ansari Nagar, New Delhi',
    pincode: '110029',
    district: 'South Delhi',
    state: 'Delhi',
    type: 'government',
    availableVaccines: ['All routine vaccines', 'Adult vaccines', 'Travel vaccines'],
    operatingHours: '24/7',
    contactNumber: '+91-11-26165060',
    hasRefrigeration: true,
    emergencyServices: true
  },
  {
    id: 'kolkata_sskm',
    name: 'SSKM Hospital',
    address: '244, AJC Bose Road, Kolkata',
    pincode: '700020',
    district: 'Kolkata',
    state: 'West Bengal',
    type: 'government',
    availableVaccines: ['All routine vaccines', 'Specialized vaccines'],
    operatingHours: 'Mon-Sat 8AM-6PM',
    contactNumber: '+91-33-22235555',
    hasRefrigeration: true,
    emergencyServices: true
  }
];

// Helper functions
export const getVaccinesByAge = (ageInMonths: number): VaccineSchedule[] => {
  return vaccinationSchedule.filter(vaccine => {
    if (vaccine.ageInMonths !== undefined) {
      return Math.abs(vaccine.ageInMonths - ageInMonths) <= 1; // Within 1 month tolerance
    }
    return false;
  });
};

export const getVaccinesByCategory = (category: string): VaccineSchedule[] => {
  return vaccinationSchedule.filter(vaccine => vaccine.ageCategory === category);
};

export const getOverdueVaccines = (currentAgeInMonths: number): VaccineSchedule[] => {
  return vaccinationSchedule.filter(vaccine => {
    if (vaccine.ageInMonths !== undefined) {
      return vaccine.ageInMonths < currentAgeInMonths - 2; // More than 2 months overdue
    }
    return false;
  });
};

export const getUpcomingVaccines = (currentAgeInMonths: number): VaccineSchedule[] => {
  return vaccinationSchedule.filter(vaccine => {
    if (vaccine.ageInMonths !== undefined) {
      return vaccine.ageInMonths > currentAgeInMonths && vaccine.ageInMonths <= currentAgeInMonths + 6;
    }
    return false;
  });
};

export const getVaccinationCentersByPincode = (pincode: string): VaccinationCenter[] => {
  return vaccinationCenters.filter(center => center.pincode === pincode);
};

export const getVaccinationCentersByDistrict = (district: string): VaccinationCenter[] => {
  return vaccinationCenters.filter(center => 
    center.district.toLowerCase().includes(district.toLowerCase())
  );
};

export const calculateVaccinationStatus = (
  dateOfBirth: string, 
  completedVaccines: string[]
): {
  completed: VaccineSchedule[];
  overdue: VaccineSchedule[];
  upcoming: VaccineSchedule[];
  currentAge: number;
} => {
  const birthDate = new Date(dateOfBirth);
  const currentDate = new Date();
  const ageInMonths = Math.floor((currentDate.getTime() - birthDate.getTime()) / (1000 * 60 * 60 * 24 * 30.44));
  
  const completed = vaccinationSchedule.filter(vaccine => 
    completedVaccines.includes(vaccine.id)
  );
  
  const overdue = getOverdueVaccines(ageInMonths).filter(vaccine => 
    !completedVaccines.includes(vaccine.id)
  );
  
  const upcoming = getUpcomingVaccines(ageInMonths).filter(vaccine => 
    !completedVaccines.includes(vaccine.id)
  );
  
  return {
    completed,
    overdue,
    upcoming,
    currentAge: ageInMonths
  };
};
