// Evidence-Based Treatment Recommendations System
// Based on WHO and ICMR Guidelines for Clinical Management

export interface TreatmentRecommendation {
  condition: string;
  severity: 'mild' | 'moderate' | 'severe';
  icmrGuidelines: string;
  whoGuidelines: string;
  homeManagement?: {
    medications: MedicationRecommendation[];
    nonPharmacological: string[];
    dietaryAdvice: string[];
    activityRestrictions: string[];
    warningSigns: string[];
    followUpCriteria: string[];
  };
  facilityManagement?: {
    investigations: string[];
    treatment: string[];
    monitoring: string[];
    complications: string[];
  };
  prevention: {
    primary: string[];
    secondary: string[];
    environmental: string[];
  };
  patientEducation: string[];
  culturalConsiderations: string[];
  costEffectiveAlternatives: string[];
}

export interface MedicationRecommendation {
  name: string;
  genericName: string;
  dosage: string;
  frequency: string;
  duration: string;
  route: 'oral' | 'topical' | 'injection' | 'inhalation';
  contraindications: string[];
  sideEffects: string[];
  pregnancyCategory: 'A' | 'B' | 'C' | 'D' | 'X';
  pediatricDose?: string;
  geriatricConsiderations?: string[];
  cost: 'low' | 'moderate' | 'high';
  availability: 'widely_available' | 'limited' | 'prescription_only';
}

// WHO/ICMR Evidence-Based Treatment Guidelines
export const treatmentGuidelines: Record<string, TreatmentRecommendation> = {
  tuberculosis: {
    condition: 'Tuberculosis',
    severity: 'moderate',
    icmrGuidelines: 'ICMR TB Treatment Guidelines 2023',
    whoGuidelines: 'WHO TB Treatment Guidelines 2022',
    homeManagement: {
      medications: [
        {
          name: 'DOTS (Directly Observed Treatment)',
          genericName: 'Rifampin + Isoniazid + Ethambutol + Pyrazinamide',
          dosage: 'Weight-based dosing',
          frequency: 'Daily',
          duration: '6 months (intensive + continuation phase)',
          route: 'oral',
          contraindications: ['Severe liver disease', 'Drug hypersensitivity'],
          sideEffects: ['Hepatotoxicity', 'Peripheral neuropathy', 'GI upset'],
          pregnancyCategory: 'B',
          pediatricDose: 'Weight-based pediatric formulation',
          geriatricConsiderations: ['Monitor liver function', 'Adjust for renal function'],
          cost: 'low',
          availability: 'widely_available'
        }
      ],
      nonPharmacological: [
        'Adequate rest and sleep',
        'Nutritious diet with increased protein',
        'Isolation during initial 2 weeks of treatment',
        'Cover mouth when coughing',
        'Ensure good ventilation in living spaces'
      ],
      dietaryAdvice: [
        'High-protein diet (eggs, dairy, pulses)',
        'Vitamin-rich foods (fruits, vegetables)',
        'Adequate caloric intake for weight gain',
        'Avoid alcohol completely',
        'Take medications on empty stomach'
      ],
      activityRestrictions: [
        'Avoid strenuous physical activity initially',
        'Gradual return to normal activities',
        'Avoid crowded places during initial treatment',
        'No work/school for first 2 weeks if sputum positive'
      ],
      warningSigns: [
        'Coughing up blood',
        'Severe chest pain',
        'Difficulty breathing',
        'High fever not responding to treatment',
        'Severe weakness or weight loss'
      ],
      followUpCriteria: [
        'Weekly weight monitoring',
        'Monthly sputum examination',
        'Liver function tests if symptoms develop',
        'Treatment completion monitoring',
        'Contact screening of family members'
      ]
    },
    facilityManagement: {
      investigations: [
        'Sputum AFB microscopy',
        'GeneXpert MTB/RIF',
        'Chest X-ray',
        'HIV testing',
        'Liver function tests',
        'Complete blood count'
      ],
      treatment: [
        'DOTS under healthcare supervision',
        'Nutritional supplementation',
        'Treatment of comorbidities',
        'Contact tracing and screening',
        'Drug resistance testing if indicated'
      ],
      monitoring: [
        'Monthly clinical assessment',
        'Weight gain monitoring',
        'Sputum conversion tracking',
        'Adverse drug reaction monitoring',
        'Treatment adherence assessment'
      ],
      complications: [
        'Drug-resistant TB',
        'Treatment failure',
        'Relapse',
        'Drug-induced hepatitis',
        'Immune reconstitution syndrome'
      ]
    },
    prevention: {
      primary: [
        'BCG vaccination in infants',
        'Improved living conditions',
        'Adequate nutrition',
        'Early case detection and treatment'
      ],
      secondary: [
        'Contact screening',
        'Isoniazid preventive therapy for high-risk contacts',
        'Regular follow-up of treated patients'
      ],
      environmental: [
        'Improved ventilation in homes',
        'Reduced overcrowding',
        'Infection control measures',
        'Community awareness programs'
      ]
    },
    patientEducation: [
      'Importance of treatment completion',
      'Drug adherence counseling',
      'Recognition of warning signs',
      'Prevention of transmission',
      'Nutritional requirements'
    ],
    culturalConsiderations: [
      'Address stigma and misconceptions',
      'Involve family in treatment support',
      'Consider traditional beliefs about illness',
      'Provide education in local language'
    ],
    costEffectiveAlternatives: [
      'Generic drug formulations',
      'Community-based DOTS',
      'Nutritional support programs',
      'Family-based treatment support'
    ]
  },

  malaria: {
    condition: 'Malaria',
    severity: 'moderate',
    icmrGuidelines: 'ICMR Malaria Treatment Guidelines 2023',
    whoGuidelines: 'WHO Malaria Treatment Guidelines 2023',
    homeManagement: {
      medications: [
        {
          name: 'Artemether-Lumefantrine (Coartem)',
          genericName: 'Artemether + Lumefantrine',
          dosage: '20mg/120mg tablets',
          frequency: 'Twice daily',
          duration: '3 days',
          route: 'oral',
          contraindications: ['Known hypersensitivity', 'Severe malaria'],
          sideEffects: ['Nausea', 'Vomiting', 'Dizziness', 'Headache'],
          pregnancyCategory: 'B',
          pediatricDose: 'Weight-based dosing available',
          cost: 'moderate',
          availability: 'widely_available'
        }
      ],
      nonPharmacological: [
        'Bed rest during acute phase',
        'Tepid sponging for fever',
        'Adequate fluid intake',
        'Use of insecticide-treated bed nets',
        'Keep patient in cool, well-ventilated room'
      ],
      dietaryAdvice: [
        'Light, easily digestible foods',
        'Increased fluid intake (ORS, water, soups)',
        'Avoid solid foods during vomiting',
        'Gradual return to normal diet',
        'Vitamin C rich foods for recovery'
      ],
      activityRestrictions: [
        'Complete bed rest during fever',
        'Avoid strenuous activities for 1 week',
        'Gradual return to normal activities',
        'Avoid travel to endemic areas'
      ],
      warningSigns: [
        'Persistent high fever after 48 hours of treatment',
        'Confusion or altered consciousness',
        'Difficulty breathing',
        'Severe vomiting preventing medication',
        'Dark colored urine',
        'Severe weakness or inability to sit up'
      ],
      followUpCriteria: [
        'Daily temperature monitoring',
        'Symptom assessment after 48 hours',
        'Complete treatment even if feeling better',
        'Return if fever persists after 3 days',
        'Parasite clearance confirmation'
      ]
    },
    prevention: {
      primary: [
        'Use of insecticide-treated bed nets',
        'Indoor residual spraying',
        'Elimination of mosquito breeding sites',
        'Chemoprophylaxis for high-risk individuals'
      ],
      secondary: [
        'Early diagnosis and treatment',
        'Active case detection',
        'Mass drug administration in high transmission areas'
      ],
      environmental: [
        'Eliminate standing water',
        'Proper drainage systems',
        'Use of larvicides in water bodies',
        'Community vector control programs'
      ]
    },
    patientEducation: [
      'Complete the full course of medication',
      'Recognize danger signs',
      'Prevention methods',
      'When to seek medical care',
      'Importance of bed net use'
    ],
    culturalConsiderations: [
      'Address traditional beliefs about fever',
      'Involve community leaders in prevention',
      'Respect for traditional healing practices',
      'Community-based education programs'
    ],
    costEffectiveAlternatives: [
      'Generic antimalarial drugs',
      'Community case management',
      'Subsidized bed nets',
      'Community health worker programs'
    ]
  },

  dengue: {
    condition: 'Dengue Fever',
    severity: 'moderate',
    icmrGuidelines: 'ICMR Dengue Management Guidelines 2023',
    whoGuidelines: 'WHO Dengue Guidelines 2012',
    homeManagement: {
      medications: [
        {
          name: 'Paracetamol',
          genericName: 'Acetaminophen',
          dosage: '500mg',
          frequency: 'Every 6 hours as needed',
          duration: 'Until fever subsides',
          route: 'oral',
          contraindications: ['Liver disease', 'Alcohol use disorder'],
          sideEffects: ['Hepatotoxicity with overdose'],
          pregnancyCategory: 'B',
          pediatricDose: '10-15mg/kg every 6 hours',
          cost: 'low',
          availability: 'widely_available'
        }
      ],
      nonPharmacological: [
        'Complete bed rest',
        'Adequate hydration with ORS',
        'Tepid sponging for fever control',
        'Monitor for warning signs',
        'Avoid aspirin and NSAIDs'
      ],
      dietaryAdvice: [
        'Increased fluid intake (water, ORS, fresh juices)',
        'Light, nutritious meals',
        'Avoid spicy and oily foods',
        'Coconut water for electrolyte balance',
        'Papaya leaf extract (traditional remedy)'
      ],
      activityRestrictions: [
        'Complete bed rest during acute phase',
        'Avoid strenuous activities for 2 weeks',
        'Monitor platelet count regularly',
        'Avoid medications that affect platelets'
      ],
      warningSigns: [
        'Severe abdominal pain',
        'Persistent vomiting',
        'Bleeding from nose or gums',
        'Difficulty breathing',
        'Extreme restlessness',
        'Skin pallor and coldness'
      ],
      followUpCriteria: [
        'Daily platelet count monitoring',
        'Watch for warning signs',
        'Immediate medical care if complications',
        'Complete recovery assessment',
        'Prevention counseling'
      ]
    },
    prevention: {
      primary: [
        'Eliminate mosquito breeding sites',
        'Use of personal protective measures',
        'Community vector control',
        'Water storage management'
      ],
      secondary: [
        'Early case detection',
        'Prompt treatment of cases',
        'Vector surveillance'
      ],
      environmental: [
        'Remove stagnant water',
        'Proper waste management',
        'Use of biological control agents',
        'Community cleanup drives'
      ]
    },
    patientEducation: [
      'Recognize warning signs',
      'Importance of adequate hydration',
      'When to seek immediate medical care',
      'Prevention of mosquito breeding',
      'Avoid self-medication with aspirin'
    ],
    culturalConsiderations: [
      'Community involvement in vector control',
      'Traditional remedies as supportive care',
      'Family-based care approach',
      'Local language educational materials'
    ],
    costEffectiveAlternatives: [
      'Home-based oral rehydration',
      'Community-based case management',
      'Low-cost vector control methods',
      'Traditional supportive remedies'
    ]
  },

  cholera: {
    condition: 'Cholera/Severe Diarrhea',
    severity: 'severe',
    icmrGuidelines: 'ICMR Diarrheal Disease Guidelines 2023',
    whoGuidelines: 'WHO Cholera Treatment Guidelines 2023',
    homeManagement: {
      medications: [
        {
          name: 'ORS (Oral Rehydration Solution)',
          genericName: 'Sodium chloride + Glucose + Potassium chloride',
          dosage: '1 sachet in 1 liter clean water',
          frequency: 'After each loose stool',
          duration: 'Until diarrhea stops',
          route: 'oral',
          contraindications: ['Persistent vomiting', 'Severe dehydration'],
          sideEffects: ['Rarely - electrolyte imbalance if overused'],
          pregnancyCategory: 'A',
          pediatricDose: 'Same solution, age-appropriate volume',
          cost: 'low',
          availability: 'widely_available'
        }
      ],
      nonPharmacological: [
        'Immediate oral rehydration',
        'Continue breastfeeding in infants',
        'Zinc supplementation in children',
        'Maintain hygiene and sanitation',
        'Monitor hydration status'
      ],
      dietaryAdvice: [
        'Continue normal feeding when possible',
        'BRAT diet (Banana, Rice, Applesauce, Toast)',
        'Avoid dairy products temporarily',
        'Increase salt and sugar intake',
        'Avoid high-fat and spicy foods'
      ],
      activityRestrictions: [
        'Rest until symptoms improve',
        'Avoid food preparation for others',
        'Maintain strict hygiene',
        'Isolate if infectious cause suspected'
      ],
      warningSign: [
        'Signs of severe dehydration',
        'Persistent vomiting',
        'Blood in stool',
        'High fever',
        'Severe abdominal pain',
        'Decreased urine output'
      ],
      followUpCriteria: [
        'Monitor hydration status',
        'Assess stool frequency and consistency',
        'Watch for complications',
        'Ensure complete recovery',
        'Prevention counseling'
      ]
    },
    prevention: {
      primary: [
        'Safe water and sanitation',
        'Food safety practices',
        'Hand hygiene',
        'Vaccination in high-risk areas'
      ],
      secondary: [
        'Early case detection',
        'Prompt treatment',
        'Contact tracing'
      ],
      environmental: [
        'Improved water supply',
        'Proper sewage disposal',
        'Food safety regulations',
        'Community hygiene programs'
      ]
    },
    patientEducation: [
      'Recognize signs of dehydration',
      'Proper ORS preparation and use',
      'Food and water safety',
      'Hand hygiene practices',
      'When to seek medical care'
    ],
    culturalConsiderations: [
      'Address beliefs about diarrheal diseases',
      'Involve community in prevention',
      'Respect traditional remedies as supportive',
      'Community-based education'
    ],
    costEffectiveAlternatives: [
      'Home-made ORS solutions',
      'Community-based case management',
      'Low-cost water purification methods',
      'Community health worker programs'
    ]
  }
};

// Treatment Decision Engine
export class TreatmentRecommendationEngine {
  
  /**
   * Get treatment recommendations based on diagnosis and patient profile
   */
  getTreatmentRecommendations(
    condition: string,
    severity: 'mild' | 'moderate' | 'severe',
    userProfile: {
      age?: number;
      pregnancy?: boolean;
      comorbidities?: string[];
      allergies?: string[];
      currentMedications?: string[];
    }
  ): TreatmentRecommendation {
    
    const baseRecommendation = treatmentGuidelines[condition];
    if (!baseRecommendation) {
      return this.getGenericRecommendation(condition, severity);
    }

    // Customize recommendations based on patient profile
    return this.customizeRecommendations(baseRecommendation, severity, userProfile);
  }

  /**
   * Customize recommendations based on patient profile
   */
  private customizeRecommendations(
    baseRecommendation: TreatmentRecommendation,
    severity: 'mild' | 'moderate' | 'severe',
    userProfile: any
  ): TreatmentRecommendation {
    
    const customized = { ...baseRecommendation, severity };

    // Age-based modifications
    if (userProfile.age !== undefined) {
      if (userProfile.age < 18) {
        customized.homeManagement = this.addPediatricConsiderations(customized.homeManagement);
      } else if (userProfile.age > 65) {
        customized.homeManagement = this.addGeriatricConsiderations(customized.homeManagement);
      }
    }

    // Pregnancy modifications
    if (userProfile.pregnancy) {
      customized.homeManagement = this.addPregnancyConsiderations(customized.homeManagement);
    }

    // Comorbidity modifications
    if (userProfile.comorbidities && userProfile.comorbidities.length > 0) {
      customized.homeManagement = this.addComorbidityConsiderations(
        customized.homeManagement, 
        userProfile.comorbidities
      );
    }

    // Severity-based modifications
    if (severity === 'severe') {
      customized.facilityManagement = this.enhanceFacilityManagement(customized.facilityManagement);
    }

    return customized;
  }

  /**
   * Add pediatric considerations
   */
  private addPediatricConsiderations(homeManagement: any): any {
    if (!homeManagement) return homeManagement;

    return {
      ...homeManagement,
      medications: homeManagement.medications?.map((med: MedicationRecommendation) => ({
        ...med,
        dosage: med.pediatricDose || 'Consult healthcare provider for pediatric dosing',
        contraindications: [...med.contraindications, 'Consult pediatrician before use']
      })),
      nonPharmacological: [
        ...homeManagement.nonPharmacological,
        'Ensure adequate nutrition for growth',
        'Monitor hydration status closely',
        'Maintain normal activities as tolerated'
      ],
      warningSign: [
        ...homeManagement.warningSign,
        'Lethargy or unusual irritability',
        'Difficulty feeding or drinking',
        'Decreased urination'
      ]
    };
  }

  /**
   * Add geriatric considerations
   */
  private addGeriatricConsiderations(homeManagement: any): any {
    if (!homeManagement) return homeManagement;

    return {
      ...homeManagement,
      medications: homeManagement.medications?.map((med: MedicationRecommendation) => ({
        ...med,
        contraindications: [...med.contraindications, 'Monitor for drug interactions'],
        sideEffects: [...med.sideEffects, 'Increased risk of side effects in elderly']
      })),
      nonPharmacological: [
        ...homeManagement.nonPharmacological,
        'Monitor for dehydration risk',
        'Ensure medication adherence',
        'Regular blood pressure monitoring'
      ]
    };
  }

  /**
   * Add pregnancy considerations
   */
  private addPregnancyConsiderations(homeManagement: any): any {
    if (!homeManagement) return homeManagement;

    return {
      ...homeManagement,
      medications: homeManagement.medications?.filter((med: MedicationRecommendation) => 
        med.pregnancyCategory === 'A' || med.pregnancyCategory === 'B'
      ),
      nonPharmacological: [
        ...homeManagement.nonPharmacological,
        'Ensure adequate nutrition for fetal development',
        'Monitor for pregnancy complications',
        'Regular prenatal check-ups'
      ],
      warningSign: [
        ...homeManagement.warningSign,
        'Vaginal bleeding',
        'Severe abdominal pain',
        'Decreased fetal movements'
      ]
    };
  }

  /**
   * Add comorbidity considerations
   */
  private addComorbidityConsiderations(homeManagement: any, comorbidities: string[]): any {
    if (!homeManagement) return homeManagement;

    let modified = { ...homeManagement };

    if (comorbidities.includes('diabetes')) {
      modified.nonPharmacological.push('Monitor blood glucose levels closely');
      modified.dietaryAdvice = modified.dietaryAdvice?.map((advice: string) => 
        advice.includes('sugar') ? 'Monitor sugar intake carefully' : advice
      );
    }

    if (comorbidities.includes('hypertension')) {
      modified.nonPharmacological.push('Monitor blood pressure regularly');
      modified.warningSign.push('Severe headache or vision changes');
    }

    if (comorbidities.includes('heart_disease')) {
      modified.warningSign.push('Chest pain or breathing difficulty');
      modified.activityRestrictions.push('Avoid strenuous activities');
    }

    return modified;
  }

  /**
   * Enhance facility management for severe cases
   */
  private enhanceFacilityManagement(facilityManagement: any): any {
    if (!facilityManagement) {
      return {
        investigations: ['Complete blood count', 'Basic metabolic panel'],
        treatment: ['Supportive care', 'Symptom management'],
        monitoring: ['Vital signs monitoring', 'Symptom tracking'],
        complications: ['Secondary infections', 'Dehydration']
      };
    }

    return {
      ...facilityManagement,
      investigations: [
        ...facilityManagement.investigations,
        'Arterial blood gas analysis',
        'Electrolyte panel',
        'Liver and kidney function tests'
      ],
      treatment: [
        ...facilityManagement.treatment,
        'Intensive monitoring',
        'IV fluid management',
        'Oxygen therapy if needed'
      ],
      monitoring: [
        ...facilityManagement.monitoring,
        'Hourly vital signs',
        'Fluid balance monitoring',
        'Neurological assessment'
      ]
    };
  }

  /**
   * Get generic recommendation for unknown conditions
   */
  private getGenericRecommendation(condition: string, severity: 'mild' | 'moderate' | 'severe'): TreatmentRecommendation {
    return {
      condition,
      severity,
      icmrGuidelines: 'ICMR General Clinical Guidelines',
      whoGuidelines: 'WHO Primary Care Guidelines',
      homeManagement: {
        medications: [],
        nonPharmacological: [
          'Adequate rest',
          'Maintain hydration',
          'Monitor symptoms',
          'Maintain good hygiene'
        ],
        dietaryAdvice: [
          'Balanced, nutritious diet',
          'Adequate fluid intake',
          'Avoid alcohol and smoking'
        ],
        activityRestrictions: [
          'Rest as needed',
          'Avoid strenuous activities',
          'Return to normal activities gradually'
        ],
        warningSign: [
          'Worsening symptoms',
          'High fever',
          'Severe pain',
          'Difficulty breathing'
        ],
        followUpCriteria: [
          'Monitor symptoms daily',
          'Seek care if no improvement in 3 days',
          'Return for follow-up as advised'
        ]
      },
      prevention: {
        primary: ['Healthy lifestyle', 'Good hygiene practices'],
        secondary: ['Regular health check-ups', 'Early symptom recognition'],
        environmental: ['Clean living environment', 'Safe food and water']
      },
      patientEducation: [
        'Understand the condition',
        'Recognize warning signs',
        'Follow treatment recommendations',
        'Maintain preventive measures'
      ],
      culturalConsiderations: [
        'Respect traditional beliefs',
        'Involve family in care',
        'Provide culturally appropriate education'
      ],
      costEffectiveAlternatives: [
        'Generic medications when available',
        'Home-based care when appropriate',
        'Community health resources'
      ]
    };
  }

  /**
   * Get medication interaction warnings
   */
  checkMedicationInteractions(
    recommendedMedications: MedicationRecommendation[],
    currentMedications: string[]
  ): string[] {
    const warnings: string[] = [];
    
    // Common interaction checks
    const interactions: Record<string, string[]> = {
      'warfarin': ['aspirin', 'nsaids', 'antibiotics'],
      'metformin': ['alcohol', 'contrast_agents'],
      'ace_inhibitors': ['nsaids', 'potassium_supplements'],
      'digoxin': ['diuretics', 'antibiotics', 'antacids']
    };

    currentMedications.forEach(currentMed => {
      const lowerCurrentMed = currentMed.toLowerCase();
      
      recommendedMedications.forEach(recMed => {
        const lowerRecMed = recMed.genericName.toLowerCase();
        
        Object.entries(interactions).forEach(([drug, interactsWith]) => {
          if (lowerCurrentMed.includes(drug) && 
              interactsWith.some(interact => lowerRecMed.includes(interact))) {
            warnings.push(
              `Potential interaction between ${currentMed} and ${recMed.name}. Consult healthcare provider.`
            );
          }
        });
      });
    });

    return warnings;
  }
}

// Export singleton instance
export const treatmentRecommendationEngine = new TreatmentRecommendationEngine();
