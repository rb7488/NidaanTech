import { whoGuidelines, mapUserSymptomsToStandard, DiseaseGuideline } from './whoGuidelines';
import { getLocationDiseaseData, getSeasonalDiseases, getEndemicDiseases, getCommonDiseases } from './locationDiseases';
import { applyStateBasedScoring, getStateDiseaseData } from './stateWiseDiseases';
import { questionEngine, Question, Answer, UserProfile, Symptom } from './questionEngine';
import { referralDecisionEngine, ReferralDecision } from './referralSystem';
import { treatmentRecommendationEngine, TreatmentRecommendation } from './treatmentRecommendations';

export interface MedicalDiagnosisResult {
  primaryDiagnosis: {
    disease: string;
    confidence: number;
    severity: 'mild' | 'moderate' | 'severe';
    score: number;
  };
  differentialDiagnoses: Array<{
    disease: string;
    confidence: number;
    score: number;
  }>;
  symptoms: {
    matched: string[];
    unmatched: string[];
  };
  recommendations: {
    immediate: string[];
    treatment: string[];
    prevention: string[];
    emergency: boolean;
  };
  followUp: {
    required: boolean;
    timeframe: string;
    instructions: string[];
  };
  riskFactors: string[];
  complications: string[];
  professionalHelpRequired: boolean;
  professionalHelpReason: string;
  // Enhanced features
  intelligentQuestions?: {
    nextQuestion: Question | null;
    conversationSummary: any;
    totalQuestions: number;
  };
  referralDecision?: ReferralDecision;
  treatmentRecommendations?: TreatmentRecommendation;
  clinicalMetrics?: {
    diagnosticAccuracy: number;
    whoCompliance: boolean;
    informationGain: number;
    clinicalConfidence: number;
  };
}

export interface DiagnosisRequest {
  symptoms: string[];
  age?: number;
  gender?: 'male' | 'female';
  pregnancy?: boolean;
  travelHistory?: string[];
  comorbidities?: string[];
  pincode?: string;
  language?: string;
  illnessDuration?: number; // Days since symptoms started
  // Enhanced features
  conversationHistory?: Answer[];
  enableIntelligentQuestions?: boolean;
  enableReferralDecision?: boolean;
  enableTreatmentRecommendations?: boolean;
  currentMedications?: string[];
  allergies?: string[];
}

class MedicalDiagnosisEngine {
  private guidelines: Record<string, DiseaseGuideline>;

  constructor() {
    this.guidelines = whoGuidelines;
  }

  /**
   * Main diagnosis function that analyzes symptoms against WHO guidelines
   */
  public diagnose(request: DiagnosisRequest): MedicalDiagnosisResult {
    const { 
      symptoms, age, gender, pregnancy, travelHistory, comorbidities, pincode, language, illnessDuration,
      conversationHistory = [], enableIntelligentQuestions = true, enableReferralDecision = true,
      enableTreatmentRecommendations = true, currentMedications = [], allergies = []
    } = request;
    
    // Map user symptoms to standardized medical terms
    const mappedSymptoms = mapUserSymptomsToStandard(symptoms);
    
    // Calculate scores for each disease
    const diseaseScores = this.calculateDiseaseScores(mappedSymptoms, age, gender, pregnancy, travelHistory, comorbidities, pincode);
    
    // Get primary diagnosis
    const primaryDiagnosis = this.getPrimaryDiagnosis(diseaseScores);
    
    // Get differential diagnoses
    const differentialDiagnoses = this.getDifferentialDiagnoses(diseaseScores, primaryDiagnosis.disease);
    
    // Determine severity with conversation history
    const severity = this.determineSeverity(primaryDiagnosis.disease, mappedSymptoms, age, comorbidities, illnessDuration, conversationHistory);
    
    // Generate recommendations
    const recommendations = this.generateRecommendations(primaryDiagnosis.disease, severity, age, pregnancy, pincode);
    
    // Determine follow-up requirements
    const followUp = this.determineFollowUp(primaryDiagnosis.disease, severity, age, comorbidities);
    
    // Identify risk factors
    const riskFactors = this.identifyRiskFactors(primaryDiagnosis.disease, age, gender, pregnancy, travelHistory, comorbidities);
    
    // Get potential complications
    const complications = this.getComplications(primaryDiagnosis.disease, severity, age, comorbidities);
    
    // Assess if professional medical help is required
    const professionalHelpAssessment = this.assessProfessionalHelpRequired(
      primaryDiagnosis.disease, 
      severity, 
      mappedSymptoms, 
      age, 
      illnessDuration,
      comorbidities
    );

    // Base result
    const baseResult: MedicalDiagnosisResult = {
      primaryDiagnosis: {
        disease: primaryDiagnosis.disease,
        confidence: primaryDiagnosis.confidence,
        severity,
        score: primaryDiagnosis.score
      },
      differentialDiagnoses,
      symptoms: {
        matched: mappedSymptoms,
        unmatched: symptoms.filter(s => !mappedSymptoms.includes(s.toLowerCase().trim()))
      },
      recommendations,
      followUp,
      riskFactors,
      complications,
      professionalHelpRequired: professionalHelpAssessment.required,
      professionalHelpReason: professionalHelpAssessment.reason
    };

    // Enhanced features
    const userProfile: UserProfile = { age, gender, pregnancy, location: pincode, comorbidities, travelHistory };
    const symptomObjects: Symptom[] = mappedSymptoms.map(s => ({
      name: s,
      severity: severity === 'mild' ? 1 : severity === 'moderate' ? 2 : 3,
      duration: illnessDuration || 1,
      pattern: 'continuous'
    }));

    // Intelligent Questions
    if (enableIntelligentQuestions) {
      const nextQuestion = questionEngine.generateNextQuestion(
        symptomObjects,
        Object.fromEntries(diseaseScores.map(d => [d.disease, d.score])),
        conversationHistory,
        userProfile
      );
      
      const conversationSummary = questionEngine.getConversationSummary();
      
      baseResult.intelligentQuestions = {
        nextQuestion,
        conversationSummary,
        totalQuestions: conversationHistory.length
      };
    }

    // Referral Decision
    if (enableReferralDecision) {
      baseResult.referralDecision = referralDecisionEngine.makeReferralDecision(
        primaryDiagnosis.disease,
        mappedSymptoms,
        severity,
        { age, pregnancy, comorbidities, location: pincode }
      );
    }

    // Treatment Recommendations
    if (enableTreatmentRecommendations) {
      baseResult.treatmentRecommendations = treatmentRecommendationEngine.getTreatmentRecommendations(
        primaryDiagnosis.disease,
        severity,
        { age, pregnancy, comorbidities, allergies, currentMedications }
      );
    }

    // Clinical Metrics
    baseResult.clinicalMetrics = {
      diagnosticAccuracy: this.calculateDiagnosticAccuracy(primaryDiagnosis, mappedSymptoms),
      whoCompliance: this.validateWHOCompliance(primaryDiagnosis.disease),
      informationGain: this.calculateInformationGain(conversationHistory),
      clinicalConfidence: this.calculateClinicalConfidence(primaryDiagnosis, severity, conversationHistory)
    };

    return baseResult;
  }

  /**
   * Calculate disease scores based on symptom matching and WHO criteria
   */
  private calculateDiseaseScores(
    symptoms: string[], 
    age?: number, 
    gender?: string, 
    pregnancy?: boolean, 
    travelHistory?: string[], 
    comorbidities?: string[],
    pincode?: string
  ): Array<{ disease: string; score: number; confidence: number }> {
    const scores: Array<{ disease: string; score: number; confidence: number }> = [];

    for (const [diseaseName, guideline] of Object.entries(this.guidelines)) {
      let score = 0;
      let matchedSymptoms = 0;
      let totalPossibleScore = 0;

      // Calculate base score from symptoms
      for (const symptom of symptoms) {
        const diseaseSymptom = guideline.symptoms.find(s => s.symptom === symptom);
        if (diseaseSymptom) {
          score += diseaseSymptom.weight;
          matchedSymptoms++;
        }
      }

      // Calculate total possible score for this disease
      totalPossibleScore = guideline.symptoms.reduce((sum, s) => sum + s.weight, 0);

      // Check diagnostic criteria
      const primaryMatches = guideline.diagnosticCriteria.primary.filter(s => symptoms.includes(s)).length;
      const secondaryMatches = guideline.diagnosticCriteria.secondary.filter(s => symptoms.includes(s)).length;
      const exclusionMatches = guideline.diagnosticCriteria.exclusion.filter(s => symptoms.includes(s)).length;

      // Apply diagnostic criteria bonuses/penalties
      if (primaryMatches === guideline.diagnosticCriteria.primary.length) {
        score += 20; // Full primary criteria match
      } else if (primaryMatches > 0) {
        score += primaryMatches * 5; // Partial primary criteria match
      }

      if (secondaryMatches > 0) {
        score += secondaryMatches * 2; // Secondary criteria bonus
      }

      if (exclusionMatches > 0) {
        score -= exclusionMatches * 15; // Exclusion criteria penalty
      }

      // Apply enhanced state-based scoring (only)
      if (pincode) {
        score = applyStateBasedScoring(score, diseaseName, pincode);
      }

      // Apply risk factor adjustments
      score = this.applyRiskFactorAdjustments(score, diseaseName, age, gender, pregnancy, travelHistory, comorbidities);

      // Calculate confidence based on symptom match ratio and diagnostic criteria
      const symptomMatchRatio = matchedSymptoms / Math.max(guideline.symptoms.length, 1);
      const primaryCriteriaRatio = primaryMatches / Math.max(guideline.diagnosticCriteria.primary.length, 1);
      const secondaryCriteriaRatio = secondaryMatches / Math.max(guideline.diagnosticCriteria.secondary.length, 1);
      
      // More accurate confidence calculation
      const baseConfidence = symptomMatchRatio * 50; // 50% weight for symptom matching
      const primaryConfidence = primaryCriteriaRatio * 30; // 30% weight for primary criteria
      const secondaryConfidence = secondaryCriteriaRatio * 15; // 15% weight for secondary criteria
      const baseBonus = 5; // 5% base confidence
      
      // Penalty for exclusion criteria matches
      const exclusionPenalty = exclusionMatches * 10;
      
      const confidence = Math.min(95, Math.max(5, 
        baseConfidence + primaryConfidence + secondaryConfidence + baseBonus - exclusionPenalty
      ));

      scores.push({
        disease: diseaseName,
        score: Math.max(0, score),
        confidence: Math.max(5, confidence)
      });
    }

    // Sort primarily by confidence (symptom matching accuracy)
    // Only use score as tiebreaker when confidence is very close
    return scores.sort((a, b) => {
      // If confidence difference is significant (>2%), prioritize confidence
      if (Math.abs(a.confidence - b.confidence) > 2) {
        return b.confidence - a.confidence; // Higher confidence first
      }
      // If confidence is very close, use score as tiebreaker
      return b.score - a.score;
    });
  }

  /**
   * Apply location-based scoring adjustments
   */
  private applyLocationBasedScoring(
    score: number,
    diseaseName: string,
    pincode: string
  ): number {
    const locationData = getLocationDiseaseData(pincode);
    if (!locationData) return score;

    let adjustedScore = score;

    // Check if disease is endemic to this location (reduced bias)
    if (locationData.endemicDiseases.includes(diseaseName)) {
      adjustedScore += 5; // Reduced from 15 to 5
    }

    // Check if disease is common in this location (reduced bias)
    if (locationData.commonDiseases.includes(diseaseName)) {
      adjustedScore += 3; // Reduced from 10 to 3
    }

    // Check if disease is seasonal for current season (reduced bias)
    const seasonalDiseases = getSeasonalDiseases(pincode);
    if (seasonalDiseases.includes(diseaseName)) {
      adjustedScore += 2; // Reduced from 8 to 2
    }

    return adjustedScore;
  }

  /**
   * Apply risk factor adjustments to disease scores
   */
  private applyRiskFactorAdjustments(
    score: number, 
    disease: string, 
    age?: number, 
    gender?: string, 
    pregnancy?: boolean, 
    travelHistory?: string[], 
    comorbidities?: string[]
  ): number {
    let adjustedScore = score;

    // Age-based adjustments
    if (age !== undefined) {
      if (disease === 'malaria' && age < 5) {
        adjustedScore += 10; // Children more susceptible to severe malaria
      }
      if (disease === 'dengue' && age < 15) {
        adjustedScore += 5; // Children more susceptible to dengue
      }
      if (disease === 'cholera' && age > 65) {
        adjustedScore += 8; // Elderly more susceptible to severe cholera
      }
      if (disease === 'diarrhea' && age < 2) {
        adjustedScore += 12; // Infants more susceptible to severe diarrhea
      }
    }

    // Pregnancy adjustments
    if (pregnancy) {
      if (disease === 'malaria') {
        adjustedScore += 15; // Pregnant women at higher risk of severe malaria
      }
      if (disease === 'dengue') {
        adjustedScore += 10; // Pregnant women at higher risk of severe dengue
      }
    }

    // Travel history adjustments
    if (travelHistory && travelHistory.length > 0) {
      if (disease === 'malaria') {
        // Check if travel history includes malaria-endemic areas
        const endemicAreas = ['africa', 'south america', 'southeast asia', 'india', 'odisha'];
        const hasEndemicTravel = travelHistory.some(area => 
          endemicAreas.some(endemic => area.toLowerCase().includes(endemic))
        );
        if (hasEndemicTravel) {
          adjustedScore += 20;
        }
      }
    }

    // Comorbidity adjustments
    if (comorbidities && comorbidities.length > 0) {
      if (comorbidities.includes('diabetes') || comorbidities.includes('hypertension')) {
        if (disease === 'dengue' || disease === 'malaria') {
          adjustedScore += 8; // Higher risk of complications
        }
      }
      if (comorbidities.includes('immunocompromised')) {
        adjustedScore += 12; // Higher risk for all diseases
      }
    }

    return adjustedScore;
  }

  /**
   * Get primary diagnosis from disease scores
   */
  private getPrimaryDiagnosis(scores: Array<{ disease: string; score: number; confidence: number }>): {
    disease: string;
    score: number;
    confidence: number;
  } {
    if (scores.length === 0) {
      return { disease: 'unknown', score: 0, confidence: 0 };
    }

    const topScore = scores[0];
    
    // If top score is too low, consider it unknown
    if (topScore.score < 15) {
      return { disease: 'unknown', score: topScore.score, confidence: topScore.confidence };
    }

    return topScore;
  }

  /**
   * Get differential diagnoses (other possible diseases)
   */
  private getDifferentialDiagnoses(
    scores: Array<{ disease: string; score: number; confidence: number }>, 
    primaryDisease: string
  ): Array<{ disease: string; confidence: number; score: number }> {
    return scores
      .filter(s => s.disease !== primaryDisease && s.score > 10)
      .slice(0, 3) // Top 3 differential diagnoses
      .map(s => ({
        disease: s.disease,
        confidence: s.confidence,
        score: s.score
      }));
  }

  /**
   * Determine severity based on WHO criteria and question answers
   */
  private determineSeverity(
    disease: string, 
    symptoms: string[], 
    age?: number, 
    comorbidities?: string[],
    illnessDuration?: number,
    conversationHistory?: any[]
  ): 'mild' | 'moderate' | 'severe' {
    const guideline = this.guidelines[disease];
    if (!guideline) return 'mild';

    let severityScore = 0;

    // Calculate severity based on symptoms with proper weight consideration
    for (const symptom of symptoms) {
      const diseaseSymptom = guideline.symptoms.find(s => s.symptom === symptom);
      if (diseaseSymptom) {
        // Use weight to influence severity calculation
        const weightMultiplier = diseaseSymptom.weight || 1.0;
        
        switch (diseaseSymptom.severity) {
          case 'mild':
            severityScore += 1 * weightMultiplier;
            break;
          case 'moderate':
            severityScore += 2 * weightMultiplier;
            break;
          case 'severe':
            severityScore += 4 * weightMultiplier; // Increased weight for severe symptoms
            break;
        }
      }
    }

    // Factor in question answers for more accurate severity assessment
    if (conversationHistory && conversationHistory.length > 0) {
      conversationHistory.forEach(qa => {
        // Import question engine to access question details
        const allQuestions = [
          // TB questions
          { id: 'tb_hemoptysis', weight: 0.95, urgency: 'immediate_referral', pathognomonic: false, warningSign: true },
          { id: 'tb_weight_loss', weight: 0.8, urgency: undefined, pathognomonic: false, warningSign: false },
          { id: 'tb_night_sweats', weight: 0.7, urgency: undefined, pathognomonic: false, warningSign: false },
          { id: 'tb_cough_duration', weight: 0.9, urgency: undefined, pathognomonic: true, warningSign: false },
          // Malaria questions
          { id: 'malaria_severe_symptoms', weight: 0.95, urgency: 'immediate_referral', pathognomonic: false, warningSign: true },
          { id: 'malaria_fever_pattern', weight: 0.85, urgency: undefined, pathognomonic: false, warningSign: false },
          { id: 'malaria_chills', weight: 0.8, urgency: undefined, pathognomonic: false, warningSign: false },
          // Dengue questions
          { id: 'dengue_bleeding', weight: 0.9, urgency: 'urgent', pathognomonic: false, warningSign: true },
          { id: 'dengue_abdominal_pain', weight: 0.85, urgency: undefined, pathognomonic: false, warningSign: true },
          // Cholera questions
          { id: 'cholera_rice_water', weight: 0.85, urgency: undefined, pathognomonic: true, warningSign: false },
          { id: 'cholera_dehydration', weight: 0.8, urgency: undefined, pathognomonic: false, warningSign: true },
          // Add more as needed
        ];
        
        const question = allQuestions.find(q => q.id === qa.questionId);
        if (question && (qa.answer === true || qa.answer === 'yes')) {
          let severityImpact = question.weight * 2; // Base impact from weight
          
          // Pathognomonic symptoms significantly increase severity
          if (question.pathognomonic) {
            severityImpact *= 2.5;
          }
          
          // Warning signs increase severity
          if (question.warningSign) {
            severityImpact *= 2.0;
          }
          
          // Urgent symptoms increase severity
          if (question.urgency === 'immediate_referral') {
            severityImpact *= 3.0;
          } else if (question.urgency === 'urgent') {
            severityImpact *= 1.8;
          }
          
          severityScore += severityImpact;
        }
      });
    }

    // Check for emergency indicators (improved matching)
    const emergencyIndicators = guideline.emergencyIndicators.filter(indicator => 
      symptoms.some(symptom => {
        const indicatorLower = indicator.toLowerCase();
        const symptomLower = symptom.toLowerCase();
        
        // Direct matches
        if (indicatorLower.includes(symptomLower) || symptomLower.includes(indicatorLower)) {
          return true;
        }
        
        // Check for key emergency terms
        const emergencyTerms = [
          'confusion', 'seizures', 'shock', 'bleeding', 'dehydration', 
          'breathing_difficulty', 'severe_abdominal_pain', 'persistent_vomiting',
          'no_urine', 'rapid_pulse', 'low_blood_pressure', 'sunken_eyes'
        ];
        
        return emergencyTerms.some(term => 
          (indicatorLower.includes(term) && symptomLower.includes(term)) ||
          (term === symptomLower)
        );
      })
    );

    if (emergencyIndicators.length > 0) {
      return 'severe';
    }

    // Age-based severity adjustments
    if (age !== undefined) {
      if (age < 2 || age > 65) {
        severityScore += 2; // Higher risk for infants and elderly
      }
    }

    // Comorbidity adjustments
    if (comorbidities && comorbidities.length > 0) {
      severityScore += comorbidities.length; // Each comorbidity increases severity
    }

    // Duration-based adjustments (disease-specific)
    if (illnessDuration !== undefined) {
      // Allergic conditions like hay fever don't become more severe with time
      if (disease === 'hay_fever' || disease === 'common_cold') {
        // No duration penalty for allergic/mild conditions
        if (illnessDuration >= 14) {
          severityScore += 1; // Only slight increase for very prolonged symptoms
        }
      } else {
        // Other diseases get standard duration adjustments
        if (illnessDuration >= 7) {
          severityScore += 3; // Prolonged illness increases severity
        } else if (illnessDuration >= 3) {
          severityScore += 1; // Moderate duration slight increase
        }
        
        // Disease-specific duration considerations
        if (disease === 'malaria' && illnessDuration >= 5) {
          severityScore += 2; // Malaria becomes more severe after 5 days
        }
        if (disease === 'dengue' && illnessDuration >= 4) {
          severityScore += 2; // Dengue critical phase typically starts day 4-5
        }
        if (disease === 'cholera' && illnessDuration >= 2) {
          severityScore += 3; // Cholera can become severe quickly
        }
        if (disease === 'diarrhea' && illnessDuration >= 14) {
          severityScore += 2; // Chronic diarrhea is more concerning
        }
      }
    }

    // Determine final severity with improved thresholds based on weighted scoring
    if (severityScore >= 8.0) {
      return 'severe';
    } else if (severityScore >= 4.0) {
      return 'moderate';
    } else {
      return 'mild';
    }
  }

  /**
   * Generate treatment and care recommendations
   */
  private generateRecommendations(
    disease: string, 
    severity: string, 
    age?: number, 
    pregnancy?: boolean, 
    pincode?: string
  ): {
    immediate: string[];
    treatment: string[];
    prevention: string[];
    emergency: boolean;
  } {
    const guideline = this.guidelines[disease];
    if (!guideline) {
      return {
        immediate: ['Consult a healthcare provider'],
        treatment: ['Seek medical advice'],
        prevention: ['Practice good hygiene'],
        emergency: false
      };
    }

    // Only contact emergency for moderate or severe cases
    const emergency = (severity === 'severe' || severity === 'moderate') && 
                     (guideline.emergencyIndicators.some(indicator => 
                       indicator.toLowerCase().includes('shock') || 
                       indicator.toLowerCase().includes('severe') ||
                       indicator.toLowerCase().includes('emergency')
                     ) || severity === 'severe');

    let treatment = guideline.treatment[severity as keyof typeof guideline.treatment] || guideline.treatment.mild;

    // Age-specific adjustments
    if (age !== undefined && age < 2) {
      treatment = treatment.map(t => 
        t.includes('adult') ? t.replace('adult', 'pediatric') : t
      );
    }

    // Pregnancy-specific adjustments
    if (pregnancy) {
      treatment = treatment.filter(t => 
        !t.toLowerCase().includes('contraindicated') && 
        !t.toLowerCase().includes('avoid')
      );
    }

    return {
      immediate: emergency ? ['Seek immediate medical attention', 'Go to nearest hospital'] : ['Monitor symptoms closely'],
      treatment,
      prevention: guideline.prevention,
      emergency
    };
  }

  /**
   * Determine follow-up requirements
   */
  private determineFollowUp(
    disease: string, 
    severity: string, 
    age?: number, 
    comorbidities?: string[]
  ): {
    required: boolean;
    timeframe: string;
    instructions: string[];
  } {
    const guideline = this.guidelines[disease];
    if (!guideline) {
      return {
        required: false,
        timeframe: 'Not specified',
        instructions: ['Monitor symptoms']
      };
    }

    let required = severity === 'severe' || severity === 'moderate';
    let timeframe = '24-48 hours';
    let instructions = ['Monitor symptoms', 'Take prescribed medications'];

    if (severity === 'severe') {
      timeframe = 'Immediate';
      instructions = ['Seek immediate medical care', 'Monitor vital signs', 'Follow emergency protocols'];
    } else if (severity === 'moderate') {
      timeframe = '24 hours';
      instructions = ['Monitor symptoms closely', 'Take prescribed medications', 'Rest and hydrate'];
    } else {
      timeframe = '48-72 hours';
      instructions = ['Monitor symptoms', 'Rest and hydrate', 'Seek care if symptoms worsen'];
    }

    // Age-specific follow-up
    if (age !== undefined && age < 2) {
      required = true;
      timeframe = '12-24 hours';
      instructions.push('Monitor for dehydration signs');
    }

    // Comorbidity-specific follow-up
    if (comorbidities && comorbidities.length > 0) {
      required = true;
      instructions.push('Monitor for complications due to existing conditions');
    }

    return {
      required,
      timeframe,
      instructions
    };
  }

  /**
   * Identify risk factors
   */
  private identifyRiskFactors(
    disease: string, 
    age?: number, 
    gender?: string, 
    pregnancy?: boolean, 
    travelHistory?: string[], 
    comorbidities?: string[]
  ): string[] {
    const riskFactors: string[] = [];

    if (age !== undefined) {
      if (age < 2) {
        riskFactors.push('Infant age group (high risk for severe disease)');
      } else if (age > 65) {
        riskFactors.push('Elderly age group (increased complication risk)');
      }
    }

    if (pregnancy) {
      riskFactors.push('Pregnancy (increased risk of severe disease)');
    }

    if (travelHistory && travelHistory.length > 0) {
      riskFactors.push('Recent travel history');
    }

    if (comorbidities && comorbidities.length > 0) {
      riskFactors.push(`Existing medical conditions: ${comorbidities.join(', ')}`);
    }

    // Disease-specific risk factors
    const guideline = this.guidelines[disease];
    if (guideline) {
      if (guideline.category === 'vector-borne') {
        riskFactors.push('Vector-borne disease risk');
      } else if (guideline.category === 'waterborne') {
        riskFactors.push('Waterborne disease risk');
      }
    }

    return riskFactors;
  }

  /**
   * Assess if professional medical help is required
   */
  private assessProfessionalHelpRequired(
    disease: string,
    severity: 'mild' | 'moderate' | 'severe',
    symptoms: string[],
    age?: number,
    illnessDuration?: number,
    comorbidities?: string[]
  ): { required: boolean; reason: string } {
    const guideline = this.guidelines[disease];
    if (!guideline) {
      return { required: false, reason: "Unknown condition" };
    }

    // Always require professional help for severe cases
    if (severity === 'severe') {
      return { 
        required: true, 
        reason: "Severe symptoms require immediate medical attention" 
      };
    }

    // Check for emergency indicators
    const hasEmergencyIndicators = guideline.emergencyIndicators.some(indicator => 
      symptoms.some(symptom => 
        symptom.toLowerCase().includes(indicator.toLowerCase()) ||
        indicator.toLowerCase().includes(symptom.toLowerCase())
      )
    );

    if (hasEmergencyIndicators) {
      return { 
        required: true, 
        reason: "Emergency symptoms detected - immediate medical care needed" 
      };
    }

    // Age-based considerations
    if (age !== undefined) {
      if (age < 2) {
        return { 
          required: true, 
          reason: "Infants under 2 years require medical evaluation" 
        };
      }
      if (age > 65) {
        return { 
          required: true, 
          reason: "Elderly patients (65+) should consult healthcare provider" 
        };
      }
    }

    // Duration-based considerations
    if (illnessDuration !== undefined) {
      if (illnessDuration >= 7) {
        return { 
          required: true, 
          reason: "Symptoms persisting for 7+ days require medical evaluation" 
        };
      }
      
      // Disease-specific duration thresholds
      if (disease === 'malaria' && illnessDuration >= 3) {
        return { 
          required: true, 
          reason: "Malaria symptoms for 3+ days require medical attention" 
        };
      }
      if (disease === 'dengue' && illnessDuration >= 4) {
        return { 
          required: true, 
          reason: "Dengue symptoms for 4+ days require medical monitoring" 
        };
      }
      if (disease === 'cholera' && illnessDuration >= 2) {
        return { 
          required: true, 
          reason: "Cholera symptoms for 2+ days require immediate medical care" 
        };
      }
      if (disease === 'typhoid' && illnessDuration >= 5) {
        return { 
          required: true, 
          reason: "Typhoid symptoms for 5+ days require medical evaluation" 
        };
      }
    }

    // Comorbidity considerations
    if (comorbidities && comorbidities.length > 0) {
      return { 
        required: true, 
        reason: "Existing health conditions require medical supervision" 
      };
    }

    // Moderate severity cases
    if (severity === 'moderate') {
      return { 
        required: true, 
        reason: "Moderate symptoms recommend medical consultation" 
      };
    }

    // Mild cases - usually don't require professional help
    return { 
      required: false, 
      reason: "Mild symptoms can be managed with home care and monitoring" 
    };
  }

  /**
   * Get potential complications
   */
  private getComplications(
    disease: string, 
    severity: string, 
    age?: number, 
    comorbidities?: string[]
  ): string[] {
    const guideline = this.guidelines[disease];
    if (!guideline) return [];

    const complications = [...(guideline.complications || [])];

    // Age-specific complications
    if (age !== undefined && age < 2) {
      complications.push('Dehydration (high risk in infants)');
    }

    if (age !== undefined && age > 65) {
      complications.push('Secondary infections (increased risk in elderly)');
    }

    // Comorbidity-specific complications
    if (comorbidities && comorbidities.length > 0) {
      if (comorbidities.includes('diabetes')) {
        complications.push('Diabetic complications');
      }
      if (comorbidities.includes('heart_disease')) {
        complications.push('Cardiac complications');
      }
    }

    return complications;
  }

  /**
   * Calculate diagnostic accuracy based on symptom matching
   */
  private calculateDiagnosticAccuracy(
    primaryDiagnosis: { disease: string; confidence: number; score: number },
    symptoms: string[]
  ): number {
    const guideline = this.guidelines[primaryDiagnosis.disease];
    if (!guideline) return 0.5; // Default accuracy for unknown conditions

    // Calculate based on symptom match ratio and WHO evidence level
    const totalSymptoms = guideline.symptoms.length;
    const matchedSymptoms = symptoms.filter(s => 
      guideline.symptoms.some(gs => gs.symptom === s)
    ).length;

    const symptomMatchRatio = totalSymptoms > 0 ? matchedSymptoms / totalSymptoms : 0;
    const confidenceBonus = primaryDiagnosis.confidence / 100;
    
    // WHO guidelines typically have 85-95% accuracy for major diseases
    const baseAccuracy = 0.85;
    const adjustedAccuracy = baseAccuracy + (symptomMatchRatio * 0.1) + (confidenceBonus * 0.05);
    
    return Math.min(0.95, Math.max(0.60, adjustedAccuracy));
  }

  /**
   * Validate WHO compliance for diagnosis
   */
  private validateWHOCompliance(disease: string): boolean {
    const guideline = this.guidelines[disease];
    if (!guideline) return false;

    // Check if guideline has WHO reference and proper structure
    const hasWHOReference = guideline.whoReference?.includes('WHO');
    const hasProperSymptoms = guideline.symptoms && guideline.symptoms.length > 0;
    const hasDiagnosticCriteria = guideline.diagnosticCriteria && 
      guideline.diagnosticCriteria.primary && 
      guideline.diagnosticCriteria.primary.length > 0;
    const hasEmergencyIndicators = guideline.emergencyIndicators && 
      guideline.emergencyIndicators.length > 0;

    return hasWHOReference && hasProperSymptoms && hasDiagnosticCriteria && hasEmergencyIndicators;
  }

  /**
   * Calculate information gain from conversation history
   */
  private calculateInformationGain(conversationHistory: Answer[]): number {
    if (conversationHistory.length === 0) return 0;

    // Calculate based on question quality and answers
    let totalGain = 0;
    conversationHistory.forEach(answer => {
      // Each answered question provides some information gain
      // Higher gain for pathognomonic symptoms and warning signs
      const baseGain = 0.1;
      const answerBonus = answer.answer === true ? 0.05 : 0.02;
      totalGain += baseGain + answerBonus;
    });

    return Math.min(1.0, totalGain);
  }

  /**
   * Calculate clinical confidence based on multiple factors
   */
  private calculateClinicalConfidence(
    primaryDiagnosis: { disease: string; confidence: number; score: number },
    severity: 'mild' | 'moderate' | 'severe',
    conversationHistory: Answer[]
  ): number {
    let confidence = primaryDiagnosis.confidence / 100; // Base confidence

    // Boost confidence based on conversation quality
    const conversationBonus = Math.min(0.15, conversationHistory.length * 0.02);
    confidence += conversationBonus;

    // Severity consistency check
    const severityBonus = severity === 'severe' ? 0.05 : 0.02;
    confidence += severityBonus;

    // WHO compliance bonus
    const whoCompliance = this.validateWHOCompliance(primaryDiagnosis.disease);
    if (whoCompliance) {
      confidence += 0.08;
    }

    return Math.min(0.98, Math.max(0.40, confidence));
  }

  /**
   * Process intelligent question answer and update diagnosis
   */
  public processQuestionAnswer(
    currentResult: MedicalDiagnosisResult,
    answer: Answer,
    originalRequest: DiagnosisRequest
  ): MedicalDiagnosisResult {
    // Add answer to conversation history
    const updatedHistory = [...(originalRequest.conversationHistory || []), answer];
    
    // Update disease scores based on answer
    const updatedScores = questionEngine.processAnswer(answer);
    
    // Re-run diagnosis with updated information
    const updatedRequest: DiagnosisRequest = {
      ...originalRequest,
      conversationHistory: updatedHistory
    };

    return this.diagnose(updatedRequest);
  }

  /**
   * Get performance metrics for monitoring system effectiveness
   */
  public getPerformanceMetrics(results: MedicalDiagnosisResult[]): {
    averageDiagnosticAccuracy: number;
    whoComplianceRate: number;
    averageInformationGain: number;
    averageClinicalConfidence: number;
    totalConsultations: number;
    severityDistribution: Record<string, number>;
    commonDiseases: Record<string, number>;
  } {
    if (results.length === 0) {
      return {
        averageDiagnosticAccuracy: 0,
        whoComplianceRate: 0,
        averageInformationGain: 0,
        averageClinicalConfidence: 0,
        totalConsultations: 0,
        severityDistribution: {},
        commonDiseases: {}
      };
    }

    const totalConsultations = results.length;
    
    // Calculate averages
    const averageDiagnosticAccuracy = results.reduce((sum, r) => 
      sum + (r.clinicalMetrics?.diagnosticAccuracy || 0), 0) / totalConsultations;
    
    const whoComplianceRate = results.reduce((sum, r) => 
      sum + (r.clinicalMetrics?.whoCompliance ? 1 : 0), 0) / totalConsultations;
    
    const averageInformationGain = results.reduce((sum, r) => 
      sum + (r.clinicalMetrics?.informationGain || 0), 0) / totalConsultations;
    
    const averageClinicalConfidence = results.reduce((sum, r) => 
      sum + (r.clinicalMetrics?.clinicalConfidence || 0), 0) / totalConsultations;

    // Severity distribution
    const severityDistribution: Record<string, number> = {};
    results.forEach(r => {
      const severity = r.primaryDiagnosis.severity;
      severityDistribution[severity] = (severityDistribution[severity] || 0) + 1;
    });

    // Common diseases
    const commonDiseases: Record<string, number> = {};
    results.forEach(r => {
      const disease = r.primaryDiagnosis.disease;
      commonDiseases[disease] = (commonDiseases[disease] || 0) + 1;
    });

    return {
      averageDiagnosticAccuracy,
      whoComplianceRate,
      averageInformationGain,
      averageClinicalConfidence,
      totalConsultations,
      severityDistribution,
      commonDiseases
    };
  }
}

// Export singleton instance
export const medicalDiagnosisEngine = new MedicalDiagnosisEngine();

// Export the class for testing
export { MedicalDiagnosisEngine };
