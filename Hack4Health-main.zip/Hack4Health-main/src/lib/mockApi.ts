import { translations } from './translations';

export interface SymptomAnalysisResponse {
  severity: 'mild' | 'moderate' | 'severe';
  symptoms: string[];
  recommendation: string;
  homeRemedies: string[];
  nearestClinic: string;
  ashaWorker: string;
  confidence: number;
  followUpRequired: boolean;
  emergencyContact: boolean;
}

export interface VaccinationResponse {
  dueVaccines: string[];
  nextDueDate: string;
  vaccinationCenter: string;
  reminderSet: boolean;
  familyMembers: Array<{
    name: string;
    age: number;
    dueVaccines: string[];
    nextDueDate: string;
  }>;
}

export interface OutbreakAlertResponse {
  activeAlerts: Array<{
    disease: string;
    severity: 'low' | 'moderate' | 'high';
    affectedAreas: string[];
    recommendation: string;
    symptoms: string[];
    prevention: string[];
    lastUpdated: string;
  }>;
  userAreaAlert: {
    disease: string;
    severity: 'low' | 'moderate' | 'high';
    recommendation: string;
    riskLevel: number;
  } | null;
}

export interface HealthTipResponse {
  tips: Array<{
    title: string;
    content: string;
    category: string;
    priority: 'low' | 'medium' | 'high';
  }>;
  weatherBased: {
    condition: string;
    advice: string;
  };
}

// Mock API functions
export const mockApi = {
  analyzeSymptoms: async (symptoms: string[], pincode: string, language: string = 'english'): Promise<SymptomAnalysisResponse> => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const severity = symptoms.length > 3 ? 'severe' : 
                    symptoms.length > 1 ? 'moderate' : 'mild';
    
    // Get translations for the specified language
    const t = translations[language] || translations.english;
    
    const responses = {
      mild: {
        severity: 'mild' as const,
        symptoms,
        recommendation: t.results.recommendations.mild,
        homeRemedies: [
          t.results.homeRemedies.rest,
          t.results.homeRemedies.hydration,
          t.results.homeRemedies.monitorTemperature,
          t.results.homeRemedies.lightMeals
        ],
        nearestClinic: t.results.clinics.puriPHC,
        ashaWorker: t.results.ashaWorkers.available,
        confidence: 0.85,
        followUpRequired: false,
        emergencyContact: false
      },
      moderate: {
        severity: 'moderate' as const,
        symptoms,
        recommendation: t.results.recommendations.moderate,
        homeRemedies: [
          t.results.homeRemedies.rest,
          t.results.homeRemedies.hydration,
          t.results.homeRemedies.monitorTemperature,
          t.results.homeRemedies.avoidExertion
        ],
        nearestClinic: t.results.clinics.puriDistrictHospital,
        ashaWorker: t.results.ashaWorkers.willContact,
        confidence: 0.92,
        followUpRequired: true,
        emergencyContact: false
      },
      severe: {
        severity: 'severe' as const,
        symptoms,
        recommendation: t.results.recommendations.severe,
        homeRemedies: [
          t.results.homeRemedies.rest,
          t.results.homeRemedies.hydration,
          t.results.homeRemedies.monitorVitalSigns
        ],
        nearestClinic: t.results.clinics.puriEmergency,
        ashaWorker: t.results.ashaWorkers.emergencyInitiated,
        confidence: 0.95,
        followUpRequired: true,
        emergencyContact: true
      }
    };
    
    return responses[severity];
  },

  getVaccinationSchedule: async (pincode: string, familyMembers: any[]): Promise<VaccinationResponse> => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    return {
      dueVaccines: ["BCG", "OPV", "DPT", "Measles"],
      nextDueDate: "2024-01-15",
      vaccinationCenter: "Puri PHC - Open Mon-Fri 9AM-5PM",
      reminderSet: true,
      familyMembers: [
        {
          name: "Rick Astley",
          age: 2,
          dueVaccines: ["DPT", "Measles"],
          nextDueDate: "2024-01-15"
        },
        {
          name: "Priya Devi",
          age: 25,
          dueVaccines: ["Tetanus"],
          nextDueDate: "2024-02-20"
        }
      ]
    };
  },

  getOutbreakAlerts: async (pincode: string, language: string = 'english'): Promise<OutbreakAlertResponse> => {
    await new Promise(resolve => setTimeout(resolve, 800));
    
    // Get translations for the specified language
    const t = translations[language] || translations.english;
    
    return {
      activeAlerts: [
        {
          disease: "Dengue",
          severity: "moderate",
          affectedAreas: ["751001", "751012", "752001"],
          recommendation: t.results.outbreakAlerts.dengue.recommendation,
          symptoms: t.results.outbreakAlerts.dengue.symptoms,
          prevention: t.results.outbreakAlerts.dengue.prevention,
          lastUpdated: "2024-01-10T10:30:00Z"
        },
        {
          disease: "Malaria",
          severity: "low",
          affectedAreas: ["768001", "768002"],
          recommendation: t.results.outbreakAlerts.malaria.recommendation,
          symptoms: t.results.outbreakAlerts.malaria.symptoms,
          prevention: t.results.outbreakAlerts.malaria.prevention,
          lastUpdated: "2024-01-09T15:45:00Z"
        }
      ],
      userAreaAlert: {
        disease: "Dengue",
        severity: "moderate",
        recommendation: t.results.outbreakAlerts.dengue.recommendation,
        riskLevel: 7
      }
    };
  },

  getHealthTips: async (pincode: string, language: string = 'english'): Promise<HealthTipResponse> => {
    await new Promise(resolve => setTimeout(resolve, 600));
    
    // Get translations for the specified language
    const t = translations[language] || translations.english;
    
    return {
      tips: [
        {
          title: t.results.healthTips.monsoon.title,
          content: t.results.healthTips.monsoon.content,
          category: "Seasonal",
          priority: "high"
        },
        {
          title: t.results.healthTips.vaccination.title,
          content: t.results.healthTips.vaccination.content,
          category: "Prevention",
          priority: "high"
        },
        {
          title: t.results.healthTips.hygiene.title,
          content: t.results.healthTips.hygiene.content,
          category: "Hygiene",
          priority: "medium"
        }
      ],
      weatherBased: {
        condition: "Monsoon Season",
        advice: t.results.healthTips.weatherAdvice
      }
    };
  },

  sendWhatsAppMessage: async (message: string, phoneNumber: string): Promise<{ success: boolean; messageId: string }> => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Simulate WhatsApp API call
    return {
      success: true,
      messageId: `wa_${Date.now()}`
    };
  },

  sendSMS: async (message: string, phoneNumber: string): Promise<{ success: boolean; messageId: string }> => {
    await new Promise(resolve => setTimeout(resolve, 1200));
    
    // Simulate SMS API call
    return {
      success: true,
      messageId: `sms_${Date.now()}`
    };
  },

  notifyASHAWorker: async (workerId: string, message: string, priority: 'low' | 'medium' | 'high'): Promise<{ success: boolean; notificationId: string }> => {
    await new Promise(resolve => setTimeout(resolve, 800));
    
    return {
      success: true,
      notificationId: `notif_${Date.now()}`
    };
  }
};

// Utility functions for API calls
export const apiUtils = {
  getSeverityColor: (severity: string) => {
    switch (severity) {
      case 'mild': return 'text-green-600 bg-green-100';
      case 'moderate': return 'text-yellow-600 bg-yellow-100';
      case 'severe': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  },
  
  getSeverityIcon: (severity: string) => {
    switch (severity) {
      case 'mild': return '✅';
      case 'moderate': return '⚠️';
      case 'severe': return '🚨';
      default: return 'ℹ️';
    }
  },
  
  formatPhoneNumber: (phone: string) => {
    return phone.replace(/(\+91)(\d{5})(\d{5})/, '$1-$2-$3');
  },
  
  getTimeAgo: (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Just now';
    if (diffInHours < 24) return `${diffInHours} hours ago`;
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays} days ago`;
  }
};
