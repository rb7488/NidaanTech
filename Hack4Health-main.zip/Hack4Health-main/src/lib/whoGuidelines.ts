// WHO Guidelines Dataset for Malaria, Dengue, Cholera, and Diarrhea
// Based on official WHO recommendations and clinical protocols

export interface DiseaseSymptom {
  symptom: string;
  weight: number; // 1-10 importance for diagnosis
  severity: 'mild' | 'moderate' | 'severe';
  description: string;
}

export interface DiseaseGuideline {
  disease: string;
  icd10Code: string;
  category: 'vector-borne' | 'waterborne' | 'infectious' | 'allergic' | 'respiratory';
  symptoms: DiseaseSymptom[];
  diagnosticCriteria: {
    primary: string[]; // Must have symptoms
    secondary: string[]; // Supporting symptoms
    exclusion: string[]; // Symptoms that rule out disease
  };
  severityAssessment: {
    mild: {
      criteria: string[];
      threshold: number; // Minimum score for mild
    };
    moderate: {
      criteria: string[];
      threshold: number;
    };
    severe: {
      criteria: string[];
      threshold: number;
    };
  };
  treatment: {
    mild: string[];
    moderate: string[];
    severe: string[];
  };
  prevention: string[];
  complications: string[];
  emergencyIndicators: string[];
}

export const whoGuidelines: Record<string, DiseaseGuideline> = {
  malaria: {
    disease: "Malaria",
    icd10Code: "B50-B54",
    category: "vector-borne",
    symptoms: [
      { symptom: "fever", weight: 10, severity: "moderate", description: "High fever (38.5°C or above)" },
      { symptom: "chills", weight: 8, severity: "mild", description: "Shaking chills and rigors" },
      { symptom: "sweating", weight: 7, severity: "mild", description: "Profuse sweating after fever" },
      { symptom: "headache", weight: 6, severity: "mild", description: "Severe headache" },
      { symptom: "muscle_pain", weight: 5, severity: "mild", description: "Body aches and muscle pain" },
      { symptom: "nausea", weight: 4, severity: "mild", description: "Nausea and vomiting" },
      { symptom: "fatigue", weight: 5, severity: "mild", description: "Extreme fatigue and weakness" },
      { symptom: "anemia", weight: 8, severity: "severe", description: "Pale skin, rapid heartbeat" },
      { symptom: "jaundice", weight: 9, severity: "severe", description: "Yellowing of skin and eyes" },
      { symptom: "confusion", weight: 10, severity: "severe", description: "Mental confusion or delirium" },
      { symptom: "seizures", weight: 10, severity: "severe", description: "Convulsions or seizures" },
      { symptom: "breathing_difficulty", weight: 9, severity: "severe", description: "Rapid or labored breathing" }
    ],
    diagnosticCriteria: {
      primary: ["fever", "chills", "sweating"],
      secondary: ["headache", "muscle_pain", "fatigue", "nausea"],
      exclusion: ["jaundice", "confusion", "seizures"]
    },
    severityAssessment: {
      mild: {
        criteria: ["fever", "chills", "headache"],
        threshold: 20
      },
      moderate: {
        criteria: ["fever", "chills", "sweating", "muscle_pain", "fatigue"],
        threshold: 35
      },
      severe: {
        criteria: ["fever", "anemia", "jaundice", "confusion", "seizures", "breathing_difficulty"],
        threshold: 50
      }
    },
    treatment: {
      mild: [
        "Artemisinin-based combination therapy (ACT)",
        "Paracetamol for fever",
        "Rest and hydration",
        "Monitor for 48 hours"
      ],
      moderate: [
        "Immediate ACT treatment",
        "Intravenous fluids if needed",
        "Antipyretics for fever",
        "Hospital monitoring"
      ],
      severe: [
        "Immediate hospitalization",
        "Intravenous artesunate",
        "Supportive care for complications",
        "Blood transfusion if severe anemia",
        "ICU monitoring"
      ]
    },
    prevention: [
      "Sleep under insecticide-treated bed nets",
      "Use mosquito repellent",
      "Wear long-sleeved clothing",
      "Eliminate standing water",
      "Take antimalarial prophylaxis if traveling to endemic areas"
    ],
    complications: [
      "Cerebral malaria",
      "Severe anemia",
      "Acute kidney injury",
      "Respiratory distress",
      "Hypoglycemia"
    ],
    emergencyIndicators: [
      "Confusion or altered consciousness",
      "Seizures",
      "Severe breathing difficulty",
      "Severe dehydration",
      "Signs of shock"
    ]
  },

  dengue: {
    disease: "Dengue",
    icd10Code: "A90-A91",
    category: "vector-borne",
    symptoms: [
      { symptom: "fever", weight: 9, severity: "moderate", description: "Sudden high fever (40°C or above)" },
      { symptom: "severe_headache", weight: 8, severity: "moderate", description: "Intense headache, especially behind eyes" },
      { symptom: "eye_pain", weight: 7, severity: "moderate", description: "Pain behind the eyes" },
      { symptom: "muscle_joint_pain", weight: 8, severity: "moderate", description: "Severe muscle and joint pain" },
      { symptom: "nausea", weight: 6, severity: "mild", description: "Nausea and vomiting" },
      { symptom: "rash", weight: 7, severity: "mild", description: "Skin rash appearing 2-5 days after fever" },
      { symptom: "bleeding", weight: 9, severity: "severe", description: "Bleeding from nose, gums, or under skin" },
      { symptom: "abdominal_pain", weight: 8, severity: "severe", description: "Severe abdominal pain" },
      { symptom: "persistent_vomiting", weight: 8, severity: "severe", description: "Persistent vomiting" },
      { symptom: "restlessness", weight: 7, severity: "severe", description: "Restlessness or irritability" },
      { symptom: "fatigue", weight: 5, severity: "mild", description: "Extreme fatigue" },
      { symptom: "low_platelets", weight: 9, severity: "severe", description: "Low platelet count (thrombocytopenia)" }
    ],
    diagnosticCriteria: {
      primary: ["fever", "severe_headache", "muscle_joint_pain"],
      secondary: ["eye_pain", "rash", "nausea", "fatigue"],
      exclusion: ["bleeding", "abdominal_pain", "persistent_vomiting"]
    },
    severityAssessment: {
      mild: {
        criteria: ["fever", "headache", "muscle_pain"],
        threshold: 20
      },
      moderate: {
        criteria: ["fever", "severe_headache", "muscle_joint_pain", "eye_pain", "rash"],
        threshold: 35
      },
      severe: {
        criteria: ["fever", "bleeding", "abdominal_pain", "persistent_vomiting", "restlessness", "low_platelets"],
        threshold: 50
      }
    },
    treatment: {
      mild: [
        "Paracetamol for fever and pain (avoid aspirin/NSAIDs)",
        "Rest and adequate hydration",
        "Monitor for warning signs",
        "No specific antiviral treatment"
      ],
      moderate: [
        "Paracetamol for fever",
        "Oral rehydration therapy",
        "Close monitoring for complications",
        "Hospital observation if needed"
      ],
      severe: [
        "Immediate hospitalization",
        "Intravenous fluid resuscitation",
        "Blood transfusion if severe bleeding",
        "Platelet transfusion if needed",
        "ICU monitoring for shock"
      ]
    },
    prevention: [
      "Use mosquito repellent containing DEET",
      "Wear long-sleeved clothing and pants",
      "Use mosquito nets",
      "Eliminate standing water around homes",
      "Use window and door screens"
    ],
    complications: [
      "Dengue hemorrhagic fever",
      "Dengue shock syndrome",
      "Severe bleeding",
      "Organ failure",
      "Death"
    ],
    emergencyIndicators: [
      "Severe abdominal pain",
      "Persistent vomiting",
      "Bleeding from nose or gums",
      "Restlessness or irritability",
      "Signs of shock (cold, clammy skin)"
    ]
  },

  cholera: {
    disease: "Cholera",
    icd10Code: "A00",
    category: "waterborne",
    symptoms: [
      { symptom: "watery_diarrhea", weight: 10, severity: "severe", description: "Profuse, watery diarrhea (rice-water stools)" },
      { symptom: "vomiting", weight: 8, severity: "moderate", description: "Severe vomiting" },
      { symptom: "dehydration", weight: 9, severity: "severe", description: "Signs of dehydration" },
      { symptom: "thirst", weight: 7, severity: "moderate", description: "Intense thirst" },
      { symptom: "muscle_cramps", weight: 6, severity: "moderate", description: "Severe muscle cramps" },
      { symptom: "weakness", weight: 7, severity: "moderate", description: "Extreme weakness" },
      { symptom: "sunken_eyes", weight: 8, severity: "severe", description: "Sunken eyes" },
      { symptom: "dry_mouth", weight: 6, severity: "moderate", description: "Dry mouth and throat" },
      { symptom: "rapid_pulse", weight: 8, severity: "severe", description: "Rapid, weak pulse" },
      { symptom: "low_blood_pressure", weight: 9, severity: "severe", description: "Low blood pressure" },
      { symptom: "shock", weight: 10, severity: "severe", description: "Signs of shock" },
      { symptom: "no_urine", weight: 9, severity: "severe", description: "Little or no urine output" }
    ],
    diagnosticCriteria: {
      primary: ["watery_diarrhea", "vomiting", "dehydration"],
      secondary: ["thirst", "muscle_cramps", "weakness"],
      exclusion: ["blood_in_stool", "high_fever"]
    },
    severityAssessment: {
      mild: {
        criteria: ["watery_diarrhea", "vomiting"],
        threshold: 15
      },
      moderate: {
        criteria: ["watery_diarrhea", "vomiting", "dehydration", "thirst", "muscle_cramps"],
        threshold: 30
      },
      severe: {
        criteria: ["watery_diarrhea", "vomiting", "dehydration", "sunken_eyes", "rapid_pulse", "shock", "no_urine"],
        threshold: 50
      }
    },
    treatment: {
      mild: [
        "Oral rehydration solution (ORS)",
        "Zinc supplements for children",
        "Continue breastfeeding for infants",
        "Monitor fluid intake and output"
      ],
      moderate: [
        "Aggressive oral rehydration",
        "Intravenous fluids if oral rehydration fails",
        "Antibiotics (doxycycline or azithromycin)",
        "Zinc supplements",
        "Hospital monitoring"
      ],
      severe: [
        "Immediate intravenous fluid resuscitation",
        "Antibiotics (doxycycline or azithromycin)",
        "ICU monitoring",
        "Correct electrolyte imbalances",
        "Treat shock if present"
      ]
    },
    prevention: [
      "Drink only safe, treated water",
      "Wash hands with soap and water",
      "Cook food thoroughly",
      "Avoid raw or undercooked seafood",
      "Use proper sanitation facilities"
    ],
    complications: [
      "Severe dehydration",
      "Electrolyte imbalances",
      "Kidney failure",
      "Shock",
      "Death"
    ],
    emergencyIndicators: [
      "Severe dehydration",
      "Signs of shock",
      "No urine output for 6+ hours",
      "Severe muscle cramps",
      "Altered consciousness"
    ]
  },

  diarrhea: {
    disease: "Acute Diarrhea",
    icd10Code: "A09",
    category: "infectious",
    symptoms: [
      { symptom: "loose_stools", weight: 8, severity: "mild", description: "Loose, watery stools" },
      { symptom: "frequent_bowel_movements", weight: 7, severity: "mild", description: "Increased frequency of bowel movements" },
      { symptom: "abdominal_cramps", weight: 6, severity: "mild", description: "Abdominal pain and cramping" },
      { symptom: "nausea", weight: 5, severity: "mild", description: "Nausea and vomiting" },
      { symptom: "fever", weight: 6, severity: "moderate", description: "Low-grade fever" },
      { symptom: "dehydration", weight: 8, severity: "severe", description: "Signs of dehydration" },
      { symptom: "thirst", weight: 6, severity: "moderate", description: "Increased thirst" },
      { symptom: "dry_mouth", weight: 6, severity: "moderate", description: "Dry mouth" },
      { symptom: "fatigue", weight: 5, severity: "mild", description: "Weakness and fatigue" },
      { symptom: "blood_in_stool", weight: 9, severity: "severe", description: "Blood or mucus in stool" },
      { symptom: "high_fever", weight: 8, severity: "severe", description: "High fever (38.5°C or above)" },
      { symptom: "severe_abdominal_pain", weight: 8, severity: "severe", description: "Severe abdominal pain" }
    ],
    diagnosticCriteria: {
      primary: ["loose_stools", "frequent_bowel_movements"],
      secondary: ["abdominal_cramps", "nausea", "fever"],
      exclusion: ["blood_in_stool", "high_fever", "severe_abdominal_pain"]
    },
    severityAssessment: {
      mild: {
        criteria: ["loose_stools", "frequent_bowel_movements", "abdominal_cramps"],
        threshold: 15
      },
      moderate: {
        criteria: ["loose_stools", "frequent_bowel_movements", "nausea", "fever", "dehydration"],
        threshold: 25
      },
      severe: {
        criteria: ["loose_stools", "frequent_bowel_movements", "blood_in_stool", "high_fever", "severe_abdominal_pain", "dehydration"],
        threshold: 40
      }
    },
    treatment: {
      mild: [
        "Oral rehydration solution (ORS)",
        "Continue normal diet",
        "Zinc supplements for children",
        "Probiotics may help",
        "Rest and avoid dairy if lactose intolerant"
      ],
      moderate: [
        "Aggressive oral rehydration",
        "BRAT diet (bananas, rice, applesauce, toast)",
        "Avoid caffeine and alcohol",
        "Zinc supplements",
        "Monitor for dehydration"
      ],
      severe: [
        "Immediate medical attention",
        "Intravenous fluids if severely dehydrated",
        "Antibiotics if bacterial cause suspected",
        "Hospital monitoring",
        "Stool culture to identify pathogen"
      ]
    },
    prevention: [
      "Wash hands frequently with soap and water",
      "Drink only safe, treated water",
      "Cook food thoroughly",
      "Avoid raw or undercooked foods",
      "Practice good food hygiene"
    ],
    complications: [
      "Dehydration",
      "Electrolyte imbalances",
      "Malnutrition (in children)",
      "Secondary infections",
      "Chronic diarrhea"
    ],
    emergencyIndicators: [
      "Signs of severe dehydration",
      "Blood in stool",
      "High fever",
      "Severe abdominal pain",
      "No improvement after 48 hours"
    ]
  },

  // Hay Fever / Allergic Rhinitis
  hay_fever: {
    disease: "Hay Fever (Allergic Rhinitis)",
    icd10Code: "J30",
    category: "allergic",
    symptoms: [
      { symptom: "sneezing", weight: 8, severity: "mild", description: "Frequent sneezing" },
      { symptom: "runny_nose", weight: 7, severity: "mild", description: "Clear, watery nasal discharge" },
      { symptom: "nasal_congestion", weight: 6, severity: "mild", description: "Stuffy nose" },
      { symptom: "itchy_nose", weight: 5, severity: "mild", description: "Itching in nose" },
      { symptom: "itchy_eyes", weight: 6, severity: "mild", description: "Itchy, watery eyes" },
      { symptom: "cough", weight: 4, severity: "mild", description: "Dry cough" },
      { symptom: "fatigue", weight: 3, severity: "mild", description: "Mild fatigue" },
      { symptom: "headache", weight: 4, severity: "mild", description: "Mild headache" }
    ],
    diagnosticCriteria: {
      primary: ["sneezing", "runny_nose", "nasal_congestion"],
      secondary: ["itchy_nose", "itchy_eyes", "cough"],
      exclusion: ["fever", "severe_headache", "body_aches"]
    },
    severityAssessment: {
      mild: {
        criteria: ["sneezing", "runny_nose"],
        threshold: 10
      },
      moderate: {
        criteria: ["sneezing", "runny_nose", "nasal_congestion", "itchy_eyes"],
        threshold: 20
      },
      severe: {
        criteria: ["sneezing", "runny_nose", "nasal_congestion", "itchy_eyes", "cough", "fatigue"],
        threshold: 30
      }
    },
    treatment: {
      mild: [
        "Antihistamines (cetirizine, loratadine)",
        "Nasal saline rinses",
        "Avoid allergens",
        "Use air purifiers"
      ],
      moderate: [
        "Antihistamines",
        "Nasal corticosteroids",
        "Decongestants (short-term)",
        "Eye drops for itchy eyes"
      ],
      severe: [
        "Combination therapy (antihistamines + nasal steroids)",
        "Immunotherapy consideration",
        "Environmental control measures",
        "Regular monitoring"
      ]
    },
    prevention: [
      "Identify and avoid allergens",
      "Keep windows closed during high pollen seasons",
      "Use HEPA air filters",
      "Wash bedding regularly",
      "Shower after outdoor activities"
    ],
    riskFactors: [
      "Family history of allergies",
      "Exposure to pollen, dust mites, or pet dander",
      "Living in urban areas with high pollution",
      "Seasonal changes"
    ],
    complications: [
      "Chronic sinusitis",
      "Asthma development",
      "Sleep disturbances",
      "Reduced quality of life"
    ],
    emergencyIndicators: [
      "Severe breathing difficulty",
      "Anaphylaxis symptoms",
      "High fever with symptoms"
    ]
  },

  // Seasonal Fever / Viral Fever
  seasonal_fever: {
    disease: "Seasonal Fever (Viral Fever)",
    icd10Code: "B34",
    category: "viral",
    symptoms: [
      { symptom: "fever", weight: 6, severity: "moderate", description: "Elevated body temperature" },
      { symptom: "headache", weight: 5, severity: "moderate", description: "Head pain" },
      { symptom: "body_aches", weight: 6, severity: "moderate", description: "Muscle and joint pain" },
      { symptom: "fatigue", weight: 5, severity: "mild", description: "Tiredness and weakness" },
      { symptom: "chills", weight: 4, severity: "mild", description: "Feeling cold" },
      { symptom: "sweating", weight: 4, severity: "mild", description: "Excessive sweating" },
      { symptom: "loss_of_appetite", weight: 3, severity: "mild", description: "Reduced appetite" },
      { symptom: "nausea", weight: 3, severity: "mild", description: "Feeling sick" },
      { symptom: "cough", weight: 6, severity: "mild", description: "Dry cough (more specific for seasonal fever)" },
      { symptom: "sore_throat", weight: 5, severity: "mild", description: "Throat irritation" },
      { symptom: "runny_nose", weight: 5, severity: "mild", description: "Nasal discharge with viral fever" }
    ],
    diagnosticCriteria: {
      primary: ["fever", "headache", "body_aches"],
      secondary: ["fatigue", "chills", "sweating", "cough", "sore_throat", "runny_nose"],
      exclusion: ["severe_breathing_difficulty", "confusion", "seizures"]
    },
    severityAssessment: {
      mild: {
        criteria: ["fever", "headache"],
        threshold: 12
      },
      moderate: {
        criteria: ["fever", "headache", "body_aches", "fatigue"],
        threshold: 25
      },
      severe: {
        criteria: ["fever", "headache", "body_aches", "fatigue", "chills", "sweating"],
        threshold: 35
      }
    },
    treatment: {
      mild: [
        "Rest and adequate sleep",
        "Plenty of fluids",
        "Paracetamol for fever and pain",
        "Light, nutritious meals"
      ],
      moderate: [
        "Rest and fluids",
        "Paracetamol or ibuprofen",
        "Warm compresses for body aches",
        "Monitor temperature regularly"
      ],
      severe: [
        "Medical consultation recommended",
        "Antipyretics as prescribed",
        "Intravenous fluids if needed",
        "Close monitoring of vital signs"
      ]
    },
    prevention: [
      "Maintain good hygiene",
      "Avoid close contact with sick individuals",
      "Get adequate rest and nutrition",
      "Stay hydrated",
      "Consider flu vaccination"
    ],
    riskFactors: [
      "Weakened immune system",
      "Close contact with infected individuals",
      "Poor hygiene practices",
      "Seasonal changes",
      "Stress and fatigue"
    ],
    complications: [
      "Secondary bacterial infections",
      "Dehydration",
      "Febrile seizures (in children)",
      "Prolonged fatigue"
    ],
    emergencyIndicators: [
      "High fever (>103°F) lasting more than 3 days",
      "Severe headache with neck stiffness",
      "Difficulty breathing",
      "Confusion or altered mental state",
      "Signs of dehydration"
    ]
  },

  // Typhoid Fever
  typhoid: {
    disease: "Typhoid Fever",
    icd10Code: "A01",
    category: "bacterial",
    symptoms: [
      { symptom: "fever", weight: 6, severity: "severe", description: "High, sustained fever" },
      { symptom: "headache", weight: 7, severity: "moderate", description: "Severe headache" },
      { symptom: "abdominal_pain", weight: 8, severity: "moderate", description: "Abdominal discomfort" },
      { symptom: "diarrhea", weight: 6, severity: "moderate", description: "Watery diarrhea" },
      { symptom: "constipation", weight: 5, severity: "mild", description: "Constipation (in some cases)" },
      { symptom: "fatigue", weight: 5, severity: "moderate", description: "Extreme fatigue" },
      { symptom: "loss_of_appetite", weight: 5, severity: "moderate", description: "Loss of appetite" },
      { symptom: "rose_spots", weight: 9, severity: "moderate", description: "Rose-colored spots on chest" }
    ],
    diagnosticCriteria: {
      primary: ["fever", "headache", "abdominal_pain"],
      secondary: ["diarrhea", "fatigue", "loss_of_appetite"],
      exclusion: ["severe_breathing_difficulty", "confusion"]
    },
    severityAssessment: {
      mild: {
        criteria: ["fever", "headache"],
        threshold: 15
      },
      moderate: {
        criteria: ["fever", "headache", "abdominal_pain", "fatigue"],
        threshold: 25
      },
      severe: {
        criteria: ["fever", "headache", "abdominal_pain", "fatigue", "diarrhea", "rose_spots"],
        threshold: 40
      }
    },
    treatment: {
      mild: [
        "Antibiotics (azithromycin, ciprofloxacin)",
        "Rest and fluids",
        "Paracetamol for fever",
        "Light, easily digestible food"
      ],
      moderate: [
        "Antibiotic therapy",
        "Hospitalization may be required",
        "Intravenous fluids",
        "Close monitoring"
      ],
      severe: [
        "Hospitalization required",
        "Intravenous antibiotics",
        "Supportive care",
        "Monitor for complications"
      ]
    },
    prevention: [
      "Typhoid vaccination",
      "Safe food and water practices",
      "Proper hand hygiene",
      "Avoid street food in endemic areas",
      "Boil or purify water"
    ],
    riskFactors: [
      "Travel to endemic areas",
      "Consumption of contaminated food/water",
      "Poor sanitation",
      "Weakened immune system"
    ],
    complications: [
      "Intestinal perforation",
      "Severe dehydration",
      "Neurological complications",
      "Myocarditis",
      "Pneumonia"
    ],
    emergencyIndicators: [
      "High fever with severe headache",
      "Severe abdominal pain",
      "Signs of intestinal perforation",
      "Severe dehydration",
      "Altered mental state"
    ]
  },

  // Common Cold
  common_cold: {
    disease: "Common Cold",
    icd10Code: "J00",
    category: "viral",
    symptoms: [
      { symptom: "runny_nose", weight: 9, severity: "mild", description: "Nasal congestion and discharge" },
      { symptom: "sneezing", weight: 8, severity: "mild", description: "Frequent sneezing" },
      { symptom: "sore_throat", weight: 7, severity: "mild", description: "Throat irritation" },
      { symptom: "cough", weight: 6, severity: "mild", description: "Dry or productive cough" },
      { symptom: "fever", weight: 5, severity: "mild", description: "Mild fever (usually low-grade)" },
      { symptom: "headache", weight: 4, severity: "mild", description: "Mild headache" },
      { symptom: "fatigue", weight: 3, severity: "mild", description: "Mild tiredness" },
      { symptom: "low_grade_fever", weight: 4, severity: "mild", description: "Slight temperature elevation" }
    ],
    diagnosticCriteria: {
      primary: ["runny_nose", "sneezing", "sore_throat"],
      secondary: ["cough", "headache", "fatigue", "fever"],
      exclusion: ["high_fever", "severe_breathing_difficulty"]
    },
    severityAssessment: {
      mild: {
        criteria: ["runny_nose", "sneezing"],
        threshold: 10
      },
      moderate: {
        criteria: ["runny_nose", "sneezing", "sore_throat", "cough"],
        threshold: 20
      },
      severe: {
        criteria: ["runny_nose", "sneezing", "sore_throat", "cough", "headache", "fatigue"],
        threshold: 30
      }
    },
    treatment: {
      mild: [
        "Rest and fluids",
        "Saline nasal drops",
        "Honey for cough",
        "Warm salt water gargles"
      ],
      moderate: [
        "Rest and fluids",
        "Over-the-counter cold medications",
        "Nasal decongestants",
        "Cough suppressants if needed"
      ],
      severe: [
        "Medical consultation if symptoms persist",
        "Antibiotics only if bacterial infection suspected",
        "Supportive care",
        "Monitor for complications"
      ]
    },
    prevention: [
      "Frequent hand washing",
      "Avoid close contact with sick individuals",
      "Cover mouth when coughing/sneezing",
      "Maintain good hygiene",
      "Adequate rest and nutrition"
    ],
    riskFactors: [
      "Close contact with infected individuals",
      "Weakened immune system",
      "Seasonal changes",
      "Poor hygiene practices"
    ],
    complications: [
      "Secondary bacterial infections",
      "Sinusitis",
      "Ear infections",
      "Bronchitis",
      "Pneumonia (rare)"
    ],
    emergencyIndicators: [
      "High fever (>102°F)",
      "Severe breathing difficulty",
      "Symptoms lasting more than 10 days",
      "Severe headache with neck stiffness"
    ]
  },

  tuberculosis: {
    disease: "Tuberculosis (TB)",
    icd10Code: "A15-A19",
    category: "infectious",
    symptoms: [
      {
        symptom: "persistent cough",
        weight: 9,
        severity: "moderate",
        description: "Cough lasting more than 3 weeks"
      },
      {
        symptom: "coughing up blood",
        weight: 10,
        severity: "severe",
        description: "Hemoptysis - blood in sputum"
      },
      {
        symptom: "chest pain",
        weight: 7,
        severity: "moderate", 
        description: "Pain in chest that worsens with breathing or coughing"
      },
      {
        symptom: "weight loss",
        weight: 8,
        severity: "moderate",
        description: "Unintentional weight loss over weeks/months"
      },
      {
        symptom: "night sweats",
        weight: 8,
        severity: "moderate",
        description: "Excessive sweating during sleep"
      },
      {
        symptom: "fever",
        weight: 7,
        severity: "moderate",
        description: "Low-grade fever, especially in evening"
      },
      {
        symptom: "fatigue",
        weight: 6,
        severity: "mild",
        description: "Persistent tiredness and weakness"
      },
      {
        symptom: "loss of appetite",
        weight: 6,
        severity: "mild",
        description: "Decreased desire to eat"
      },
      {
        symptom: "shortness of breath",
        weight: 8,
        severity: "severe",
        description: "Difficulty breathing, especially with exertion"
      },
      {
        symptom: "hoarse voice",
        weight: 5,
        severity: "mild",
        description: "Voice changes due to laryngeal involvement"
      }
    ],
    diagnosticCriteria: {
      primary: ["persistent cough", "weight loss", "night sweats"],
      secondary: ["fever", "fatigue", "loss of appetite", "chest pain"],
      exclusion: ["acute onset", "rapid improvement with rest"]
    },
    severityAssessment: {
      mild: {
        criteria: ["Localized disease", "No systemic symptoms", "Good general condition"],
        threshold: 20
      },
      moderate: {
        criteria: ["Systemic symptoms present", "Some functional limitation"],
        threshold: 35
      },
      severe: {
        criteria: ["Hemoptysis", "Severe weight loss", "Respiratory distress", "Multi-organ involvement"],
        threshold: 50
      }
    },
    treatment: {
      mild: ["Anti-TB drugs (DOTS)", "Nutritional support", "Regular monitoring"],
      moderate: ["Intensive anti-TB treatment", "Close monitoring", "Nutritional rehabilitation"],
      severe: ["Hospitalization", "Intensive anti-TB treatment", "Supportive care", "Management of complications"]
    },
    prevention: ["BCG vaccination", "Contact screening", "Good ventilation", "Infection control measures"],
    complications: ["Pleural effusion", "Pneumothorax", "Respiratory failure", "Multi-drug resistance"],
    emergencyIndicators: ["Hemoptysis", "Severe breathing difficulty", "High fever with chills", "Chest pain with breathing"]
  },

  hepatitis_a: {
    disease: "Hepatitis A",
    icd10Code: "B15",
    category: "infectious",
    symptoms: [
      {
        symptom: "jaundice",
        weight: 10,
        severity: "moderate",
        description: "Yellowing of skin and eyes"
      },
      {
        symptom: "dark urine",
        weight: 9,
        severity: "moderate",
        description: "Tea-colored urine"
      },
      {
        symptom: "pale stool",
        weight: 8,
        severity: "moderate",
        description: "Clay-colored or pale bowel movements"
      },
      {
        symptom: "abdominal pain",
        weight: 8,
        severity: "moderate",
        description: "Pain in upper right abdomen"
      },
      {
        symptom: "nausea",
        weight: 7,
        severity: "mild",
        description: "Feeling sick to stomach"
      },
      {
        symptom: "vomiting",
        weight: 7,
        severity: "moderate",
        description: "Throwing up, especially after eating"
      },
      {
        symptom: "fatigue",
        weight: 8,
        severity: "moderate",
        description: "Extreme tiredness and weakness"
      },
      {
        symptom: "loss of appetite",
        weight: 7,
        severity: "mild",
        description: "No desire to eat"
      },
      {
        symptom: "fever",
        weight: 6,
        severity: "mild",
        description: "Low to moderate grade fever"
      },
      {
        symptom: "muscle aches",
        weight: 5,
        severity: "mild",
        description: "General body aches and pains"
      },
      {
        symptom: "itchy skin",
        weight: 6,
        severity: "mild",
        description: "Skin itching due to bile salts"
      }
    ],
    diagnosticCriteria: {
      primary: ["jaundice", "dark urine", "pale stool"],
      secondary: ["abdominal pain", "nausea", "vomiting", "fatigue"],
      exclusion: ["chronic symptoms", "drug-induced hepatitis"]
    },
    severityAssessment: {
      mild: {
        criteria: ["Mild jaundice", "Normal appetite", "Able to perform daily activities"],
        threshold: 20
      },
      moderate: {
        criteria: ["Obvious jaundice", "Significant fatigue", "Some activity limitation"],
        threshold: 35
      },
      severe: {
        criteria: ["Severe jaundice", "Persistent vomiting", "Signs of liver failure"],
        threshold: 50
      }
    },
    treatment: {
      mild: ["Rest", "Adequate hydration", "Avoid alcohol", "Light diet"],
      moderate: ["Close monitoring", "Symptomatic treatment", "Nutritional support"],
      severe: ["Hospitalization", "IV fluids", "Liver function monitoring", "Complication management"]
    },
    prevention: ["Hepatitis A vaccine", "Good hygiene", "Safe food and water", "Proper sanitation"],
    complications: ["Prolonged cholestasis", "Relapsing hepatitis", "Acute liver failure (rare)"],
    emergencyIndicators: ["Persistent vomiting", "Signs of dehydration", "Altered mental status", "Bleeding tendency"]
  },

  chikungunya: {
    disease: "Chikungunya",
    icd10Code: "A92.0",
    category: "vector-borne",
    symptoms: [
      {
        symptom: "sudden fever",
        weight: 9,
        severity: "moderate",
        description: "Abrupt onset of high fever (>38.5°C)"
      },
      {
        symptom: "severe joint pain",
        weight: 10,
        severity: "severe",
        description: "Intense arthralgia, especially in hands, wrists, ankles"
      },
      {
        symptom: "joint swelling",
        weight: 8,
        severity: "moderate",
        description: "Visible swelling of affected joints"
      },
      {
        symptom: "muscle pain",
        weight: 7,
        severity: "moderate",
        description: "Myalgia affecting multiple muscle groups"
      },
      {
        symptom: "headache",
        weight: 7,
        severity: "moderate",
        description: "Severe headache, often frontal"
      },
      {
        symptom: "skin rash",
        weight: 8,
        severity: "mild",
        description: "Maculopapular rash, usually appears 2-5 days after fever onset"
      },
      {
        symptom: "fatigue",
        weight: 6,
        severity: "moderate",
        description: "Extreme tiredness and weakness"
      },
      {
        symptom: "nausea",
        weight: 5,
        severity: "mild",
        description: "Feeling sick to stomach"
      },
      {
        symptom: "vomiting",
        weight: 5,
        severity: "mild",
        description: "Episodes of throwing up"
      },
      {
        symptom: "back pain",
        weight: 6,
        severity: "moderate",
        description: "Lower back pain and stiffness"
      },
      {
        symptom: "eye pain",
        weight: 6,
        severity: "mild",
        description: "Pain behind the eyes (retro-orbital pain)"
      },
      {
        symptom: "morning stiffness",
        weight: 8,
        severity: "moderate",
        description: "Joint stiffness worse in the morning"
      }
    ],
    diagnosticCriteria: {
      primary: ["sudden fever", "severe joint pain", "joint swelling"],
      secondary: ["muscle pain", "headache", "skin rash", "fatigue"],
      exclusion: ["gradual onset", "no joint involvement", "chronic arthritis history"]
    },
    severityAssessment: {
      mild: {
        criteria: ["Fever and joint pain manageable", "No functional limitation", "No complications"],
        threshold: 25
      },
      moderate: {
        criteria: ["Significant joint pain", "Some functional limitation", "Rash present"],
        threshold: 40
      },
      severe: {
        criteria: ["Severe joint pain", "Unable to perform daily activities", "Complications present"],
        threshold: 55
      }
    },
    treatment: {
      mild: ["Paracetamol for fever and pain", "Rest", "Adequate fluids", "Avoid aspirin"],
      moderate: ["NSAIDs for joint pain", "Physical therapy", "Topical analgesics"],
      severe: ["Hospitalization if needed", "Stronger analgesics", "Management of complications", "Rehabilitation"]
    },
    prevention: ["Mosquito control", "Use of bed nets", "Eliminate breeding sites", "Personal protection"],
    complications: ["Chronic arthralgia", "Persistent joint stiffness", "Depression", "Cardiovascular complications (rare)"],
    emergencyIndicators: ["Severe dehydration", "Bleeding", "Respiratory distress", "Neurological symptoms"]
  }
};

// Symptom mapping for user input
export const symptomMapping: Record<string, string[]> = {
  // Fever variations
  "fever": ["fever", "high fever", "temperature", "hot", "burning"],
  "high_fever": ["high fever", "very high fever", "40 degrees", "severe fever"],
  
  // Headache variations
  "headache": ["headache", "head pain", "head ache"],
  "severe_headache": ["severe headache", "bad headache", "intense headache", "terrible headache"],
  
  // Pain variations
  "muscle_pain": ["muscle pain", "body ache", "muscle ache", "body pain"],
  "muscle_joint_pain": ["joint pain", "muscle and joint pain", "bone pain", "joint ache"],
  "abdominal_pain": ["stomach pain", "belly pain", "abdominal pain", "tummy ache", "tummy pain"],
  "severe_abdominal_pain": ["severe stomach pain", "bad stomach pain", "intense abdominal pain"],
  "abdominal_cramps": ["stomach cramps", "belly cramps", "abdominal cramps"],
  "muscle_cramps": ["muscle cramps", "leg cramps", "body cramps"],
  "eye_pain": ["eye pain", "pain behind eyes", "sore eyes"],
  
  // Gastrointestinal
  "nausea": ["nausea", "feeling sick", "queasy", "sick feeling"],
  "vomiting": ["vomiting", "throwing up", "puking", "being sick"],
  "persistent_vomiting": ["persistent vomiting", "continuous vomiting", "can't stop vomiting"],
  "loose_stools": ["loose stools", "runny stool"],
  "frequent_bowel_movements": ["frequent bowel movements", "going to toilet often", "many times"],
  "watery_diarrhea": ["watery diarrhea", "rice water stool", "profuse diarrhea", "diarrhea", "watery stool"],
  "diarrhea": ["diarrhea", "loose motions", "stomach upset", "loose bowel movements"],
  "blood_in_stool": ["blood in stool", "bloody stool", "blood when going to toilet"],
  
  // Dehydration symptoms
  "dehydration": ["dehydration", "dehydrated", "drying out", "severe dehydration"],
  "thirst": ["thirst", "very thirsty", "extreme thirst"],
  "dry_mouth": ["dry mouth", "mouth dry", "throat dry"],
  "sunken_eyes": ["sunken eyes", "eyes sunken", "hollow eyes"],
  "no_urine": ["no urine", "not urinating", "no pee", "can't pee"],
  
  // Emergency symptoms
  "confusion": ["confusion", "confused", "disoriented", "altered consciousness"],
  "seizures": ["seizures", "convulsions", "fits", "epileptic fit"],
  "shock": ["shock", "signs of shock", "cold skin", "clammy skin"],
  "bleeding": ["bleeding", "blood", "hemorrhage", "nosebleed"],
  "breathing_difficulty": ["breathing difficulty", "shortness of breath", "trouble breathing", "can't breathe"],
  "severe_abdominal_pain": ["severe stomach pain", "intense abdominal pain", "bad stomach pain"],
  "persistent_vomiting": ["persistent vomiting", "continuous vomiting", "can't stop vomiting"],
  
  // Other symptoms
  "chills": ["chills", "shivering", "cold shivers", "rigors"],
  "sweating": ["sweating", "sweat", "perspiration", "sweating a lot"],
  "fatigue": ["fatigue", "tired", "exhausted", "weak", "no energy"],
  "sore_throat": ["sore throat", "throat pain", "throat irritation", "scratchy throat"],
  "loss_of_appetite": ["loss of appetite", "no appetite", "don't want to eat", "not hungry"],
  "weakness": ["weakness", "weak", "feeling weak", "no strength"],
  "rash": ["rash", "skin rash", "red spots", "skin spots"],
  "bleeding": ["bleeding", "blood", "nose bleed", "gum bleeding"],
  "restlessness": ["restlessness", "restless", "irritable", "agitated"],
  "confusion": ["confusion", "confused", "mental confusion", "not thinking clearly"],
  "seizures": ["seizures", "convulsions", "fits", "shaking"],
  "breathing_difficulty": ["breathing difficulty", "trouble breathing", "shortness of breath", "can't breathe"],
  "rapid_pulse": ["rapid pulse", "fast heartbeat", "heart racing", "pulse fast"],
  "low_blood_pressure": ["low blood pressure", "blood pressure low", "dizzy", "lightheaded"],
  "shock": ["shock", "in shock", "shock symptoms", "cold and clammy"],
  "anemia": ["anemia", "pale", "pale skin", "low blood"],
  "jaundice": ["jaundice", "yellow skin", "yellow eyes", "yellowing"],
  "low_platelets": ["low platelets", "bleeding easily", "bruising easily"],
  
  // New symptoms for additional diseases
  "sneezing": ["sneezing", "sneezes", "sneezing a lot"],
  "runny_nose": ["runny nose", "nose running", "nasal discharge", "watery nose"],
  "nasal_congestion": ["nasal congestion", "stuffy nose", "blocked nose", "nose blocked"],
  "itchy_nose": ["itchy nose", "nose itching", "nose tickling"],
  "itchy_eyes": ["itchy eyes", "eyes itching", "eye irritation", "watery eyes"],
  "sore_throat": ["sore throat", "throat pain", "throat irritation", "throat sore"],
  "body_aches": ["body aches", "muscle pain", "joint pain", "body pain", "aching"],
  "loss_of_appetite": ["loss of appetite", "no appetite", "not hungry", "don't want to eat"],
  "nausea": ["nausea", "feeling sick", "queasy", "nauseous"],
  "constipation": ["constipation", "can't go to toilet", "hard stools", "difficulty passing stool"],
  "rose_spots": ["rose spots", "pink spots", "spots on chest", "skin spots"],
  "low_grade_fever": ["low grade fever", "slight fever", "mild fever", "low fever"],
  
  // TB symptoms
  "persistent_cough": ["persistent cough", "chronic cough", "cough for weeks", "long lasting cough"],
  "coughing_up_blood": ["coughing up blood", "blood in sputum", "hemoptysis", "bloody cough"],
  "night_sweats": ["night sweats", "sweating at night", "drenching sweats", "excessive night sweating"],
  "hoarse_voice": ["hoarse voice", "voice changes", "raspy voice", "throat voice"],
  
  // Hepatitis symptoms  
  "jaundice": ["jaundice", "yellow skin", "yellow eyes", "yellowing"],
  "dark_urine": ["dark urine", "tea colored urine", "brown urine", "dark colored urine"],
  "pale_stool": ["pale stool", "clay colored stool", "light colored stool", "white stool"],
  "itchy_skin": ["itchy skin", "skin itching", "pruritus", "scratchy skin"],
  
  // Chikungunya symptoms
  "sudden_fever": ["sudden fever", "abrupt fever", "fever came suddenly", "immediate fever"],
  "severe_joint_pain": ["severe joint pain", "intense joint pain", "extreme joint pain", "unbearable joint pain"],
  "joint_swelling": ["joint swelling", "swollen joints", "joints are swollen", "puffy joints"],
  "morning_stiffness": ["morning stiffness", "stiff in morning", "joints stiff morning", "morning joint stiffness"],
  "skin_rash": ["skin rash", "rash on skin", "red rash", "body rash"],
  "eye_pain": ["eye pain", "pain behind eyes", "retro-orbital pain", "eyes hurt"],
  "back_pain": ["back pain", "lower back pain", "spine pain", "backache"]
};

// Function to map user input to standardized symptoms
export function mapUserSymptomsToStandard(userSymptoms: string[]): string[] {
  const mappedSymptoms: string[] = [];
  
  userSymptoms.forEach(userSymptom => {
    const lowerSymptom = userSymptom.toLowerCase().trim();
    
    // Direct match first
    if (symptomMapping[lowerSymptom]) {
      mappedSymptoms.push(lowerSymptom);
      return;
    }
    
    // Check for partial matches
    for (const [standardSymptom, variations] of Object.entries(symptomMapping)) {
      if (variations.some(variation => 
        lowerSymptom.includes(variation) || variation.includes(lowerSymptom)
      )) {
        mappedSymptoms.push(standardSymptom);
        break;
      }
    }
  });
  
  return [...new Set(mappedSymptoms)]; // Remove duplicates
}
