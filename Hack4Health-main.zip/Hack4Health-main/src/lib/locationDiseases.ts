// Location-based disease mapping for Indian pincodes
// This maps pincodes to common diseases in those areas

export interface LocationDiseaseData {
  pincode: string;
  state: string;
  district: string;
  commonDiseases: string[];
  seasonalDiseases: {
    monsoon: string[];
    summer: string[];
    winter: string[];
  };
  endemicDiseases: string[];
  riskFactors: string[];
}

// Mock location-based disease data
// In a real implementation, this would be connected to a database or API
export const locationDiseaseMapping: Record<string, LocationDiseaseData> = {
  // Odisha pincodes
  "751001": {
    pincode: "751001",
    state: "Odisha",
    district: "Bhubaneswar",
    commonDiseases: ["malaria", "dengue", "diarrhea", "seasonal_fever"],
    seasonalDiseases: {
      monsoon: ["malaria", "dengue", "cholera", "diarrhea"],
      summer: ["heat_stroke", "dehydration", "seasonal_fever"],
      winter: ["common_cold", "hay_fever", "respiratory_infections"]
    },
    endemicDiseases: ["malaria", "dengue"],
    riskFactors: ["high_humidity", "stagnant_water", "mosquito_breeding"]
  },
  "751002": {
    pincode: "751002",
    state: "Odisha",
    district: "Bhubaneswar",
    commonDiseases: ["malaria", "dengue", "diarrhea", "seasonal_fever"],
    seasonalDiseases: {
      monsoon: ["malaria", "dengue", "cholera", "diarrhea"],
      summer: ["heat_stroke", "dehydration", "seasonal_fever"],
      winter: ["common_cold", "hay_fever", "respiratory_infections"]
    },
    endemicDiseases: ["malaria", "dengue"],
    riskFactors: ["high_humidity", "stagnant_water", "mosquito_breeding"]
  },
  "751003": {
    pincode: "751003",
    state: "Odisha",
    district: "Bhubaneswar",
    commonDiseases: ["malaria", "dengue", "diarrhea", "seasonal_fever"],
    seasonalDiseases: {
      monsoon: ["malaria", "dengue", "cholera", "diarrhea"],
      summer: ["heat_stroke", "dehydration", "seasonal_fever"],
      winter: ["common_cold", "hay_fever", "respiratory_infections"]
    },
    endemicDiseases: ["malaria", "dengue"],
    riskFactors: ["high_humidity", "stagnant_water", "mosquito_breeding"]
  },
  "751004": {
    pincode: "751004",
    state: "Odisha",
    district: "Bhubaneswar",
    commonDiseases: ["malaria", "dengue", "diarrhea", "seasonal_fever"],
    seasonalDiseases: {
      monsoon: ["malaria", "dengue", "cholera", "diarrhea"],
      summer: ["heat_stroke", "dehydration", "seasonal_fever"],
      winter: ["common_cold", "hay_fever", "respiratory_infections"]
    },
    endemicDiseases: ["malaria", "dengue"],
    riskFactors: ["high_humidity", "stagnant_water", "mosquito_breeding"]
  },
  "751005": {
    pincode: "751005",
    state: "Odisha",
    district: "Bhubaneswar",
    commonDiseases: ["malaria", "dengue", "diarrhea", "seasonal_fever"],
    seasonalDiseases: {
      monsoon: ["malaria", "dengue", "cholera", "diarrhea"],
      summer: ["heat_stroke", "dehydration", "seasonal_fever"],
      winter: ["common_cold", "hay_fever", "respiratory_infections"]
    },
    endemicDiseases: ["malaria", "dengue"],
    riskFactors: ["high_humidity", "stagnant_water", "mosquito_breeding"]
  },
  "751006": {
    pincode: "751006",
    state: "Odisha",
    district: "Bhubaneswar",
    commonDiseases: ["malaria", "dengue", "diarrhea", "seasonal_fever"],
    seasonalDiseases: {
      monsoon: ["malaria", "dengue", "cholera", "diarrhea"],
      summer: ["heat_stroke", "dehydration", "seasonal_fever"],
      winter: ["common_cold", "hay_fever", "respiratory_infections"]
    },
    endemicDiseases: ["malaria", "dengue"],
    riskFactors: ["high_humidity", "stagnant_water", "mosquito_breeding"]
  },
  "751007": {
    pincode: "751007",
    state: "Odisha",
    district: "Bhubaneswar",
    commonDiseases: ["malaria", "dengue", "diarrhea", "seasonal_fever"],
    seasonalDiseases: {
      monsoon: ["malaria", "dengue", "cholera", "diarrhea"],
      summer: ["heat_stroke", "dehydration", "seasonal_fever"],
      winter: ["common_cold", "hay_fever", "respiratory_infections"]
    },
    endemicDiseases: ["malaria", "dengue"],
    riskFactors: ["high_humidity", "stagnant_water", "mosquito_breeding"]
  },
  "751008": {
    pincode: "751008",
    state: "Odisha",
    district: "Bhubaneswar",
    commonDiseases: ["malaria", "dengue", "diarrhea", "seasonal_fever"],
    seasonalDiseases: {
      monsoon: ["malaria", "dengue", "cholera", "diarrhea"],
      summer: ["heat_stroke", "dehydration", "seasonal_fever"],
      winter: ["common_cold", "hay_fever", "respiratory_infections"]
    },
    endemicDiseases: ["malaria", "dengue"],
    riskFactors: ["high_humidity", "stagnant_water", "mosquito_breeding"]
  },
  "751009": {
    pincode: "751009",
    state: "Odisha",
    district: "Bhubaneswar",
    commonDiseases: ["malaria", "dengue", "diarrhea", "seasonal_fever"],
    seasonalDiseases: {
      monsoon: ["malaria", "dengue", "cholera", "diarrhea"],
      summer: ["heat_stroke", "dehydration", "seasonal_fever"],
      winter: ["common_cold", "hay_fever", "respiratory_infections"]
    },
    endemicDiseases: ["malaria", "dengue"],
    riskFactors: ["high_humidity", "stagnant_water", "mosquito_breeding"]
  },
  "751010": {
    pincode: "751010",
    state: "Odisha",
    district: "Bhubaneswar",
    commonDiseases: ["malaria", "dengue", "diarrhea", "seasonal_fever"],
    seasonalDiseases: {
      monsoon: ["malaria", "dengue", "cholera", "diarrhea"],
      summer: ["heat_stroke", "dehydration", "seasonal_fever"],
      winter: ["common_cold", "hay_fever", "respiratory_infections"]
    },
    endemicDiseases: ["malaria", "dengue"],
    riskFactors: ["high_humidity", "stagnant_water", "mosquito_breeding"]
  },
  "751011": {
    pincode: "751011",
    state: "Odisha",
    district: "Bhubaneswar",
    commonDiseases: ["malaria", "dengue", "diarrhea", "seasonal_fever"],
    seasonalDiseases: {
      monsoon: ["malaria", "dengue", "cholera", "diarrhea"],
      summer: ["heat_stroke", "dehydration", "seasonal_fever"],
      winter: ["common_cold", "hay_fever", "respiratory_infections"]
    },
    endemicDiseases: ["malaria", "dengue"],
    riskFactors: ["high_humidity", "stagnant_water", "mosquito_breeding"]
  },
  "751012": {
    pincode: "751012",
    state: "Odisha",
    district: "Bhubaneswar",
    commonDiseases: ["malaria", "dengue", "diarrhea", "seasonal_fever"],
    seasonalDiseases: {
      monsoon: ["malaria", "dengue", "cholera", "diarrhea"],
      summer: ["heat_stroke", "dehydration", "seasonal_fever"],
      winter: ["common_cold", "hay_fever", "respiratory_infections"]
    },
    endemicDiseases: ["malaria", "dengue"],
    riskFactors: ["high_humidity", "stagnant_water", "mosquito_breeding"]
  },
  "751013": {
    pincode: "751013",
    state: "Odisha",
    district: "Bhubaneswar",
    commonDiseases: ["malaria", "dengue", "diarrhea", "seasonal_fever"],
    seasonalDiseases: {
      monsoon: ["malaria", "dengue", "cholera", "diarrhea"],
      summer: ["heat_stroke", "dehydration", "seasonal_fever"],
      winter: ["common_cold", "hay_fever", "respiratory_infections"]
    },
    endemicDiseases: ["malaria", "dengue"],
    riskFactors: ["high_humidity", "stagnant_water", "mosquito_breeding"]
  },
  "751014": {
    pincode: "751014",
    state: "Odisha",
    district: "Bhubaneswar",
    commonDiseases: ["malaria", "dengue", "diarrhea", "seasonal_fever"],
    seasonalDiseases: {
      monsoon: ["malaria", "dengue", "cholera", "diarrhea"],
      summer: ["heat_stroke", "dehydration", "seasonal_fever"],
      winter: ["common_cold", "hay_fever", "respiratory_infections"]
    },
    endemicDiseases: ["malaria", "dengue"],
    riskFactors: ["high_humidity", "stagnant_water", "mosquito_breeding"]
  },
  "751015": {
    pincode: "751015",
    state: "Odisha",
    district: "Bhubaneswar",
    commonDiseases: ["malaria", "dengue", "diarrhea", "seasonal_fever"],
    seasonalDiseases: {
      monsoon: ["malaria", "dengue", "cholera", "diarrhea"],
      summer: ["heat_stroke", "dehydration", "seasonal_fever"],
      winter: ["common_cold", "hay_fever", "respiratory_infections"]
    },
    endemicDiseases: ["malaria", "dengue"],
    riskFactors: ["high_humidity", "stagnant_water", "mosquito_breeding"]
  },
  "751016": {
    pincode: "751016",
    state: "Odisha",
    district: "Bhubaneswar",
    commonDiseases: ["malaria", "dengue", "diarrhea", "seasonal_fever"],
    seasonalDiseases: {
      monsoon: ["malaria", "dengue", "cholera", "diarrhea"],
      summer: ["heat_stroke", "dehydration", "seasonal_fever"],
      winter: ["common_cold", "hay_fever", "respiratory_infections"]
    },
    endemicDiseases: ["malaria", "dengue"],
    riskFactors: ["high_humidity", "stagnant_water", "mosquito_breeding"]
  },
  "751017": {
    pincode: "751017",
    state: "Odisha",
    district: "Bhubaneswar",
    commonDiseases: ["malaria", "dengue", "diarrhea", "seasonal_fever"],
    seasonalDiseases: {
      monsoon: ["malaria", "dengue", "cholera", "diarrhea"],
      summer: ["heat_stroke", "dehydration", "seasonal_fever"],
      winter: ["common_cold", "hay_fever", "respiratory_infections"]
    },
    endemicDiseases: ["malaria", "dengue"],
    riskFactors: ["high_humidity", "stagnant_water", "mosquito_breeding"]
  },
  "751018": {
    pincode: "751018",
    state: "Odisha",
    district: "Bhubaneswar",
    commonDiseases: ["malaria", "dengue", "diarrhea", "seasonal_fever"],
    seasonalDiseases: {
      monsoon: ["malaria", "dengue", "cholera", "diarrhea"],
      summer: ["heat_stroke", "dehydration", "seasonal_fever"],
      winter: ["common_cold", "hay_fever", "respiratory_infections"]
    },
    endemicDiseases: ["malaria", "dengue"],
    riskFactors: ["high_humidity", "stagnant_water", "mosquito_breeding"]
  },
  "751019": {
    pincode: "751019",
    state: "Odisha",
    district: "Bhubaneswar",
    commonDiseases: ["malaria", "dengue", "diarrhea", "seasonal_fever"],
    seasonalDiseases: {
      monsoon: ["malaria", "dengue", "cholera", "diarrhea"],
      summer: ["heat_stroke", "dehydration", "seasonal_fever"],
      winter: ["common_cold", "hay_fever", "respiratory_infections"]
    },
    endemicDiseases: ["malaria", "dengue"],
    riskFactors: ["high_humidity", "stagnant_water", "mosquito_breeding"]
  },
  "751020": {
    pincode: "751020",
    state: "Odisha",
    district: "Bhubaneswar",
    commonDiseases: ["malaria", "dengue", "diarrhea", "seasonal_fever"],
    seasonalDiseases: {
      monsoon: ["malaria", "dengue", "cholera", "diarrhea"],
      summer: ["heat_stroke", "dehydration", "seasonal_fever"],
      winter: ["common_cold", "hay_fever", "respiratory_infections"]
    },
    endemicDiseases: ["malaria", "dengue"],
    riskFactors: ["high_humidity", "stagnant_water", "mosquito_breeding"]
  },
  "751021": {
    pincode: "751021",
    state: "Odisha",
    district: "Bhubaneswar",
    commonDiseases: ["malaria", "dengue", "diarrhea", "seasonal_fever"],
    seasonalDiseases: {
      monsoon: ["malaria", "dengue", "cholera", "diarrhea"],
      summer: ["heat_stroke", "dehydration", "seasonal_fever"],
      winter: ["common_cold", "hay_fever", "respiratory_infections"]
    },
    endemicDiseases: ["malaria", "dengue"],
    riskFactors: ["high_humidity", "stagnant_water", "mosquito_breeding"]
  },
  "751022": {
    pincode: "751022",
    state: "Odisha",
    district: "Bhubaneswar",
    commonDiseases: ["malaria", "dengue", "diarrhea", "seasonal_fever"],
    seasonalDiseases: {
      monsoon: ["malaria", "dengue", "cholera", "diarrhea"],
      summer: ["heat_stroke", "dehydration", "seasonal_fever"],
      winter: ["common_cold", "hay_fever", "respiratory_infections"]
    },
    endemicDiseases: ["malaria", "dengue"],
    riskFactors: ["high_humidity", "stagnant_water", "mosquito_breeding"]
  },
  "751023": {
    pincode: "751023",
    state: "Odisha",
    district: "Bhubaneswar",
    commonDiseases: ["malaria", "dengue", "diarrhea", "seasonal_fever"],
    seasonalDiseases: {
      monsoon: ["malaria", "dengue", "cholera", "diarrhea"],
      summer: ["heat_stroke", "dehydration", "seasonal_fever"],
      winter: ["common_cold", "hay_fever", "respiratory_infections"]
    },
    endemicDiseases: ["malaria", "dengue"],
    riskFactors: ["high_humidity", "stagnant_water", "mosquito_breeding"]
  },
  "751024": {
    pincode: "751024",
    state: "Odisha",
    district: "Bhubaneswar",
    commonDiseases: ["malaria", "dengue", "diarrhea", "seasonal_fever"],
    seasonalDiseases: {
      monsoon: ["malaria", "dengue", "cholera", "diarrhea"],
      summer: ["heat_stroke", "dehydration", "seasonal_fever"],
      winter: ["common_cold", "hay_fever", "respiratory_infections"]
    },
    endemicDiseases: ["malaria", "dengue"],
    riskFactors: ["high_humidity", "stagnant_water", "mosquito_breeding"]
  },
  "751025": {
    pincode: "751025",
    state: "Odisha",
    district: "Bhubaneswar",
    commonDiseases: ["malaria", "dengue", "diarrhea", "seasonal_fever"],
    seasonalDiseases: {
      monsoon: ["malaria", "dengue", "cholera", "diarrhea"],
      summer: ["heat_stroke", "dehydration", "seasonal_fever"],
      winter: ["common_cold", "hay_fever", "respiratory_infections"]
    },
    endemicDiseases: ["malaria", "dengue"],
    riskFactors: ["high_humidity", "stagnant_water", "mosquito_breeding"]
  },
  "751026": {
    pincode: "751026",
    state: "Odisha",
    district: "Bhubaneswar",
    commonDiseases: ["malaria", "dengue", "diarrhea", "seasonal_fever"],
    seasonalDiseases: {
      monsoon: ["malaria", "dengue", "cholera", "diarrhea"],
      summer: ["heat_stroke", "dehydration", "seasonal_fever"],
      winter: ["common_cold", "hay_fever", "respiratory_infections"]
    },
    endemicDiseases: ["malaria", "dengue"],
    riskFactors: ["high_humidity", "stagnant_water", "mosquito_breeding"]
  },
  "751027": {
    pincode: "751027",
    state: "Odisha",
    district: "Bhubaneswar",
    commonDiseases: ["malaria", "dengue", "diarrhea", "seasonal_fever"],
    seasonalDiseases: {
      monsoon: ["malaria", "dengue", "cholera", "diarrhea"],
      summer: ["heat_stroke", "dehydration", "seasonal_fever"],
      winter: ["common_cold", "hay_fever", "respiratory_infections"]
    },
    endemicDiseases: ["malaria", "dengue"],
    riskFactors: ["high_humidity", "stagnant_water", "mosquito_breeding"]
  },
  "751028": {
    pincode: "751028",
    state: "Odisha",
    district: "Bhubaneswar",
    commonDiseases: ["malaria", "dengue", "diarrhea", "seasonal_fever"],
    seasonalDiseases: {
      monsoon: ["malaria", "dengue", "cholera", "diarrhea"],
      summer: ["heat_stroke", "dehydration", "seasonal_fever"],
      winter: ["common_cold", "hay_fever", "respiratory_infections"]
    },
    endemicDiseases: ["malaria", "dengue"],
    riskFactors: ["high_humidity", "stagnant_water", "mosquito_breeding"]
  },
  "751029": {
    pincode: "751029",
    state: "Odisha",
    district: "Bhubaneswar",
    commonDiseases: ["malaria", "dengue", "diarrhea", "seasonal_fever"],
    seasonalDiseases: {
      monsoon: ["malaria", "dengue", "cholera", "diarrhea"],
      summer: ["heat_stroke", "dehydration", "seasonal_fever"],
      winter: ["common_cold", "hay_fever", "respiratory_infections"]
    },
    endemicDiseases: ["malaria", "dengue"],
    riskFactors: ["high_humidity", "stagnant_water", "mosquito_breeding"]
  },
  "751030": {
    pincode: "751030",
    state: "Odisha",
    district: "Bhubaneswar",
    commonDiseases: ["malaria", "dengue", "diarrhea", "seasonal_fever"],
    seasonalDiseases: {
      monsoon: ["malaria", "dengue", "cholera", "diarrhea"],
      summer: ["heat_stroke", "dehydration", "seasonal_fever"],
      winter: ["common_cold", "hay_fever", "respiratory_infections"]
    },
    endemicDiseases: ["malaria", "dengue"],
    riskFactors: ["high_humidity", "stagnant_water", "mosquito_breeding"]
  },
  // Delhi pincodes
  "110001": {
    pincode: "110001",
    state: "Delhi",
    district: "Central Delhi",
    commonDiseases: ["dengue", "seasonal_fever", "common_cold", "hay_fever"],
    seasonalDiseases: {
      monsoon: ["dengue", "chikungunya", "malaria"],
      summer: ["heat_stroke", "dehydration", "seasonal_fever"],
      winter: ["common_cold", "hay_fever", "respiratory_infections"]
    },
    endemicDiseases: ["dengue"],
    riskFactors: ["air_pollution", "urban_heat_island", "mosquito_breeding"]
  },
  // Kolkata pincodes
  "700001": {
    pincode: "700001",
    state: "West Bengal",
    district: "Kolkata",
    commonDiseases: ["cholera", "dengue", "diarrhea", "seasonal_fever"],
    seasonalDiseases: {
      monsoon: ["cholera", "dengue", "malaria", "diarrhea"],
      summer: ["heat_stroke", "dehydration", "seasonal_fever"],
      winter: ["common_cold", "respiratory_infections"]
    },
    endemicDiseases: ["cholera", "dengue"],
    riskFactors: ["water_contamination", "high_humidity", "poor_sanitation"]
  },
  // Jaipur pincodes
  "302001": {
    pincode: "302001",
    state: "Rajasthan",
    district: "Jaipur",
    commonDiseases: ["seasonal_fever", "common_cold", "dengue"],
    seasonalDiseases: {
      monsoon: ["dengue", "chikungunya", "malaria"],
      summer: ["heat_stroke", "dehydration", "seasonal_fever"],
      winter: ["common_cold", "seasonal_fever", "respiratory_infections"]
    },
    endemicDiseases: ["dengue"],
    riskFactors: ["extreme_heat", "dust_storms", "water_scarcity"]
  },
  // Bangalore pincodes
  "560001": {
    pincode: "560001",
    state: "Karnataka",
    district: "Bangalore",
    commonDiseases: ["hay_fever", "seasonal_fever", "common_cold"],
    seasonalDiseases: {
      monsoon: ["dengue", "malaria", "seasonal_fever"],
      summer: ["hay_fever", "seasonal_fever", "dehydration"],
      winter: ["common_cold", "hay_fever", "respiratory_infections"]
    },
    endemicDiseases: ["hay_fever"],
    riskFactors: ["pollen_exposure", "air_pollution", "seasonal_allergens"]
  }
};

// Function to get location-based disease data
export function getLocationDiseaseData(pincode: string): LocationDiseaseData | null {
  return locationDiseaseMapping[pincode] || null;
}

// Function to get current season
export function getCurrentSeason(): 'monsoon' | 'summer' | 'winter' {
  const month = new Date().getMonth() + 1; // 1-12
  
  if (month >= 6 && month <= 9) {
    return 'monsoon';
  } else if (month >= 3 && month <= 5) {
    return 'summer';
  } else {
    return 'winter';
  }
}

// Function to get seasonal diseases for a location
export function getSeasonalDiseases(pincode: string): string[] {
  const locationData = getLocationDiseaseData(pincode);
  if (!locationData) return [];
  
  const season = getCurrentSeason();
  return locationData.seasonalDiseases[season] || [];
}

// Function to get endemic diseases for a location
export function getEndemicDiseases(pincode: string): string[] {
  const locationData = getLocationDiseaseData(pincode);
  return locationData?.endemicDiseases || [];
}

// Function to get common diseases for a location
export function getCommonDiseases(pincode: string): string[] {
  const locationData = getLocationDiseaseData(pincode);
  return locationData?.commonDiseases || [];
}

// Function to get risk factors for a location
export function getLocationRiskFactors(pincode: string): string[] {
  const locationData = getLocationDiseaseData(pincode);
  return locationData?.riskFactors || [];
}

