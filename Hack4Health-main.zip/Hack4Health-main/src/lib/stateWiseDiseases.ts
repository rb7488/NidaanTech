/**
 * Indian State-wise Disease Data
 * Based on epidemiological data and health ministry reports
 */

export interface StateDiseaseData {
  state: string;
  districts: Record<string, DistrictDiseaseData>;
}

export interface DistrictDiseaseData {
  district: string;
  pincodes: string[];
  endemicDiseases: string[];
  seasonalDiseases: {
    monsoon: string[];
    winter: string[];
    summer: string[];
    postMonsoon: string[];
  };
  commonDiseases: string[];
  riskFactors: string[];
  healthAdvisories: string[];
  climateZone: 'tropical' | 'subtropical' | 'temperate' | 'arid' | 'coastal';
  waterQualityIssues: boolean;
  vectorBorneRisk: 'high' | 'medium' | 'low';
}

export const stateWiseDiseaseData: Record<string, StateDiseaseData> = {
  "odisha": {
    state: "Odisha",
    districts: {
      "khordha": {
        district: "Khordha",
        pincodes: ["751001", "751002", "751003", "751004", "751005", "751006", "751007", "751008", "751009", "751010"],
        endemicDiseases: ["malaria", "dengue", "chikungunya", "japanese_encephalitis"],
        seasonalDiseases: {
          monsoon: ["malaria", "dengue", "cholera", "diarrhea", "typhoid", "hepatitis_a", "leptospirosis"],
          winter: ["seasonal_fever", "common_cold", "pneumonia", "bronchitis"],
          summer: ["diarrhea", "typhoid", "heat_stroke", "dehydration"],
          postMonsoon: ["dengue", "chikungunya", "viral_fever"]
        },
        commonDiseases: ["common_cold", "diarrhea", "seasonal_fever", "gastroenteritis"],
        riskFactors: ["high_humidity", "stagnant_water", "poor_sanitation", "overcrowding"],
        healthAdvisories: [
          "Use mosquito nets during monsoon",
          "Ensure safe drinking water",
          "Maintain proper sanitation",
          "Report prolonged fever immediately"
        ],
        climateZone: "tropical",
        waterQualityIssues: true,
        vectorBorneRisk: "high"
      },
      "cuttack": {
        district: "Cuttack",
        pincodes: ["753001", "753002", "753003", "753004", "753005", "753006", "753007", "753008", "753009", "753010"],
        endemicDiseases: ["malaria", "dengue", "filariasis"],
        seasonalDiseases: {
          monsoon: ["malaria", "dengue", "cholera", "diarrhea", "typhoid"],
          winter: ["seasonal_fever", "common_cold", "respiratory_infections"],
          summer: ["diarrhea", "typhoid", "heat_related_illness"],
          postMonsoon: ["dengue", "chikungunya"]
        },
        commonDiseases: ["common_cold", "diarrhea", "seasonal_fever"],
        riskFactors: ["river_proximity", "flooding", "poor_drainage"],
        healthAdvisories: [
          "Avoid flood water contact",
          "Use ORS for diarrhea",
          "Maintain vector control measures"
        ],
        climateZone: "tropical",
        waterQualityIssues: true,
        vectorBorneRisk: "high"
      },
      "puri": {
        district: "Puri",
        pincodes: ["752001", "752002", "752003", "752004", "752005"],
        endemicDiseases: ["malaria", "dengue", "cholera"],
        seasonalDiseases: {
          monsoon: ["cholera", "diarrhea", "typhoid", "hepatitis_a"],
          winter: ["seasonal_fever", "common_cold"],
          summer: ["diarrhea", "heat_stroke", "dehydration"],
          postMonsoon: ["dengue", "viral_fever"]
        },
        commonDiseases: ["diarrhea", "common_cold", "gastroenteritis"],
        riskFactors: ["coastal_area", "high_tourist_influx", "water_contamination"],
        healthAdvisories: [
          "Drink only bottled/boiled water",
          "Avoid street food during festivals",
          "Maintain personal hygiene"
        ],
        climateZone: "coastal",
        waterQualityIssues: true,
        vectorBorneRisk: "medium"
      }
    }
  },
  "west_bengal": {
    state: "West Bengal",
    districts: {
      "kolkata": {
        district: "Kolkata",
        pincodes: ["700001", "700002", "700003", "700004", "700005", "700006", "700007", "700008", "700009", "700010"],
        endemicDiseases: ["dengue", "chikungunya", "malaria", "kala_azar"],
        seasonalDiseases: {
          monsoon: ["dengue", "malaria", "cholera", "diarrhea", "typhoid"],
          winter: ["seasonal_fever", "common_cold", "pneumonia"],
          summer: ["diarrhea", "typhoid", "heat_stroke"],
          postMonsoon: ["dengue", "chikungunya", "viral_fever"]
        },
        commonDiseases: ["common_cold", "diarrhea", "seasonal_fever"],
        riskFactors: ["urban_pollution", "overcrowding", "poor_waste_management"],
        healthAdvisories: [
          "Use air purifiers during pollution peaks",
          "Maintain vector control in urban areas",
          "Ensure proper waste disposal"
        ],
        climateZone: "subtropical",
        waterQualityIssues: true,
        vectorBorneRisk: "high"
      }
    }
  },
  "maharashtra": {
    state: "Maharashtra",
    districts: {
      "mumbai": {
        district: "Mumbai",
        pincodes: ["400001", "400002", "400003", "400004", "400005", "400006", "400007", "400008", "400009", "400010"],
        endemicDiseases: ["dengue", "chikungunya", "malaria"],
        seasonalDiseases: {
          monsoon: ["dengue", "malaria", "leptospirosis", "gastroenteritis"],
          winter: ["seasonal_fever", "common_cold", "respiratory_infections"],
          summer: ["heat_stroke", "dehydration", "food_poisoning"],
          postMonsoon: ["dengue", "chikungunya"]
        },
        commonDiseases: ["common_cold", "gastroenteritis", "respiratory_infections"],
        riskFactors: ["high_population_density", "slum_areas", "monsoon_flooding"],
        healthAdvisories: [
          "Avoid waterlogged areas during monsoon",
          "Use protective clothing in slum areas",
          "Maintain hydration during summer"
        ],
        climateZone: "coastal",
        waterQualityIssues: true,
        vectorBorneRisk: "high"
      }
    }
  },
  "kerala": {
    state: "Kerala",
    districts: {
      "thiruvananthapuram": {
        district: "Thiruvananthapuram",
        pincodes: ["695001", "695002", "695003", "695004", "695005"],
        endemicDiseases: ["dengue", "chikungunya", "zika", "nipah"],
        seasonalDiseases: {
          monsoon: ["dengue", "chikungunya", "leptospirosis", "hepatitis_a"],
          winter: ["seasonal_fever", "common_cold"],
          summer: ["heat_stroke", "dehydration"],
          postMonsoon: ["dengue", "viral_fever"]
        },
        commonDiseases: ["common_cold", "gastroenteritis", "seasonal_fever"],
        riskFactors: ["high_rainfall", "coconut_groves", "backwaters"],
        healthAdvisories: [
          "Monitor for Nipah virus symptoms",
          "Avoid contact with bats",
          "Use mosquito control measures"
        ],
        climateZone: "tropical",
        waterQualityIssues: false,
        vectorBorneRisk: "high"
      }
    }
  },
  "rajasthan": {
    state: "Rajasthan",
    districts: {
      "jaipur": {
        district: "Jaipur",
        pincodes: ["302001", "302002", "302003", "302004", "302005"],
        endemicDiseases: ["dengue", "chikungunya", "scrub_typhus"],
        seasonalDiseases: {
          monsoon: ["dengue", "chikungunya", "malaria", "scrub_typhus"],
          winter: ["seasonal_fever", "common_cold", "pneumonia"],
          summer: ["heat_stroke", "dehydration", "heat_exhaustion"],
          postMonsoon: ["dengue", "viral_fever"]
        },
        commonDiseases: ["common_cold", "seasonal_fever", "respiratory_infections"],
        riskFactors: ["extreme_heat", "dust_storms", "water_scarcity"],
        healthAdvisories: [
          "Stay hydrated during extreme heat",
          "Avoid outdoor activities during peak summer",
          "Use protective masks during dust storms"
        ],
        climateZone: "arid",
        waterQualityIssues: true,
        vectorBorneRisk: "medium"
      }
    }
  }
};

/**
 * Get disease data for a specific pincode
 */
export const getStateDiseaseData = (pincode: string): DistrictDiseaseData | null => {
  for (const stateData of Object.values(stateWiseDiseaseData)) {
    for (const districtData of Object.values(stateData.districts)) {
      if (districtData.pincodes.includes(pincode)) {
        return districtData;
      }
    }
  }
  return null;
};

/**
 * Get seasonal diseases for a pincode based on current season
 */
export const getSeasonalDiseasesForPincode = (
  pincode: string, 
  season: 'monsoon' | 'winter' | 'summer' | 'postMonsoon' = 'monsoon'
): string[] => {
  const data = getStateDiseaseData(pincode);
  return data?.seasonalDiseases[season] || [];
};

/**
 * Get endemic diseases for a pincode
 */
export const getEndemicDiseasesForPincode = (pincode: string): string[] => {
  const data = getStateDiseaseData(pincode);
  return data?.endemicDiseases || [];
};

/**
 * Get common diseases for a pincode
 */
export const getCommonDiseasesForPincode = (pincode: string): string[] => {
  const data = getStateDiseaseData(pincode);
  return data?.commonDiseases || [];
};

/**
 * Get risk factors for a pincode
 */
export const getRiskFactorsForPincode = (pincode: string): string[] => {
  const data = getStateDiseaseData(pincode);
  return data?.riskFactors || [];
};

/**
 * Get health advisories for a pincode
 */
export const getHealthAdvisoriesForPincode = (pincode: string): string[] => {
  const data = getStateDiseaseData(pincode);
  return data?.healthAdvisories || [];
};

/**
 * Get vector-borne disease risk level for a pincode
 */
export const getVectorBorneRisk = (pincode: string): 'high' | 'medium' | 'low' => {
  const data = getStateDiseaseData(pincode);
  return data?.vectorBorneRisk || 'low';
};

/**
 * Check if a pincode has water quality issues
 */
export const hasWaterQualityIssues = (pincode: string): boolean => {
  const data = getStateDiseaseData(pincode);
  return data?.waterQualityIssues || false;
};

/**
 * Get current season based on month (simplified)
 */
export const getCurrentSeason = (): 'monsoon' | 'winter' | 'summer' | 'postMonsoon' => {
  const month = new Date().getMonth() + 1; // 1-12
  
  if (month >= 6 && month <= 9) {
    return 'monsoon';
  } else if (month >= 10 && month <= 11) {
    return 'postMonsoon';
  } else if (month >= 12 || month <= 2) {
    return 'winter';
  } else {
    return 'summer';
  }
};

/**
 * Enhanced disease scoring based on state-wise data
 */
export const applyStateBasedScoring = (
  score: number,
  diseaseName: string,
  pincode: string
): number => {
  const data = getStateDiseaseData(pincode);
  if (!data) return score;

  let adjustedScore = score;
  const currentSeason = getCurrentSeason();

  // Endemic disease bonus (significantly increased for better location weighting)
  if (data.endemicDiseases.includes(diseaseName)) {
    adjustedScore += 25; // Increased from 15 to 25 for strong endemic disease detection
  }

  // Seasonal disease bonus (increased)
  if (data.seasonalDiseases[currentSeason].includes(diseaseName)) {
    adjustedScore += 12; // Increased from 8 to 12 for better seasonal detection
  }

  // Common disease bonus (small)
  if (data.commonDiseases.includes(diseaseName)) {
    adjustedScore += 5; // Increased from 3 to 5
  }

  // Vector-borne risk adjustment (increased)
  if (['malaria', 'dengue', 'chikungunya', 'zika', 'japanese_encephalitis'].includes(diseaseName)) {
    switch (data.vectorBorneRisk) {
      case 'high':
        adjustedScore += 10; // Increased from 4 to 10
        break;
      case 'medium':
        adjustedScore += 6; // Increased from 2 to 6
        break;
      case 'low':
        adjustedScore += 2; // Increased from 1 to 2
        break;
    }
  }

  // Water quality issues adjustment (increased)
  if (data.waterQualityIssues && ['cholera', 'diarrhea', 'typhoid', 'hepatitis_a'].includes(diseaseName)) {
    adjustedScore += 8; // Increased from 3 to 8
  }

  return adjustedScore;
};
