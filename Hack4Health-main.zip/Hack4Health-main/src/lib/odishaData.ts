export interface OdishaZone {
  name: string;
  districts: string[];
  pincodes: string[];
  population: number;
  healthCenters: number;
}

export const odishaZones: Record<string, OdishaZone> = {
  north: {
    name: "Northern Odisha",
    districts: ["Mayurbhanj", "Keonjhar", "Sundargarh", "Sambalpur"],
    pincodes: ["757001", "758001", "770001", "768001"],
    population: 4500000,
    healthCenters: 120
  },
  south: {
    name: "Southern Odisha", 
    districts: ["Gajapati", "Ganjam", "Kandhamal", "Kalahandi"],
    pincodes: ["761001", "760001", "762001", "766001"],
    population: 3800000,
    healthCenters: 95
  },
  east: {
    name: "Eastern Odisha",
    districts: ["Balasore", "Bhadrak", "Kendrapara", "Jagatsinghpur"],
    pincodes: ["756001", "756100", "754211", "754103"],
    population: 4200000,
    healthCenters: 110
  },
  west: {
    name: "Western Odisha",
    districts: ["Nuapada", "Bargarh", "Jharsuguda", "Debagarh"],
    pincodes: ["766105", "768028", "768201", "768108"],
    population: 3200000,
    healthCenters: 85
  },
  central: {
    name: "Central Odisha",
    districts: ["Khorda", "Puri", "Cuttack", "Nayagarh"],
    pincodes: ["751001", "752001", "753001", "752069"],
    population: 4800000,
    healthCenters: 130
  }
};

export interface VaccinationCenter {
  id: string;
  name: string;
  address: string;
  pincode: string;
  phone: string;
  timings: string;
  services: string[];
  zone: string;
  coordinates: {
    lat: number;
    lng: number;
  };
}

export const vaccinationCenters: VaccinationCenter[] = [
  {
    id: "vc001",
    name: "Puri District Hospital",
    address: "Puri, Odisha",
    pincode: "752001",
    phone: "+91-6752-222123",
    timings: "Mon-Fri: 9AM-5PM, Sat: 9AM-1PM",
    services: ["BCG", "OPV", "DPT", "Measles", "Hepatitis B"],
    zone: "central",
    coordinates: { lat: 19.8134, lng: 85.8315 }
  },
  {
    id: "vc002", 
    name: "Sambalpur Medical College",
    address: "Sambalpur, Odisha",
    pincode: "768001",
    phone: "+91-663-2400123",
    timings: "Mon-Fri: 8AM-4PM",
    services: ["All Vaccines", "Specialized Care"],
    zone: "north",
    coordinates: { lat: 21.4704, lng: 83.9707 }
  },
  {
    id: "vc003",
    name: "Berhampur PHC",
    address: "Berhampur, Ganjam",
    pincode: "760001", 
    phone: "+91-680-2201234",
    timings: "Mon-Sat: 9AM-3PM",
    services: ["BCG", "OPV", "DPT", "Measles"],
    zone: "south",
    coordinates: { lat: 19.3149, lng: 84.7941 }
  },
  {
    id: "vc004",
    name: "Balasore District Hospital",
    address: "Balasore, Odisha",
    pincode: "756001",
    phone: "+91-6782-260123",
    timings: "Mon-Fri: 9AM-5PM",
    services: ["BCG", "OPV", "DPT", "Measles", "Hepatitis B"],
    zone: "east",
    coordinates: { lat: 21.4944, lng: 86.9336 }
  },
  {
    id: "vc005",
    name: "Bargarh PHC",
    address: "Bargarh, Odisha", 
    pincode: "768028",
    phone: "+91-6646-220123",
    timings: "Mon-Sat: 9AM-3PM",
    services: ["BCG", "OPV", "DPT", "Measles"],
    zone: "west",
    coordinates: { lat: 21.3333, lng: 83.6167 }
  }
];

export interface ASHAWorker {
  id: string;
  name: string;
  phone: string;
  zone: string;
  pincodes: string[];
  languages: string[];
  experience: number;
}

export const ashaWorkers: ASHAWorker[] = [
  {
    id: "asha001",
    name: "Sunita Devi",
    phone: "+91-98765-43210",
    zone: "central",
    pincodes: ["751001", "751012"],
    languages: ["hindi", "odia", "english"],
    experience: 8
  },
  {
    id: "asha002", 
    name: "Lakshmi Patra",
    phone: "+91-98765-43211",
    zone: "north",
    pincodes: ["768001", "768002"],
    languages: ["odia", "sambalpuri", "hindi"],
    experience: 6
  },
  {
    id: "asha003",
    name: "Ranjana Mahanta",
    phone: "+91-98765-43212", 
    zone: "south",
    pincodes: ["760001", "760002"],
    languages: ["odia", "hindi", "english"],
    experience: 10
  },
  {
    id: "asha004",
    name: "Pramila Behera",
    phone: "+91-98765-43213",
    zone: "east", 
    pincodes: ["756001", "756002"],
    languages: ["odia", "hindi"],
    experience: 7
  },
  {
    id: "asha005",
    name: "Sushila Sahu",
    phone: "+91-98765-43214",
    zone: "west",
    pincodes: ["768028", "768029"],
    languages: ["sambalpuri", "odia", "hindi"],
    experience: 5
  }
];

export function getZoneByPincode(pincode: string): string | null {
  for (const [zoneKey, zone] of Object.entries(odishaZones)) {
    if (zone.pincodes.includes(pincode)) {
      return zoneKey;
    }
  }
  return null;
}

export function getNearbyCenters(pincode: string, limit: number = 3): VaccinationCenter[] {
  const userZone = getZoneByPincode(pincode);
  if (!userZone) return [];
  
  return vaccinationCenters
    .filter(center => center.zone === userZone)
    .slice(0, limit);
}

export function getASHAWorker(pincode: string): ASHAWorker | null {
  return ashaWorkers.find(worker => 
    worker.pincodes.includes(pincode)
  ) || null;
}
