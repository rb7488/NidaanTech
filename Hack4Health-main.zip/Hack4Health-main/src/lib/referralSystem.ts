// Clinical Decision Support and Referral Criteria System
// Based on WHO and ICMR Guidelines for Healthcare Facility Referrals

export interface ReferralCriteria {
  immediate: {
    symptoms: string[];
    whoGuideline: string;
    action: string;
    timeframe: string;
    facility: string[];
  };
  urgent: {
    symptoms: string[];
    whoGuideline: string;
    action: string;
    timeframe: string;
    facility: string[];
  };
  routine: {
    symptoms: string[];
    whoGuideline: string;
    action: string;
    timeframe: string;
    facility: string[];
  };
}

export interface FacilityType {
  name: string;
  level: 'primary' | 'secondary' | 'tertiary';
  capabilities: string[];
  staffing: string[];
  equipment: string[];
  location: string;
  contact: string;
  availability: '24/7' | 'business_hours' | 'emergency_only';
}

export interface ReferralDecision {
  urgency: 'immediate' | 'urgent' | 'routine' | 'home_care';
  facility: FacilityType | null;
  reason: string;
  symptoms: string[];
  whoGuideline: string;
  timeframe: string;
  instructions: string[];
  followUp: {
    required: boolean;
    timeframe: string;
    provider: string;
  };
  transportRequired: boolean;
  accompanimentNeeded: boolean;
}

// WHO-based Immediate Referral Triggers (Red Flags)
export const immediateReferralTriggers: Record<string, string[]> = {
  tuberculosis: [
    'hemoptysis', // Blood in sputum
    'severe_cough_with_blood',
    'difficulty_breathing',
    'chest_pain_severe',
    'high_fever_persistent'
  ],
  malaria: [
    'altered_consciousness',
    'seizures',
    'severe_anemia',
    'difficulty_breathing',
    'shock',
    'jaundice_severe',
    'bleeding',
    'hypoglycemia'
  ],
  dengue: [
    'severe_abdominal_pain',
    'persistent_vomiting',
    'bleeding',
    'difficulty_breathing',
    'severe_plasma_leakage',
    'organ_impairment',
    'shock'
  ],
  cholera: [
    'severe_dehydration',
    'shock',
    'altered_consciousness',
    'no_urine_output',
    'severe_electrolyte_imbalance'
  ],
  chikungunya: [
    'severe_joint_destruction',
    'neurological_complications',
    'myocarditis',
    'severe_skin_lesions'
  ],
  typhoid: [
    'severe_complications',
    'intestinal_bleeding',
    'perforation',
    'shock',
    'altered_consciousness'
  ],
  hepatitis_a: [
    'acute_liver_failure',
    'severe_jaundice',
    'altered_consciousness',
    'bleeding_tendency'
  ],
  respiratory: [
    'severe_difficulty_breathing',
    'cyanosis',
    'altered_consciousness',
    'severe_chest_pain',
    'high_fever_with_toxicity'
  ],
  gastroenteritis: [
    'severe_dehydration',
    'bloody_diarrhea_severe',
    'high_fever_with_toxicity',
    'severe_abdominal_pain'
  ]
};

// Urgent Referral Criteria (Within 24 hours)
export const urgentReferralTriggers: Record<string, string[]> = {
  tuberculosis: [
    'persistent_cough_2weeks',
    'weight_loss_significant',
    'night_sweats_severe',
    'contact_with_tb_patient'
  ],
  malaria: [
    'high_fever_with_chills',
    'severe_headache',
    'vomiting_persistent',
    'weakness_severe'
  ],
  dengue: [
    'high_fever_4days',
    'severe_headache',
    'pain_behind_eyes',
    'muscle_pain_severe',
    'skin_rash'
  ],
  cholera: [
    'profuse_watery_diarrhea',
    'vomiting_frequent',
    'dehydration_moderate'
  ],
  typhoid: [
    'fever_continuous_1week',
    'rose_spots',
    'severe_headache',
    'abdominal_pain'
  ],
  hepatitis_a: [
    'jaundice',
    'dark_urine',
    'pale_stools',
    'severe_fatigue'
  ]
};

// Facility Types and Capabilities
export const facilityTypes: Record<string, FacilityType> = {
  emergency_department: {
    name: 'Emergency Department',
    level: 'tertiary',
    capabilities: [
      'Emergency care',
      'ICU',
      'Laboratory services',
      'Radiology',
      'Blood bank',
      'Surgery',
      'Specialist consultations'
    ],
    staffing: ['Emergency physicians', 'Specialists', 'ICU staff', 'Nurses'],
    equipment: ['Ventilators', 'Monitors', 'Defibrillators', 'X-ray', 'CT scan'],
    location: 'District Hospital, Bhubaneswar',
    contact: '+91-674-2301234',
    availability: '24/7'
  },
  district_hospital: {
    name: 'District Hospital',
    level: 'secondary',
    capabilities: [
      'General medicine',
      'Surgery',
      'Obstetrics',
      'Pediatrics',
      'Laboratory',
      'X-ray',
      'Blood storage'
    ],
    staffing: ['Medical officers', 'Specialists', 'Staff nurses'],
    equipment: ['Basic monitors', 'X-ray machine', 'Laboratory equipment'],
    location: 'District Headquarters',
    contact: '+91-674-2345678',
    availability: '24/7'
  },
  chc: {
    name: 'Community Health Centre (CHC)',
    level: 'secondary',
    capabilities: [
      'General medicine',
      'Basic surgery',
      'Obstetrics',
      'Laboratory',
      'First aid'
    ],
    staffing: ['Medical officers', 'Staff nurses', 'Laboratory technician'],
    equipment: ['Basic equipment', 'Delivery table', 'Laboratory setup'],
    location: 'Block level',
    contact: '+91-674-2456789',
    availability: '24/7'
  },
  phc: {
    name: 'Primary Health Centre (PHC)',
    level: 'primary',
    capabilities: [
      'General medicine',
      'Immunization',
      'Maternal care',
      'Basic laboratory',
      'First aid'
    ],
    staffing: ['Medical officer', 'Staff nurse', 'ANM'],
    equipment: ['Basic medical kit', 'Delivery kit', 'Weighing scale'],
    location: 'Village cluster level',
    contact: '+91-674-2567890',
    availability: 'business_hours'
  },
  sub_center: {
    name: 'Sub Centre',
    level: 'primary',
    capabilities: [
      'Basic health services',
      'Immunization',
      'Health education',
      'First aid'
    ],
    staffing: ['ANM', 'ASHA worker'],
    equipment: ['Basic medical kit', 'Weighing scale'],
    location: 'Village level',
    contact: '+91-674-2678901',
    availability: 'business_hours'
  },
  asha_worker: {
    name: 'ASHA Worker',
    level: 'primary',
    capabilities: [
      'Health promotion',
      'Basic treatment',
      'Referral facilitation',
      'Community mobilization'
    ],
    staffing: ['ASHA worker'],
    equipment: ['Basic medical kit', 'Drug kit'],
    location: 'Village level',
    contact: '+91-98765-43210',
    availability: 'business_hours'
  }
};

// Clinical Decision Support Engine
export class ReferralDecisionEngine {
  
  /**
   * Make referral decision based on symptoms, disease, and patient profile
   */
  makeReferralDecision(
    primaryDisease: string,
    symptoms: string[],
    severity: 'mild' | 'moderate' | 'severe',
    userProfile: {
      age?: number;
      pregnancy?: boolean;
      comorbidities?: string[];
      location?: string;
    }
  ): ReferralDecision {
    
    // Check for immediate referral triggers
    const immediateSymptoms = this.checkImmediateReferral(primaryDisease, symptoms);
    if (immediateSymptoms.length > 0) {
      return this.createImmediateReferral(primaryDisease, immediateSymptoms, userProfile);
    }

    // Check for urgent referral triggers
    const urgentSymptoms = this.checkUrgentReferral(primaryDisease, symptoms);
    if (urgentSymptoms.length > 0 || severity === 'severe') {
      return this.createUrgentReferral(primaryDisease, urgentSymptoms, userProfile);
    }

    // Check for routine referral needs
    if (severity === 'moderate' || this.requiresRoutineReferral(userProfile)) {
      return this.createRoutineReferral(primaryDisease, symptoms, userProfile);
    }

    // Home care management
    return this.createHomeCareRecommendation(primaryDisease, symptoms, userProfile);
  }

  /**
   * Check for immediate referral triggers
   */
  private checkImmediateReferral(disease: string, symptoms: string[]): string[] {
    const triggers = immediateReferralTriggers[disease] || [];
    return symptoms.filter(symptom => 
      triggers.some(trigger => 
        symptom.toLowerCase().includes(trigger.toLowerCase()) ||
        trigger.toLowerCase().includes(symptom.toLowerCase())
      )
    );
  }

  /**
   * Check for urgent referral triggers
   */
  private checkUrgentReferral(disease: string, symptoms: string[]): string[] {
    const triggers = urgentReferralTriggers[disease] || [];
    return symptoms.filter(symptom => 
      triggers.some(trigger => 
        symptom.toLowerCase().includes(trigger.toLowerCase()) ||
        trigger.toLowerCase().includes(symptom.toLowerCase())
      )
    );
  }

  /**
   * Create immediate referral decision
   */
  private createImmediateReferral(
    disease: string, 
    symptoms: string[], 
    userProfile: any
  ): ReferralDecision {
    return {
      urgency: 'immediate',
      facility: facilityTypes.emergency_department,
      reason: `Immediate medical attention required due to severe symptoms: ${symptoms.join(', ')}`,
      symptoms,
      whoGuideline: this.getWHOGuideline(disease, 'immediate'),
      timeframe: 'Within 1 hour',
      instructions: [
        'Call emergency services immediately',
        'Do not delay seeking medical care',
        'Accompany patient to hospital',
        'Bring all medications and medical records',
        'Monitor vital signs during transport'
      ],
      followUp: {
        required: true,
        timeframe: 'As directed by emergency physician',
        provider: 'Emergency department'
      },
      transportRequired: true,
      accompanimentNeeded: true
    };
  }

  /**
   * Create urgent referral decision
   */
  private createUrgentReferral(
    disease: string, 
    symptoms: string[], 
    userProfile: any
  ): ReferralDecision {
    const facility = this.selectAppropriateUrgentFacility(userProfile);
    
    return {
      urgency: 'urgent',
      facility,
      reason: `Medical evaluation needed within 24 hours due to: ${symptoms.join(', ')}`,
      symptoms,
      whoGuideline: this.getWHOGuideline(disease, 'urgent'),
      timeframe: 'Within 24 hours',
      instructions: [
        'Visit healthcare facility within 24 hours',
        'Monitor symptoms closely',
        'Seek immediate care if symptoms worsen',
        'Bring complete symptom history',
        'Follow medication instructions carefully'
      ],
      followUp: {
        required: true,
        timeframe: 'As advised by healthcare provider',
        provider: facility.name
      },
      transportRequired: facility.level === 'tertiary',
      accompanimentNeeded: userProfile.age < 18 || userProfile.age > 65 || userProfile.pregnancy
    };
  }

  /**
   * Create routine referral decision
   */
  private createRoutineReferral(
    disease: string, 
    symptoms: string[], 
    userProfile: any
  ): ReferralDecision {
    const facility = this.selectAppropriateRoutineFacility(userProfile);
    
    return {
      urgency: 'routine',
      facility,
      reason: `Medical consultation recommended for proper diagnosis and treatment`,
      symptoms,
      whoGuideline: this.getWHOGuideline(disease, 'routine'),
      timeframe: 'Within 1 week',
      instructions: [
        'Schedule appointment with healthcare provider',
        'Continue monitoring symptoms',
        'Maintain symptom diary',
        'Follow home care recommendations',
        'Return if symptoms worsen'
      ],
      followUp: {
        required: true,
        timeframe: 'Within 2 weeks',
        provider: facility.name
      },
      transportRequired: false,
      accompanimentNeeded: userProfile.age < 16 || userProfile.pregnancy
    };
  }

  /**
   * Create home care recommendation
   */
  private createHomeCareRecommendation(
    disease: string, 
    symptoms: string[], 
    userProfile: any
  ): ReferralDecision {
    return {
      urgency: 'home_care',
      facility: facilityTypes.asha_worker,
      reason: 'Mild symptoms can be managed with home care and monitoring',
      symptoms,
      whoGuideline: this.getWHOGuideline(disease, 'home_care'),
      timeframe: 'Monitor for 48-72 hours',
      instructions: [
        'Follow home care recommendations',
        'Monitor symptoms daily',
        'Maintain adequate hydration',
        'Get plenty of rest',
        'Contact ASHA worker if symptoms worsen',
        'Seek medical care if no improvement in 3 days'
      ],
      followUp: {
        required: true,
        timeframe: 'Within 3 days if no improvement',
        provider: 'ASHA Worker or PHC'
      },
      transportRequired: false,
      accompanimentNeeded: false
    };
  }

  /**
   * Select appropriate facility for urgent care
   */
  private selectAppropriateUrgentFacility(userProfile: any): FacilityType {
    // High-risk patients go to district hospital
    if (userProfile.age < 2 || userProfile.age > 65 || 
        userProfile.pregnancy || userProfile.comorbidities?.length > 0) {
      return facilityTypes.district_hospital;
    }
    
    // Others can go to CHC
    return facilityTypes.chc;
  }

  /**
   * Select appropriate facility for routine care
   */
  private selectAppropriateRoutineFacility(userProfile: any): FacilityType {
    // Pregnancy and pediatric cases go to CHC
    if (userProfile.pregnancy || userProfile.age < 16) {
      return facilityTypes.chc;
    }
    
    // Others can start at PHC
    return facilityTypes.phc;
  }

  /**
   * Check if routine referral is required based on profile
   */
  private requiresRoutineReferral(userProfile: any): boolean {
    // Age-based criteria
    if (userProfile.age < 2 || userProfile.age > 65) {
      return true;
    }
    
    // Pregnancy
    if (userProfile.pregnancy) {
      return true;
    }
    
    // Comorbidities
    if (userProfile.comorbidities && userProfile.comorbidities.length > 0) {
      return true;
    }
    
    return false;
  }

  /**
   * Get WHO guideline reference for referral decision
   */
  private getWHOGuideline(disease: string, urgency: string): string {
    const guidelines: Record<string, Record<string, string>> = {
      tuberculosis: {
        immediate: 'WHO TB Guidelines - Emergency Management',
        urgent: 'WHO TB Screening and Diagnosis Guidelines',
        routine: 'WHO TB Community Care Guidelines',
        home_care: 'WHO TB Prevention Guidelines'
      },
      malaria: {
        immediate: 'WHO Severe Malaria Management Guidelines',
        urgent: 'WHO Malaria Diagnosis Guidelines',
        routine: 'WHO Malaria Case Management',
        home_care: 'WHO Malaria Prevention Guidelines'
      },
      dengue: {
        immediate: 'WHO Dengue Severe Case Management',
        urgent: 'WHO Dengue Clinical Management',
        routine: 'WHO Dengue Surveillance Guidelines',
        home_care: 'WHO Dengue Prevention Guidelines'
      },
      cholera: {
        immediate: 'WHO Cholera Emergency Response',
        urgent: 'WHO Cholera Case Management',
        routine: 'WHO Cholera Treatment Guidelines',
        home_care: 'WHO Cholera Prevention Guidelines'
      }
    };

    return guidelines[disease]?.[urgency] || 'WHO General Clinical Guidelines';
  }

  /**
   * Get facility recommendations based on location
   */
  getFacilityRecommendations(location: string): FacilityType[] {
    // In a real implementation, this would query a database of facilities
    // For now, return standard facility hierarchy
    return [
      facilityTypes.asha_worker,
      facilityTypes.sub_center,
      facilityTypes.phc,
      facilityTypes.chc,
      facilityTypes.district_hospital,
      facilityTypes.emergency_department
    ];
  }

  /**
   * Calculate transport time and cost
   */
  calculateTransportRequirements(
    fromLocation: string,
    facility: FacilityType,
    urgency: 'immediate' | 'urgent' | 'routine'
  ): {
    estimatedTime: string;
    transportMode: string;
    estimatedCost: string;
    instructions: string[];
  } {
    if (urgency === 'immediate') {
      return {
        estimatedTime: '15-30 minutes',
        transportMode: 'Ambulance (108)',
        estimatedCost: 'Free',
        instructions: [
          'Call 108 for free ambulance service',
          'Have patient ready for transport',
          'Accompany patient to hospital',
          'Bring identification and medical records'
        ]
      };
    }

    if (urgency === 'urgent') {
      return {
        estimatedTime: '30-60 minutes',
        transportMode: 'Private vehicle or auto-rickshaw',
        estimatedCost: '₹50-200',
        instructions: [
          'Arrange private transport if available',
          'Use public transport if necessary',
          'Ensure patient comfort during journey',
          'Monitor symptoms during transport'
        ]
      };
    }

    return {
      estimatedTime: '1-2 hours',
      transportMode: 'Public transport or walking',
      estimatedCost: '₹10-50',
      instructions: [
        'Schedule appointment in advance',
        'Use convenient transport method',
        'Bring symptom diary and questions',
        'Allow extra time for waiting'
      ]
    };
  }
}

// Export singleton instance
export const referralDecisionEngine = new ReferralDecisionEngine();

// Export referral criteria for external use
export const referralCriteria: ReferralCriteria = {
  immediate: {
    symptoms: Object.values(immediateReferralTriggers).flat(),
    whoGuideline: 'WHO Emergency Care Guidelines',
    action: 'Emergency referral within 1 hour',
    timeframe: 'Immediate',
    facility: ['Emergency Department', 'District Hospital']
  },
  urgent: {
    symptoms: Object.values(urgentReferralTriggers).flat(),
    whoGuideline: 'WHO Clinical Management Guidelines',
    action: 'Medical evaluation within 24 hours',
    timeframe: 'Within 24 hours',
    facility: ['CHC', 'District Hospital']
  },
  routine: {
    symptoms: ['mild_fever', 'minor_symptoms', 'follow_up_needed'],
    whoGuideline: 'WHO Primary Care Guidelines',
    action: 'Routine medical consultation',
    timeframe: 'Within 1 week',
    facility: ['PHC', 'CHC', 'ASHA Worker']
  }
};
