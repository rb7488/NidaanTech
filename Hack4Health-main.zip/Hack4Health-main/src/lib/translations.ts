export interface Translation {
  navigation: {
    home: string;
    vaccines: string;
    symptoms: string;
    alerts: string;
    profile: string;
  };
  buttons: {
    checkSymptoms: string;
    viewReminders: string;
    emergencyContact: string;
    shareWhatsApp: string;
    sendSMS: string;
    speakNow: string;
    stopSpeaking: string;
    selectLanguage: string;
    toggleTheme: string;
    listening: string;
    voiceNotSupported: string;
    microphonePermissionDenied: string;
  };
    labels: {
      enterSymptoms: string;
      selectLanguage: string;
      currentLocation: string;
      pincode: string;
      phoneNumber: string;
      name: string;
      dateOfBirth: string;
      familyMembers: string;
      vaccinationSchedule: string;
      dueVaccines: string;
      nextDueDate: string;
      vaccinationCenter: string;
      outbreakAlerts: string;
      severity: string;
      recommendation: string;
      homeRemedies: string;
      nearestClinic: string;
      ashaWorker: string;
      malaria: string;
      dengue: string;
      cholera: string;
      diarrhea: string;
      unknown: string;
      monitorSymptoms: string;
      takeMedications: string;
      monitorDehydration: string;
      monitorComplications: string;
      seekCare: string;
      followUpQuestions: string;
      illnessDuration: string;
      daysSinceSymptoms: string;
      whyImportant: string;
      durationExplanation: string;
    };
  severity: {
    mild: string;
    moderate: string;
    severe: string;
  };
  common: {
    loading: string;
    error: string;
    success: string;
    cancel: string;
    save: string;
    edit: string;
    delete: string;
    add: string;
    search: string;
    filter: string;
    sort: string;
    refresh: string;
    offline: string;
    online: string;
  };
  messages: {
    welcomeMessage: string;
    symptomCheckComplete: string;
    vaccinationReminder: string;
    outbreakAlert: string;
    emergencyContacted: string;
    dataSaved: string;
    networkError: string;
  };
  results: {
    recommendations: {
      mild: string;
      moderate: string;
      severe: string;
    };
    homeRemedies: {
      rest: string;
      hydration: string;
      monitorTemperature: string;
      lightMeals: string;
      avoidExertion: string;
      monitorVitalSigns: string;
    };
    clinics: {
      puriPHC: string;
      puriDistrictHospital: string;
      puriEmergency: string;
    };
    ashaWorkers: {
      available: string;
      willContact: string;
      emergencyInitiated: string;
    };
    outbreakAlerts: {
      dengue: {
        recommendation: string;
        symptoms: string[];
        prevention: string[];
      };
      malaria: {
        recommendation: string;
        symptoms: string[];
        prevention: string[];
      };
    };
    healthTips: {
      monsoon: {
        title: string;
        content: string;
      };
      vaccination: {
        title: string;
        content: string;
      };
      hygiene: {
        title: string;
        content: string;
      };
      weatherAdvice: string;
    };
  };
}

export const translations: Record<string, Translation> = {
  english: {
    navigation: {
      home: "Home",
      vaccines: "Vaccines",
      symptoms: "Symptoms",
      alerts: "Alerts",
      profile: "Profile"
    },
    buttons: {
      checkSymptoms: "Check Symptoms",
      viewReminders: "View Reminders",
      emergencyContact: "Emergency Contact",
      shareWhatsApp: "Share via WhatsApp",
      sendSMS: "Send SMS",
      speakNow: "Speak Now",
      stopSpeaking: "Stop Speaking",
      selectLanguage: "Select Language",
      toggleTheme: "Toggle Theme",
      listening: "Listening...",
      voiceNotSupported: "Voice input not supported",
      microphonePermissionDenied: "Microphone permission denied"
    },
    labels: {
      enterSymptoms: "Enter symptoms",
      selectLanguage: "Select language",
      currentLocation: "Current location",
      pincode: "Pincode",
      phoneNumber: "Phone Number",
      name: "Name",
      dateOfBirth: "Date of Birth",
      familyMembers: "Family Members",
      vaccinationSchedule: "Vaccination Schedule",
      dueVaccines: "Due Vaccines",
      nextDueDate: "Next Due Date",
      vaccinationCenter: "Vaccination Center",
      outbreakAlerts: "Outbreak Alerts",
      severity: "Severity",
      recommendation: "Recommendation",
      homeRemedies: "Home Remedies",
      nearestClinic: "Nearest Clinic",
      ashaWorker: "ASHA Worker",
      malaria: "Malaria",
      dengue: "Dengue",
      cholera: "Cholera",
      diarrhea: "Acute Diarrhea",
      unknown: "Unknown Condition",
      monitorSymptoms: "Monitor symptoms",
      takeMedications: "Take prescribed medications",
      monitorDehydration: "Monitor for dehydration signs",
      monitorComplications: "Monitor for complications due to existing conditions",
      seekCare: "Seek care if symptoms worsen",
      followUpQuestions: "Follow-up Questions",
      illnessDuration: "Illness Duration",
      daysSinceSymptoms: "How many days have you been experiencing these symptoms?",
      whyImportant: "Why is this important?",
      durationExplanation: "The duration of symptoms helps us determine the severity and appropriate treatment. Some conditions become more serious over time, while others may resolve naturally."
    },
    severity: {
      mild: "Mild",
      moderate: "Moderate",
      severe: "Severe"
    },
    common: {
      loading: "Loading...",
      error: "Error",
      success: "Success",
      cancel: "Cancel",
      save: "Save",
      edit: "Edit",
      delete: "Delete",
      add: "Add",
      search: "Search",
      filter: "Filter",
      sort: "Sort",
      refresh: "Refresh",
      offline: "Offline",
      online: "Online"
    },
    messages: {
      welcomeMessage: "Welcome to Nidaan - Your Health Companion",
      symptomCheckComplete: "Symptom check completed",
      vaccinationReminder: "Vaccination reminder set",
      outbreakAlert: "New outbreak alert in your area",
      emergencyContacted: "Emergency contact has been notified",
      dataSaved: "Data saved successfully",
      networkError: "Network error. Please check your connection."
    },
    results: {
      recommendations: {
        mild: "Monitor symptoms at home. Rest and stay hydrated.",
        moderate: "Visit nearby clinic within 24 hours for proper diagnosis.",
        severe: "Seek immediate medical attention. Contact emergency services if needed."
      },
      homeRemedies: {
        rest: "Rest",
        hydration: "Hydration",
        monitorTemperature: "Monitor temperature",
        lightMeals: "Light meals",
        avoidExertion: "Avoid exertion",
        monitorVitalSigns: "Monitor vital signs"
      },
      clinics: {
        puriPHC: "Puri PHC - 2.5km away",
        puriDistrictHospital: "Puri District Hospital - 2.5km away",
        puriEmergency: "Puri District Hospital - Emergency Department"
      },
      ashaWorkers: {
        available: "Sunita Devi (+91-98765-43210) - Available for consultation",
        willContact: "Sunita Devi (+91-98765-43210) - Will contact you within 2 hours",
        emergencyInitiated: "Sunita Devi (+91-98765-43210) - Emergency contact initiated"
      },
      outbreakAlerts: {
        dengue: {
          recommendation: "Use mosquito nets, eliminate standing water, wear protective clothing",
          symptoms: ["High fever", "Severe headache", "Pain behind eyes", "Muscle and joint pain"],
          prevention: ["Use mosquito repellent", "Wear long sleeves", "Eliminate standing water", "Use bed nets"]
        },
        malaria: {
          recommendation: "Take preventive measures, use mosquito nets",
          symptoms: ["Fever", "Chills", "Sweating", "Headache"],
          prevention: ["Use mosquito nets", "Apply repellent", "Wear protective clothing"]
        }
      },
      healthTips: {
        monsoon: {
          title: "Monsoon Health Tips",
          content: "During monsoon, avoid street food and drink only boiled water to prevent waterborne diseases."
        },
        vaccination: {
          title: "Vaccination Reminder",
          content: "Keep your vaccination schedule updated. Missing vaccines can lead to serious health complications."
        },
        hygiene: {
          title: "Hand Hygiene",
          content: "Wash hands frequently with soap and water, especially before eating and after using the toilet."
        },
        weatherAdvice: "High humidity and standing water increase disease risk. Use mosquito nets and avoid stagnant water."
      }
    }
  },
  hindi: {
    navigation: {
      home: "होम",
      vaccines: "टीके",
      symptoms: "लक्षण",
      alerts: "अलर्ट",
      profile: "प्रोफाइल"
    },
    buttons: {
      checkSymptoms: "लक्षण जांचें",
      viewReminders: "रिमाइंडर देखें",
      emergencyContact: "आपातकालीन संपर्क",
      shareWhatsApp: "WhatsApp पर साझा करें",
      sendSMS: "SMS भेजें",
      speakNow: "अब बोलें",
      stopSpeaking: "बोलना बंद करें",
      selectLanguage: "भाषा चुनें",
      toggleTheme: "थीम बदलें",
      listening: "सुन रहे हैं...",
      voiceNotSupported: "आवाज इनपुट समर्थित नहीं है",
      microphonePermissionDenied: "माइक्रोफोन अनुमति अस्वीकृत"
    },
    labels: {
      enterSymptoms: "लक्षण दर्ज करें",
      selectLanguage: "भाषा चुनें",
      currentLocation: "वर्तमान स्थान",
      pincode: "पिनकोड",
      phoneNumber: "फोन नंबर",
      name: "नाम",
      dateOfBirth: "जन्म तिथि",
      familyMembers: "परिवार के सदस्य",
      vaccinationSchedule: "टीकाकरण कार्यक्रम",
      dueVaccines: "देय टीके",
      nextDueDate: "अगली देय तिथि",
      vaccinationCenter: "टीकाकरण केंद्र",
      outbreakAlerts: "प्रकोप अलर्ट",
      severity: "गंभीरता",
      recommendation: "सिफारिश",
      homeRemedies: "घरेलू उपचार",
      nearestClinic: "निकटतम क्लिनिक",
      ashaWorker: "आशा कार्यकर्ता",
      malaria: "मलेरिया",
      dengue: "डेंगू",
      cholera: "हैजा",
      diarrhea: "तीव्र दस्त",
      unknown: "अज्ञात स्थिति",
      monitorSymptoms: "लक्षणों की निगरानी करें",
      takeMedications: "निर्धारित दवाएं लें",
      monitorDehydration: "निर्जलीकरण के लक्षणों की निगरानी करें",
      monitorComplications: "मौजूदा स्थितियों के कारण जटिलताओं की निगरानी करें",
      seekCare: "लक्षण बिगड़ने पर देखभाल लें",
      followUpQuestions: "अतिरिक्त प्रश्न",
      illnessDuration: "बीमारी की अवधि",
      daysSinceSymptoms: "आपको ये लक्षण कितने दिनों से हैं?",
      whyImportant: "यह क्यों महत्वपूर्ण है?",
      durationExplanation: "लक्षणों की अवधि हमें गंभीरता और उपयुक्त उपचार निर्धारित करने में मदद करती है। कुछ स्थितियां समय के साथ गंभीर हो जाती हैं, जबकि कुछ प्राकृतिक रूप से ठीक हो जाती हैं।"
    },
    severity: {
      mild: "हल्का",
      moderate: "मध्यम",
      severe: "गंभीर"
    },
    common: {
      loading: "लोड हो रहा है...",
      error: "त्रुटि",
      success: "सफलता",
      cancel: "रद्द करें",
      save: "सहेजें",
      edit: "संपादित करें",
      delete: "हटाएं",
      add: "जोड़ें",
      search: "खोजें",
      filter: "फिल्टर",
      sort: "क्रमबद्ध करें",
      refresh: "रिफ्रेश करें",
      offline: "ऑफलाइन",
      online: "ऑनलाइन"
    },
    messages: {
      welcomeMessage: "निदान में आपका स्वागत है - आपका स्वास्थ्य साथी",
      symptomCheckComplete: "लक्षण जांच पूरी हुई",
      vaccinationReminder: "टीकाकरण रिमाइंडर सेट किया गया",
      outbreakAlert: "आपके क्षेत्र में नया प्रकोप अलर्ट",
      emergencyContacted: "आपातकालीन संपर्क को सूचित किया गया",
      dataSaved: "डेटा सफलतापूर्वक सहेजा गया",
      networkError: "नेटवर्क त्रुटि। कृपया अपना कनेक्शन जांचें।"
    },
    results: {
      recommendations: {
        mild: "घर पर लक्षणों की निगरानी करें। आराम करें और हाइड्रेटेड रहें।",
        moderate: "उचित निदान के लिए 24 घंटे के भीतर निकटतम क्लिनिक जाएं।",
        severe: "तुरंत चिकित्सा सहायता लें। आवश्यकता होने पर आपातकालीन सेवाओं से संपर्क करें।"
      },
      homeRemedies: {
        rest: "आराम",
        hydration: "हाइड्रेशन",
        monitorTemperature: "तापमान की निगरानी",
        lightMeals: "हल्का भोजन",
        avoidExertion: "मेहनत से बचें",
        monitorVitalSigns: "महत्वपूर्ण संकेतों की निगरानी"
      },
      clinics: {
        puriPHC: "पुरी PHC - 2.5 किमी दूर",
        puriDistrictHospital: "पुरी जिला अस्पताल - 2.5 किमी दूर",
        puriEmergency: "पुरी जिला अस्पताल - आपातकालीन विभाग"
      },
      ashaWorkers: {
        available: "सुनीता देवी (+91-98765-43210) - परामर्श के लिए उपलब्ध",
        willContact: "सुनीता देवी (+91-98765-43210) - 2 घंटे के भीतर संपर्क करेंगी",
        emergencyInitiated: "सुनीता देवी (+91-98765-43210) - आपातकालीन संपर्क शुरू किया गया"
      },
      outbreakAlerts: {
        dengue: {
          recommendation: "मच्छरदानी का उपयोग करें, खड़े पानी को खत्म करें, सुरक्षात्मक कपड़े पहनें",
          symptoms: ["तेज बुखार", "गंभीर सिरदर्द", "आंखों के पीछे दर्द", "मांसपेशियों और जोड़ों में दर्द"],
          prevention: ["मच्छर रोधी का उपयोग करें", "लंबी बाजू के कपड़े पहनें", "खड़े पानी को खत्म करें", "बेड नेट का उपयोग करें"]
        },
        malaria: {
          recommendation: "निवारक उपाय अपनाएं, मच्छरदानी का उपयोग करें",
          symptoms: ["बुखार", "ठंड लगना", "पसीना आना", "सिरदर्द"],
          prevention: ["मच्छरदानी का उपयोग करें", "रिपेलेंट लगाएं", "सुरक्षात्मक कपड़े पहनें"]
        }
      },
      healthTips: {
        monsoon: {
          title: "मानसून स्वास्थ्य सुझाव",
          content: "मानसून के दौरान, जलजनित बीमारियों को रोकने के लिए सड़क किनारे के भोजन से बचें और केवल उबला हुआ पानी पिएं।"
        },
        vaccination: {
          title: "टीकाकरण रिमाइंडर",
          content: "अपने टीकाकरण कार्यक्रम को अपडेट रखें। टीकों को छोड़ना गंभीर स्वास्थ्य जटिलताओं का कारण बन सकता है।"
        },
        hygiene: {
          title: "हाथ की स्वच्छता",
          content: "खाने से पहले और शौचालय का उपयोग करने के बाद विशेष रूप से साबुन और पानी से हाथों को बार-बार धोएं।"
        },
        weatherAdvice: "उच्च आर्द्रता और खड़ा पानी बीमारी के जोखिम को बढ़ाता है। मच्छरदानी का उपयोग करें और स्थिर पानी से बचें।"
      }
    }
  },
  odia: {
    navigation: {
      home: "ଘର",
      vaccines: "ଟିକା",
      symptoms: "ଲକ୍ଷଣ",
      alerts: "ଚେତାବନୀ",
      profile: "ପ୍ରୋଫାଇଲ"
    },
    buttons: {
      checkSymptoms: "ଲକ୍ଷଣ ଯାଞ୍ଚ କରନ୍ତୁ",
      viewReminders: "ସ୍ମାରକ ଦେଖନ୍ତୁ",
      emergencyContact: "ଜରୁରୀ ସମ୍ପର୍କ",
      shareWhatsApp: "WhatsApp ରେ ଅଂଶୀଦାର କରନ୍ତୁ",
      sendSMS: "SMS ପଠାନ୍ତୁ",
      speakNow: "ଏବେ କହନ୍ତୁ",
      stopSpeaking: "କହିବା ବନ୍ଦ କରନ୍ତୁ",
      selectLanguage: "ଭାଷା ବାଛନ୍ତୁ",
      toggleTheme: "ଥିମ୍ ବଦଳାନ୍ତୁ",
      listening: "ଶୁଣୁଛି...",
      voiceNotSupported: "ଭଏସ୍ ଇନପୁଟ୍ ସମର୍ଥିତ ନୁହେଁ",
      microphonePermissionDenied: "ମାଇକ୍ରୋଫୋନ୍ ଅନୁମତି ପ୍ରତ୍ୟାଖ୍ୟାନ"
    },
    labels: {
      enterSymptoms: "ଲକ୍ଷଣ ପ୍ରବେଶ କରନ୍ତୁ",
      selectLanguage: "ଭାଷା ବାଛନ୍ତୁ",
      currentLocation: "ବର୍ତ୍ତମାନ ସ୍ଥାନ",
      pincode: "ପିନକୋଡ୍",
      phoneNumber: "ଫୋନ୍ ନମ୍ବର",
      name: "ନାମ",
      dateOfBirth: "ଜନ୍ମ ତାରିଖ",
      familyMembers: "ପରିବାର ସଦସ୍ୟ",
      vaccinationSchedule: "ଟିକାକରଣ କାର୍ଯ୍ୟକ୍ରମ",
      dueVaccines: "ଦେୟ ଟିକା",
      nextDueDate: "ପରବର୍ତ୍ତୀ ଦେୟ ତାରିଖ",
      vaccinationCenter: "ଟିକାକରଣ କେନ୍ଦ୍ର",
      outbreakAlerts: "ପ୍ରକୋପ ଚେତାବନୀ",
      severity: "ଗୁରୁତ୍ୱ",
      recommendation: "ପରାମର୍ଶ",
      homeRemedies: "ଘରୋଇ ଉପଚାର",
      nearestClinic: "ନିକଟତମ କ୍ଲିନିକ୍",
      ashaWorker: "ଆଶା କର୍ମୀ",
      malaria: "ମ୍ୟାଲେରିଆ",
      dengue: "ଡେଙ୍ଗୁ",
      cholera: "କଲେରା",
      diarrhea: "ତୀବ୍ର ତରଳ ଝାଡ଼ା",
      unknown: "ଅଜ୍ଞାତ ଅବସ୍ଥା",
      monitorSymptoms: "ଲକ୍ଷଣଗୁଡ଼ିକର ନିରୀକ୍ଷଣ କରନ୍ତୁ",
      takeMedications: "ନିର୍ଦ୍ଧାରିତ ଔଷଧ ନିଅନ୍ତୁ",
      monitorDehydration: "ନିର୍ଜଳୀକରଣ ଚିହ୍ନଗୁଡ଼ିକର ନିରୀକ୍ଷଣ କରନ୍ତୁ",
      monitorComplications: "ବର୍ତ୍ତମାନର ଅବସ୍ଥା ଯୋଗୁଁ ଜଟିଳତାର ନିରୀକ୍ଷଣ କରନ୍ତୁ",
      seekCare: "ଲକ୍ଷଣ ଖରାପ ହେଲେ ଚିକିତ୍ସା ନିଅନ୍ତୁ",
      followUpQuestions: "ଅତିରିକ୍ତ ପ୍ରଶ୍ନ",
      illnessDuration: "ବ୍ୟାଧିର ଅବଧି",
      daysSinceSymptoms: "ଆପଣଙ୍କୁ ଏହି ଲକ୍ଷଣଗୁଡ଼ିକ କେତେ ଦିନରୁ ଅଛି?",
      whyImportant: "ଏହା କାହିଁକି ଗୁରୁତ୍ୱପୂର୍ଣ୍ଣ?",
      durationExplanation: "ଲକ୍ଷଣଗୁଡ଼ିକର ଅବଧି ଆମକୁ ଗୁରୁତ୍ୱ ଏବଂ ଉପଯୁକ୍ତ ଚିକିତ୍ସା ନିର୍ଣ୍ଣୟ କରିବାରେ ସାହାଯ୍ୟ କରେ। କେତେକ ଅବସ୍ଥା ସମୟ ସହିତ ଗୁରୁତର ହୋଇଯାଏ, ଯେତେବେଳେ ଅନ୍ୟଗୁଡ଼ିକ ପ୍ରାକୃତିକ ଭାବରେ ଠିକ୍ ହୋଇଯାଏ।"
    },
    severity: {
      mild: "ହାଲକା",
      moderate: "ମଧ୍ୟମ",
      severe: "ଗୁରୁତର"
    },
    common: {
      loading: "ଲୋଡ୍ ହେଉଛି...",
      error: "ତ୍ରୁଟି",
      success: "ସଫଳତା",
      cancel: "ବାତିଲ୍ କରନ୍ତୁ",
      save: "ସେଭ୍ କରନ୍ତୁ",
      edit: "ସମ୍ପାଦନ କରନ୍ତୁ",
      delete: "ଡିଲିଟ୍ କରନ୍ତୁ",
      add: "ଯୋଡନ୍ତୁ",
      search: "ଖୋଜନ୍ତୁ",
      filter: "ଫିଲ୍ଟର୍",
      sort: "କ୍ରମାନୁସାରେ ସଜାନ୍ତୁ",
      refresh: "ରିଫ୍ରେସ୍ କରନ୍ତୁ",
      offline: "ଅଫଲାଇନ୍",
      online: "ଅନଲାଇନ୍"
    },
    messages: {
      welcomeMessage: "ନିଦାନରେ ଆପଣଙ୍କୁ ସ୍ୱାଗତ - ଆପଣଙ୍କର ସ୍ୱାସ୍ଥ୍ୟ ସାଥୀ",
      symptomCheckComplete: "ଲକ୍ଷଣ ଯାଞ୍ଚ ସମ୍ପୂର୍ଣ୍ଣ ହେଲା",
      vaccinationReminder: "ଟିକାକରଣ ସ୍ମାରକ ସେଟ୍ ହେଲା",
      outbreakAlert: "ଆପଣଙ୍କ ଅଞ୍ଚଳରେ ନୂତନ ପ୍ରକୋପ ଚେତାବନୀ",
      emergencyContacted: "ଜରୁରୀ ସମ୍ପର୍କକୁ ସୂଚିତ କରାଗଲା",
      dataSaved: "ଡାଟା ସଫଳତାର ସହିତ ସେଭ୍ ହେଲା",
      networkError: "ନେଟୱର୍କ ତ୍ରୁଟି। ଦୟାକରି ଆପଣଙ୍କର କନେକ୍ସନ୍ ଯାଞ୍ଚ କରନ୍ତୁ।"
    },
    results: {
      recommendations: {
        mild: "ଘରେ ଲକ୍ଷଣଗୁଡ଼ିକର ନିରୀକ୍ଷଣ କରନ୍ତୁ। ବିଶ୍ରାମ ନିଅନ୍ତୁ ଏବଂ ହାଇଡ୍ରେଟେଡ୍ ରୁହନ୍ତୁ।",
        moderate: "ଉପଯୁକ୍ତ ନିର୍ଣ୍ଣୟ ପାଇଁ 24 ଘଣ୍ଟା ମଧ୍ୟରେ ନିକଟତମ କ୍ଲିନିକ୍ ଯାଆନ୍ତୁ।",
        severe: "ତୁରନ୍ତ ଚିକିତ୍ସା ସହାୟତା ନିଅନ୍ତୁ। ଆବଶ୍ୟକ ହେଲେ ଜରୁରୀ ସେବା ସହିତ ସମ୍ପର୍କ କରନ୍ତୁ।"
      },
      homeRemedies: {
        rest: "ବିଶ୍ରାମ",
        hydration: "ହାଇଡ୍ରେସନ୍",
        monitorTemperature: "ତାପମାତ୍ରା ନିରୀକ୍ଷଣ",
        lightMeals: "ହାଲୁକା ଖାଦ୍ୟ",
        avoidExertion: "ପରିଶ୍ରମ ଏଡ଼ାନ୍ତୁ",
        monitorVitalSigns: "ମହତ୍ତ୍ୱପୂର୍ଣ୍ଣ ସଙ୍କେତ ନିରୀକ୍ଷଣ"
      },
      clinics: {
        puriPHC: "ପୁରୀ PHC - 2.5 କିମି ଦୂର",
        puriDistrictHospital: "ପୁରୀ ଜିଲ୍ଲା ଡାକ୍ତରଖାନା - 2.5 କିମି ଦୂର",
        puriEmergency: "ପୁରୀ ଜିଲ୍ଲା ଡାକ୍ତରଖାନା - ଜରୁରୀ ବିଭାଗ"
      },
      ashaWorkers: {
        available: "ସୁନୀତା ଦେବୀ (+91-98765-43210) - ପରାମର୍ଶ ପାଇଁ ଉପଲବ୍ଧ",
        willContact: "ସୁନୀତା ଦେବୀ (+91-98765-43210) - 2 ଘଣ୍ଟା ମଧ୍ୟରେ ସମ୍ପର୍କ କରିବେ",
        emergencyInitiated: "ସୁନୀତା ଦେବୀ (+91-98765-43210) - ଜରୁରୀ ସମ୍ପର୍କ ଆରମ୍ଭ କରାଗଲା"
      },
      outbreakAlerts: {
        dengue: {
          recommendation: "ମଶା ଜାଲ ବ୍ୟବହାର କରନ୍ତୁ, ଖଡ଼ିଥିବା ପାଣି ଦୂର କରନ୍ତୁ, ସୁରକ୍ଷାତ୍ମକ ପୋଷାକ ପିନ୍ଧନ୍ତୁ",
          symptoms: ["ଉଚ୍ଚ ଜ୍ୱର", "ଗୁରୁତର ମୁଣ୍ଡବ୍ୟଥା", "ଆଖି ପଛରେ ଯନ୍ତ୍ରଣା", "ମାଂସପେଶୀ ଏବଂ ଗଣ୍ଠି ଯନ୍ତ୍ରଣା"],
          prevention: ["ମଶା ନିରୋଧକ ବ୍ୟବହାର କରନ୍ତୁ", "ଲମ୍ବା ହାତ ପୋଷାକ ପିନ୍ଧନ୍ତୁ", "ଖଡ଼ିଥିବା ପାଣି ଦୂର କରନ୍ତୁ", "ବିଛଣା ଜାଲ ବ୍ୟବହାର କରନ୍ତୁ"]
        },
        malaria: {
          recommendation: "ନିରାପଦ ଉପାୟ ଅବଲମ୍ବନ କରନ୍ତୁ, ମଶା ଜାଲ ବ୍ୟବହାର କରନ୍ତୁ",
          symptoms: ["ଜ୍ୱର", "ଥଣ୍ଡା ଲାଗିବା", "ଝାଳ ବୋହିବା", "ମୁଣ୍ଡବ୍ୟଥା"],
          prevention: ["ମଶା ଜାଲ ବ୍ୟବହାର କରନ୍ତୁ", "ନିରୋଧକ ଲଗାନ୍ତୁ", "ସୁରକ୍ଷାତ୍ମକ ପୋଷାକ ପିନ୍ଧନ୍ତୁ"]
        }
      },
      healthTips: {
        monsoon: {
          title: "ବର୍ଷା ଋତୁ ସ୍ୱାସ୍ଥ୍ୟ ସୁପାରିଶ",
          content: "ବର୍ଷା ଋତୁରେ, ଜଳଜନିତ ରୋଗ ପ୍ରତିରୋଧ ପାଇଁ ରାସ୍ତା କଡ଼ାର ଖାଦ୍ୟ ଏଡ଼ାନ୍ତୁ ଏବଂ କେବଳ ଫୁଟା ପାଣି ପିଅନ୍ତୁ।"
        },
        vaccination: {
          title: "ଟିକାକରଣ ସ୍ମାରକ",
          content: "ଆପଣଙ୍କର ଟିକାକରଣ କାର୍ଯ୍ୟକ୍ରମକୁ ଅପଡେଟ୍ ରଖନ୍ତୁ। ଟିକା ଛାଡ଼ିବା ଗୁରୁତର ସ୍ୱାସ୍ଥ୍ୟ ଜଟିଳତା ସୃଷ୍ଟି କରିପାରେ।"
        },
        hygiene: {
          title: "ହାତ ସ୍ୱଚ୍ଛତା",
          content: "ଖାଇବା ପୂର୍ବରୁ ଏବଂ ଶୌଚାଳୟ ବ୍ୟବହାର ପରେ ବିଶେଷ ଭାବରେ ସାବୁନ ଏବଂ ପାଣିରେ ହାତକୁ ବାରମ୍ବାର ଧୋଇବେ।"
        },
        weatherAdvice: "ଉଚ୍ଚ ଆର୍ଦ୍ରତା ଏବଂ ଖଡ଼ିଥିବା ପାଣି ରୋଗ ବିପଦ ବଢ଼ାଏ। ମଶା ଜାଲ ବ୍ୟବହାର କରନ୍ତୁ ଏବଂ ସ୍ଥିର ପାଣି ଏଡ଼ାନ୍ତୁ।"
      }
    }
  },
  sambalpuri: {
    navigation: {
      home: "ଘର",
      vaccines: "ଟିକା",
      symptoms: "ଲକ୍ଷଣ",
      alerts: "ଚେତାବନୀ",
      profile: "ପ୍ରୋଫାଇଲ"
    },
    buttons: {
      checkSymptoms: "ଲକ୍ଷଣ ଦେଖ",
      viewReminders: "ମନେପଡ଼ା ଦେଖ",
      emergencyContact: "ଜରୁରୀ କାମ",
      shareWhatsApp: "WhatsApp ରେ ଦେଖାଅ",
      sendSMS: "SMS ପଠାଅ",
      speakNow: "ଏବେ କହ",
      stopSpeaking: "କହିବା ବନ୍ଦ କର",
      selectLanguage: "ଭାଷା ବାଛ",
      toggleTheme: "ରଙ୍ଗ ବଦଳାଅ",
      listening: "ଶୁଣୁଛି...",
      voiceNotSupported: "ଭଏସ୍ ଇନପୁଟ୍ କାମ କରୁନାହିଁ",
      microphonePermissionDenied: "ମାଇକ୍ରୋଫୋନ୍ ଅନୁମତି ନାହିଁ"
    },
    labels: {
      enterSymptoms: "ଲକ୍ଷଣ ଲେଖ",
      selectLanguage: "ଭାଷା ବାଛ",
      currentLocation: "ଏବେ କେଉଁଠି",
      pincode: "ପିନ",
      phoneNumber: "ଫୋନ୍",
      name: "ନାମ",
      dateOfBirth: "ଜନ୍ମ ଦିନ",
      familyMembers: "ପରିବାର",
      vaccinationSchedule: "ଟିକା ତାରିଖ",
      dueVaccines: "ଦେୟ ଟିକା",
      nextDueDate: "ଆଗ ଟିକା ଦିନ",
      vaccinationCenter: "ଟିକା ଘର",
      outbreakAlerts: "ବ୍ୟାଧି ଚେତାବନୀ",
      severity: "କେତେ ଗୁରୁତର",
      recommendation: "କଣ କରିବେ",
      homeRemedies: "ଘରେ କଣ କରିବେ",
      nearestClinic: "ନିକଟ ଡାକ୍ତର ଘର",
      ashaWorker: "ଆଶା ଦିଦି",
      malaria: "ମ୍ୟାଲେରିଆ",
      dengue: "ଡେଙ୍ଗୁ",
      cholera: "କଲେରା",
      diarrhea: "ତରଳ ଝାଡ଼ା",
      unknown: "ଜାଣି ନାହିଁ",
      monitorSymptoms: "ଲକ୍ଷଣ ଦେଖ",
      takeMedications: "ଔଷଧ ଖା",
      monitorDehydration: "ପାଣି କମ ହେଉଛି କି ଦେଖ",
      monitorComplications: "ଅନ୍ୟ ବ୍ୟାଧି ହେଉଛି କି ଦେଖ",
      seekCare: "ଖରାପ ହେଲେ ଡାକ୍ତର ଦେଖା",
      followUpQuestions: "ଅଧିକ ପ୍ରଶ୍ନ",
      illnessDuration: "ବ୍ୟାଧି କେତେ ଦିନ",
      daysSinceSymptoms: "ତୁମକୁ ଏହି ଲକ୍ଷଣ କେତେ ଦିନରୁ ଅଛି?",
      whyImportant: "ଏହା କାହିଁକି ଜରୁରୀ?",
      durationExplanation: "ଲକ୍ଷଣ କେତେ ଦିନ ହେଲା ଜାଣିଲେ ଆମେ କେତେ ଗୁରୁତର ଏବଂ କଣ କରିବେ ବୁଝିପାରିବା। କେତେକ ବ୍ୟାଧି ଦିନ ଗଡ଼ିଲେ ଖରାପ ହୁଏ, କେତେକ ଆପେ ଠିକ୍ ହୋଇଯାଏ।"
    },
    severity: {
      mild: "ହାଲକା",
      moderate: "ମଝିଆ",
      severe: "ଗୁରୁତର"
    },
    common: {
      loading: "ଲୋଡ୍ ହେଉଛି...",
      error: "ଗଲତି",
      success: "ହେଲା",
      cancel: "ବାତିଲ୍",
      save: "ରଖ",
      edit: "ବଦଳାଅ",
      delete: "ଡିଲିଟ୍",
      add: "ଯୋଡ",
      search: "ଖୋଜ",
      filter: "ଛାଣ",
      sort: "ସଜାଅ",
      refresh: "ନୂଆ କର",
      offline: "ଅଫଲାଇନ୍",
      online: "ଅନଲାଇନ୍"
    },
    messages: {
      welcomeMessage: "ନିଦାନରେ ସ୍ୱାଗତ - ତୁମର ସ୍ୱାସ୍ଥ୍ୟ ସାଥୀ",
      symptomCheckComplete: "ଲକ୍ଷଣ ଯାଞ୍ଚ ହେଲା",
      vaccinationReminder: "ଟିକା ମନେପଡ଼ା ରଖିଲା",
      outbreakAlert: "ତୁମ ଗାଁରେ ନୂତନ ବ୍ୟାଧି ଚେତାବନୀ",
      emergencyContacted: "ଜରୁରୀ କାମ କରିବାକୁ କହିଲା",
      dataSaved: "ଡାଟା ରଖିଲା",
      networkError: "ନେଟ୍ ଗଲତି। ଫୋନ୍ ଯାଞ୍ଚ କର।"
    },
    results: {
      recommendations: {
        mild: "ଘରେ ଲକ୍ଷଣ ଦେଖ। ବିଶ୍ରାମ ନିଅ ଏବଂ ପାଣି ପିଅ।",
        moderate: "ଠିକ୍ ଜାଣିବା ପାଇଁ 24 ଘଣ୍ଟା ମଧ୍ୟରେ ନିକଟ ଡାକ୍ତର ଘର ଯା।",
        severe: "ତୁରନ୍ତ ଡାକ୍ତର ଦେଖ। ଜରୁରୀ ହେଲେ ଜରୁରୀ କାମ କର।"
      },
      homeRemedies: {
        rest: "ବିଶ୍ରାମ",
        hydration: "ପାଣି ପିଅ",
        monitorTemperature: "ଗରମ ଦେଖ",
        lightMeals: "ହାଲୁକା ଖାଇବା",
        avoidExertion: "ମେହନତ ନ କର",
        monitorVitalSigns: "ମୁଖ୍ୟ ଚିହ୍ନ ଦେଖ"
      },
      clinics: {
        puriPHC: "ପୁରୀ PHC - 2.5 କିମି ଦୂର",
        puriDistrictHospital: "ପୁରୀ ଡାକ୍ତର ଘର - 2.5 କିମି ଦୂର",
        puriEmergency: "ପୁରୀ ଡାକ୍ତର ଘର - ଜରୁରୀ ବିଭାଗ"
      },
      ashaWorkers: {
        available: "ସୁନୀତା ଦିଦି (+91-98765-43210) - ପରାମର୍ଶ ପାଇଁ ଅଛି",
        willContact: "ସୁନୀତା ଦିଦି (+91-98765-43210) - 2 ଘଣ୍ଟା ମଧ୍ୟରେ କହିବେ",
        emergencyInitiated: "ସୁନୀତା ଦିଦି (+91-98765-43210) - ଜରୁରୀ କାମ ଆରମ୍ଭ କଲା"
      },
      outbreakAlerts: {
        dengue: {
          recommendation: "ମଶା ଜାଲ ବ୍ୟବହାର କର, ଖଡ଼ିଥିବା ପାଣି ଦୂର କର, ଲମ୍ବା ପୋଷାକ ପିନ୍ଧ",
          symptoms: ["ବହୁତ ଜ୍ୱର", "ମୁଣ୍ଡ ବହୁତ ବ୍ୟଥା", "ଆଖି ପଛରେ ବ୍ୟଥା", "ମାଂସ ଏବଂ ଗଣ୍ଠି ବ୍ୟଥା"],
          prevention: ["ମଶା ନିରୋଧକ ଲଗା", "ଲମ୍ବା ପୋଷାକ ପିନ୍ଧ", "ଖଡ଼ିଥିବା ପାଣି ଦୂର କର", "ବିଛଣା ଜାଲ ବ୍ୟବହାର କର"]
        },
        malaria: {
          recommendation: "ସାବଧାନ ରୁହ, ମଶା ଜାଲ ବ୍ୟବହାର କର",
          symptoms: ["ଜ୍ୱର", "ଥଣ୍ଡା ଲାଗିବା", "ଝାଳ ବୋହିବା", "ମୁଣ୍ଡ ବ୍ୟଥା"],
          prevention: ["ମଶା ଜାଲ ବ୍ୟବହାର କର", "ନିରୋଧକ ଲଗା", "ଲମ୍ବା ପୋଷାକ ପିନ୍ଧ"]
        }
      },
      healthTips: {
        monsoon: {
          title: "ବର୍ଷା ସ୍ୱାସ୍ଥ୍ୟ ସୁପାରିଶ",
          content: "ବର୍ଷାରେ, ପାଣି ରୋଗ ଏଡ଼ାଇବା ପାଇଁ ରାସ୍ତା ଖାଦ୍ୟ ଏଡ଼ା ଏବଂ କେବଳ ଫୁଟା ପାଣି ପିଅ।"
        },
        vaccination: {
          title: "ଟିକା ମନେପଡ଼ା",
          content: "ତୁମର ଟିକା ତାରିଖ ଠିକ୍ ରଖ। ଟିକା ଛାଡ଼ିଲେ ବହୁତ ବ୍ୟାଧି ହୋଇପାରେ।"
        },
        hygiene: {
          title: "ହାତ ସଫା କର",
          content: "ଖାଇବା ପୂର୍ବରୁ ଏବଂ ଶୌଚ ପରେ ସାବୁନ ଏବଂ ପାଣିରେ ହାତ ଧୋଇବେ।"
        },
        weatherAdvice: "ବହୁତ ଆର୍ଦ୍ରତା ଏବଂ ଖଡ଼ିଥିବା ପାଣି ରୋଗ ବଢ଼ାଏ। ମଶା ଜାଲ ବ୍ୟବହାର କର ଏବଂ ଖଡ଼ିଥିବା ପାଣି ଏଡ଼ା।"
      }
    }
  }
};

export const languageNames = {
  english: "English",
  hindi: "हिंदी",
  odia: "ଓଡ଼ିଆ",
  sambalpuri: "ସମ୍ବଲପୁରୀ"
};

export const languageFlags = {
  english: "🇺🇸",
  hindi: "🇮🇳",
  odia: "🇮🇳",
  sambalpuri: "🇮🇳"
};
